# VideoAlchemist 质检员系统 (QA Sub-agents)

## 架构设计

```
VideoAlchemist (主代理)
    │
    ├─▶ TopicMiner (选题)
    │       ↓
    │   ┌─────────────────┐
    │   │ 提示词质检员     │ ◀── 检查选题提示词质量
    │   │ PromptQA        │
    │   └─────────────────┘
    │       ↓
    ├─▶ StoryForge (文案)
    │       ↓
    │   ┌─────────────────┐
    │   │ 文本质检员       │ ◀── 检查文案质量、节奏、 viral 元素
    │   │ TextQA          │
    │   └─────────────────┘
    │       ↓
    ├─▶ ShotDesign (分镜)
    │       ↓
    │   ┌─────────────────┐
    │   │ 一致性质检员     │ ◀── 检查分镜与文案一致性
    │   │ ConsistencyQA   │
    │   └─────────────────┘
    │       ↓
    ├─▶ StyleBible (设定集)
    │       ↓
    │   ┌─────────────────┐
    │   │ 一致性质检员     │ ◀── 检查视觉风格一致性
    │   │ ConsistencyQA   │
    │   └─────────────────┘
    │
    └─▶ 最终输出
```

---

## 1️⃣ 文本质检员 (TextQA)

### 职责
检查文案内容的质量、可读性、 viral 潜力

### 检查维度

| 维度 | 标准 | 权重 |
|------|------|------|
| **可读性** | 句子长度 < 20字，段落 < 3句 | 20% |
| **节奏感** | 长短句交错，有呼吸感 | 15% |
| **情绪密度** | 每30秒至少1个情绪点 | 20% |
| **钩子质量** | 开场3秒有吸引力 | 25% |
| **互动设计** | 有明确的评论引导/槽点 | 20% |

### 输出格式
```json
{
  "score": 85,
  "passed": true,
  "checks": {
    "readability": { "score": 90, "issues": [] },
    "rhythm": { "score": 80, "issues": ["第3段过长"] },
    "emotion": { "score": 85, "issues": [] },
    "hook": { "score": 90, "issues": [] },
    "interaction": { "score": 80, "issues": ["缺少槽点"] }
  },
  "suggestions": [
    "第3段建议拆分为2段，增强节奏感",
    "在1:30处增加一个反问句，提升互动率"
  ],
  "revised_text": "...（修正后的文案）"
}
```

---

## 2️⃣ 一致性质检员 (ConsistencyQA)

### 职责
检查各步骤产出的一致性，确保不偏离原始意图

### 检查维度

| 检查点 | 说明 |
|--------|------|
| **选题-文案一致** | 文案是否切入选题角度 |
| **文案-分镜一致** | 分镜是否准确表达文案内容 |
| **分镜-设定一致** | 视觉风格是否匹配内容调性 |
| **跨步骤角色一致** | 角色设定是否前后统一 |
| **情绪基调一致** | 整体情绪是否连贯 |

### 输出格式
```json
{
  "score": 92,
  "passed": true,
  "consistency_checks": {
    "topic_to_script": { "aligned": true, "drift": 0.1 },
    "script_to_shots": { "aligned": true, "drift": 0.05 },
    "shots_to_style": { "aligned": true, "drift": 0.08 },
    "character_continuity": { "aligned": true, "issues": [] },
    "tone_consistency": { "aligned": true, "tone": "励志" }
  },
  "drift_warnings": [],
  "suggestions": [
    "分镜3的情绪比文案更激昂，建议调整"
  ]
}
```

---

## 3️⃣ 提示词质检员 (PromptQA)

### 职责
检查所有 AI 生成提示词的质量、完整性、可执行性

### 检查维度

| 维度 | 标准 |
|------|------|
| **完整性** | 包含主体、动作、场景、风格、质量词 |
| **清晰度** | 无歧义，AI 可准确理解 |
| **一致性** | 系列提示词风格统一 |
| **可优化性** | 有明确的调优空间 |
| **安全性** | 无敏感词、违规内容 |

### 输出格式
```json
{
  "score": 88,
  "passed": true,
  "prompt_checks": {
    "completeness": { 
      "score": 90, 
      "missing": [],
      "has_subject": true,
      "has_action": true,
      "has_scene": true,
      "has_style": true,
      "has_quality": true
    },
    "clarity": { "score": 85, "ambiguous_terms": ["好看"] },
    "consistency": { "score": 90, "style_drift": 0.1 },
    "optimizability": { "score": 85, "suggestions": ["添加具体色彩"] },
    "safety": { "score": 100, "flags": [] }
  },
  "optimized_prompts": [
    "原始: 一个好看的角色",
    "优化: 一个可爱的3D卡通角色，大眼睛，圆脸，粉色头发，8k分辨率，Unreal Engine渲染"
  ]
}
```

---

## 质检流程 (Pipeline)

```javascript
// 在每个步骤后自动触发质检

async function videoProductionPipeline(topic) {
  // Step 1: 选题
  const topicResult = await topicMiner.generate(topic);
  
  // 触发：提示词质检员
  const topicQA = await spawnSubAgent('PromptQA', {
    input: topicResult.prompts,
    threshold: 80
  });
  if (!topicQA.passed) return revise(topicResult, topicQA);
  
  // Step 2: 文案
  const scriptResult = await storyForge.generate(topicResult);
  
  // 触发：文本质检员
  const textQA = await spawnSubAgent('TextQA', {
    input: scriptResult.text,
    threshold: 85
  });
  if (!textQA.passed) return revise(scriptResult, textQA);
  
  // Step 3: 分镜
  const shotResult = await shotDesign.generate(scriptResult);
  
  // 触发：一致性质检员
  const consistencyQA1 = await spawnSubAgent('ConsistencyQA', {
    inputs: [scriptResult, shotResult],
    threshold: 90
  });
  if (!consistencyQA1.passed) return revise(shotResult, consistencyQA1);
  
  // Step 4: 设定集
  const styleResult = await styleBible.generate(shotResult);
  
  // 触发：一致性质检员 + 提示词质检员
  const consistencyQA2 = await spawnSubAgent('ConsistencyQA', {
    inputs: [shotResult, styleResult],
    threshold: 90
  });
  const promptQA2 = await spawnSubAgent('PromptQA', {
    input: styleResult.prompts,
    threshold: 80
  });
  
  if (!consistencyQA2.passed || !promptQA2.passed) {
    return revise(styleResult, [consistencyQA2, promptQA2]);
  }
  
  return finalize(topicResult, scriptResult, shotResult, styleResult);
}
```

---

## Sub-agent 配置

### 通用配置
```json
{
  "agent_type": "qa_subagent",
  "parent_agent": "VideoAlchemist",
  "lifecycle": "ephemeral",
  "max_execution_time": "30s",
  "memory": "none",
  "report_to_parent": true
}
```

### 触发条件
| 质检员 | 触发步骤 | 触发时机 | 失败处理 |
|--------|----------|----------|----------|
| PromptQA | 选题、设定集 | 步骤完成后 | 返回修正建议，重新生成 |
| TextQA | 文案 | 步骤完成后 | 返回修改建议，优化文案 |
| ConsistencyQA | 分镜、设定集 | 步骤完成后 | 指出不一致点，调整对齐 |

### 并行优化
```javascript
// 独立质检可并行
const [textQA, consistencyQA] = await Promise.all([
  spawnSubAgent('TextQA', { input: script }),
  spawnSubAgent('ConsistencyQA', { inputs: [topic, script] })
]);
```

---

## 质检标准配置

```json
{
  "qa_thresholds": {
    "critical": 90,
    "high": 80,
    "medium": 70,
    "low": 60
  },
  "auto_revise": true,
  "max_iterations": 3,
  "escalation": "human_review"
}
```
