#!/usr/bin/env node
/**
 * VideoAlchemist - StoryForge 内容生产
 * 将选题转化为高完播率的视频文案
 */

class StoryForge {
  constructor(config = {}) {
    this.style = config.style || 'knowledge'; // knowledge, story, opinion
    this.platform = config.platform || 'douyin';
    this.duration = config.duration || 60; // seconds
  }

  async generateContent(topic, options = {}) {
    console.log('✍️  开始内容生产...\n');
    
    // 1. 结构设计
    const structure = this.designStructure();
    
    // 2. 文案撰写
    const script = await this.writeScript(topic, structure);
    
    // 3. 植入病毒元素
    const viralScript = this.injectViralElements(script);
    
    // 4. 节奏优化
    const optimizedScript = this.optimizeRhythm(viralScript);
    
    return {
      title: topic.titleOptions[0],
      script: optimizedScript,
      structure: structure,
      wordCount: this.countWords(optimizedScript),
      estimatedDuration: this.calculateDuration(optimizedScript),
      viralPoints: this.identifyViralPoints(optimizedScript)
    };
  }

  designStructure() {
    const structures = {
      knowledge: {
        name: '知识科普结构',
        parts: [
          { name: '开场钩', duration: '0-3s', goal: '抓住注意力' },
          { name: '痛点共鸣', duration: '3-8s', goal: '建立连接' },
          { name: '核心知识', duration: '8-40s', goal: '传递价值' },
          { name: '案例佐证', duration: '40-50s', goal: '增强可信' },
          { name: '总结升华', duration: '50-55s', goal: '强化记忆' },
          { name: '互动引导', duration: '55-60s', goal: '促进互动' }
        ]
      },
      story: {
        name: '故事叙事结构',
        parts: [
          { name: '悬念开场', duration: '0-5s', goal: '引发好奇' },
          { name: '背景铺垫', duration: '5-15s', goal: '建立情境' },
          { name: '冲突升级', duration: '15-40s', goal: '制造张力' },
          { name: '高潮转折', duration: '40-50s', goal: '情绪爆发' },
          { name: '结局落点', duration: '50-58s', goal: '情感共鸣' },
          { name: '留白思考', duration: '58-60s', goal: '引发回味' }
        ]
      },
      opinion: {
        name: '观点输出结构',
        parts: [
          { name: '立场鲜明', duration: '0-5s', goal: '表明态度' },
          { name: '反常识钩子', duration: '5-10s', goal: '颠覆预期' },
          { name: '论据支撑', duration: '10-35s', goal: '逻辑说服' },
          { name: '反驳预判', duration: '35-45s', goal: '堵住质疑' },
          { name: '价值升华', duration: '45-55s', goal: '提升格局' },
          { name: '行动号召', duration: '55-60s', goal: '引导行动' }
        ]
      }
    };
    
    return structures[this.style] || structures.knowledge;
  }

  async writeScript(topic, structure) {
    const parts = [];
    
    for (const part of structure.parts) {
      const content = await this.writePart(part, topic);
      parts.push({
        ...part,
        content: content
      });
    }
    
    return parts;
  }

  async writePart(part, topic) {
    // 根据部分类型生成内容
    const writers = {
      '开场钩': () => this.writeHook(topic),
      '痛点共鸣': () => this.writePainPoint(topic),
      '核心知识': () => this.writeCoreKnowledge(topic),
      '案例佐证': () => this.writeCase(topic),
      '总结升华': () => this.writeSummary(topic),
      '互动引导': () => this.writeInteraction(topic),
      '悬念开场': () => this.writeSuspense(topic),
      '背景铺垫': () => this.writeBackground(topic),
      '冲突升级': () => this.writeConflict(topic),
      '高潮转折': () => this.writeClimax(topic),
      '结局落点': () => this.writeEnding(topic),
      '留白思考': () => this.writeReflection(topic),
      '立场鲜明': () => this.writeStance(topic),
      '反常识钩子': () => this.writeCounterIntuitive(topic),
      '论据支撑': () => this.writeArguments(topic),
      '反驳预判': () => this.writeRebuttal(topic),
      '价值升华': () => this.writeElevation(topic),
      '行动号召': () => this.writeCallToAction(topic)
    };
    
    const writer = writers[part.name] || (() => `【${part.name}内容】`);
    return writer();
  }

  writeHook(topic) {
    const hooks = {
      'AI取代工作': [
        'AI不会取代你，但会用AI的人会。',
        '测试了100个岗位，我发现最危险的其实是...',
        '如果你还在做这3件事，危机已经来了。'
      ],
      '普通人逆袭': [
        '月入3千到3万，我只做了这3件事。',
        '普通人逆袭的唯一路径，今天全部分享给你。',
        '为什么有人3年逆袭，有人10年原地？差距就在这一点。'
      ]
    };
    
    const options = hooks[topic.keyword] || [
      `${topic.keyword}的真相，99%的人都不知道。`,
      `关于${topic.keyword}，我第一次公开这个秘密。`,
      `${topic.keyword}？看完这个你就全懂了。`
    ];
    
    return options[0];
  }

  writePainPoint(topic) {
    return `你是不是也经历过：努力工作却看不到希望？刷到别人逆袭的视频，心里焦虑却不知道从何开始？${topic.keyword}这个话题，戳中了太多人的痛点。`;
  }

  writeCoreKnowledge(topic) {
    const knowledge = {
      'AI取代工作': `先说结论：AI不会取代所有人，但会取代那些重复性强、规则明确的工作。\n\n第一类危险岗位：数据录入、简单翻译、基础客服...\n第二类过渡岗位：初级设计、基础写作、表格处理...\n第三类安全岗位：需要创意、情感连接、复杂决策的工作。\n\n但关键在于，即使是安全岗位，如果你不会用AI辅助，效率上也会被甩开。`,
      
      '普通人逆袭': `普通人逆袭的核心，不是天赋，不是运气，而是三个字：信息差。\n\n第一步：找到你的信息差优势。你比大多数人懂什么？\n第二步：把这个优势产品化。能帮别人解决什么问题？\n第三步：规模化传播。让更多人知道你能解决这个问题。\n\n听起来简单，但90%的人卡在了第一步。`
    };
    
    return knowledge[topic.keyword] || `${topic.keyword}的核心，其实就三个关键点。第一，大多数人理解错了；第二，真正有效的方法往往反直觉；第三，执行比认知更重要。`;
  }

  writeCase(topic) {
    return `我举个例子。去年有个粉丝找我，他${topic.keyword.includes('AI') ? '做客服的，每天被客户骂，工资还低' : '工资3千，欠了5万网贷，差点想不开'}。\n\n我让他做了3个改变：${topic.keyword.includes('AI') ? '第一，学会用ChatGPT处理80%的重复咨询；第二，把省下来的时间研究客户心理；第三，把自己的方法论做成课程分享' : '第一，找出他最擅长的技能；第二，在闲鱼上接单开始；第三，把每个客户都变成长期合作'}。\n\n6个月后，他${topic.keyword.includes('AI') ? '升职加薪，还开了自己的AI培训课' : '月入过万，还清了债务，现在有自己的小工作室'}。`;
  }

  writeSummary(topic) {
    return `所以，${topic.keyword}不是不可能，而是你需要正确的方法。记住这3点：${this.style === 'knowledge' ? '选对赛道、持续学习、快速执行' : '找到自己的优势、持续打磨、勇敢展示'}。`;
  }

  writeInteraction(topic) {
    const interactions = [
      '你同意吗？评论区说说你的看法。',
      '你正在经历什么？评论区聊聊，有问必答。',
      '如果你觉得有用，点个赞让更多人看到。',
      '你踩过什么坑？评论区提醒一下大家。'
    ];
    return interactions[Math.floor(Math.random() * interactions.length)];
  }

  // 故事型部分
  writeSuspense(topic) {
    return `那天晚上，我收到了一条改变我人生轨迹的消息。`;
  }

  writeBackground(topic) {
    return `那时候我刚毕业，${topic.keyword.includes('AI') ? '对未来充满迷茫，不知道要做什么' : '工资只有2500，住城中村，每天挤2小时地铁'}。`;
  }

  writeConflict(topic) {
    return `转折点发生在一次${topic.keyword.includes('AI') ? '部门裁员' : '意外的机会'}。那天，${topic.keyword.includes('AI') ? '老板把我叫到办公室，我以为要被开了，结果他说...' : '一个客户问我能不能帮忙做个项目，我硬着头皮接了'}。`;
  }

  writeClimax(topic) {
    return `${topic.keyword.includes('AI') ? '他说：你知道为什么留你吗？因为你上周用那个工具做的报告，比其他人3天做的都好。那一刻我明白了，技术不是威胁，不会用技术才是。' : '我连续3天没睡，把这个项目做到极致。客户看完直接说：以后我的项目都给你做。第一单我赚了8000，比我之前2个月的工资还多。'}`;
  }

  writeEnding(topic) {
    return `从那以后，我的人生彻底改变了。不是因为我多聪明，而是因为我${topic.keyword.includes('AI') ? '学会了拥抱变化' : '敢于抓住机会'}。`;
  }

  writeReflection(topic) {
    return `如果是你，你会怎么做？`;
  }

  // 观点型部分
  writeStance(topic) {
    return `我的观点很明确：${topic.keyword}，大多数人理解错了。`;
  }

  writeCounterIntuitive(topic) {
    return `反常识的是：${topic.keyword.includes('AI') ? '越怕AI的人，越容易被取代。因为焦虑让你停步不前，而别人已经在用AI提效了' : '越想逆袭的人，往往越难成功。因为急于求成，反而做不成事'}。`;
  }

  writeArguments(topic) {
    return `为什么这么说？首先，从数据来看...其次，从逻辑上讲...最后，从实际案例验证...`;
  }

  writeRebuttal(topic) {
    return `你可能会说：${topic.keyword.includes('AI') ? '我又不是技术人员，怎么用AI？' : '我没有资源，怎么逆袭？'}\n\n我的回答是：${topic.keyword.includes('AI') ? '现在的AI工具，小学毕业的人都能用。关键是你愿不愿意花1小时学习。' : '所有的资源，都是从一个客户、一个项目开始积累的。你缺的不是资源，是开始的勇气。'}`;
  }

  writeElevation(topic) {
    return `${topic.keyword}，本质上是一场认知的升级。当你看清了本质，你就超越了90%的人。`;
  }

  writeCallToAction(topic) {
    return `如果你准备好了，就从今天开始行动。哪怕只是迈出一小步，也比原地焦虑强100倍。`;
  }

  injectViralElements(script) {
    // 在合适的位置植入槽点、金句
    return script.map(part => {
      if (part.name === '核心知识' || part.name === '论据支撑') {
        return {
          ...part,
          content: this.addMemePoints(part.content)
        };
      }
      return part;
    });
  }

  addMemePoints(content) {
    // 添加记忆点和槽点
    const memeInserts = [
      '（懂的都懂）',
      '（dddd）',
      '（这里划重点）',
      '（评论区肯定有杠精，我先预判一下）'
    ];
    
    // 简单模拟：在内容后随机添加
    return content + '\n\n' + memeInserts[Math.floor(Math.random() * memeInserts.length)];
  }

  optimizeRhythm(script) {
    // 优化文案节奏：长短句交错
    return script.map(part => ({
      ...part,
      content: this.optimizeSentences(part.content)
    }));
  }

  optimizeSentences(text) {
    // 简单优化：确保短句为主
    return text
      .split('。')
      .map(s => s.trim())
      .filter(s => s.length > 0)
      .join('。\n')
      .replace(/(.{20,30}[^。])(?!\n)/g, '$1。\n');
  }

  countWords(script) {
    return script.reduce((sum, part) => sum + part.content.length, 0);
  }

  calculateDuration(script) {
    // 按平台语速计算
    const wordsPerSecond = this.platform === 'douyin' ? 4 : 3;
    return Math.ceil(this.countWords(script) / wordsPerSecond);
  }

  identifyViralPoints(script) {
    const viralPoints = [];
    
    script.forEach((part, index) => {
      if (part.name.includes('钩') || part.name.includes('悬念')) {
        viralPoints.push({ position: index, type: 'hook', reason: '开场吸引力' });
      }
      if (part.content.includes('反常识') || part.content.includes('秘密')) {
        viralPoints.push({ position: index, type: 'meme', reason: '记忆点' });
      }
      if (part.name.includes('高潮') || part.name.includes('转折')) {
        viralPoints.push({ position: index, type: 'climax', reason: '情绪峰值' });
      }
    });
    
    return viralPoints;
  }
}

// 运行示例
if (require.main === module) {
  const forge = new StoryForge({
    style: 'knowledge',
    platform: 'douyin',
    duration: 60
  });
  
  const mockTopic = {
    keyword: 'AI取代工作',
    titleOptions: ['AI不会取代你，但会用AI的人会'],
    score: 92
  };
  
  forge.generateContent(mockTopic).then(content => {
    console.log('📝 生成的视频文案：\n');
    console.log(`标题：${content.title}`);
    console.log(`字数：${content.wordCount}`);
    console.log(`预估时长：${content.estimatedDuration}秒`);
    console.log('\n结构：\n');
    
    content.script.forEach((part, i) => {
      console.log(`${i + 1}. [${part.duration}] ${part.name}`);
      console.log(`   ${part.content.substring(0, 100)}...\n`);
    });
  });
}

module.exports = StoryForge;
