#!/usr/bin/env node
/**
 * VideoAlchemist - StyleBible 设定集生成
 * 生成完整的视觉风格指南
 */

class StyleBible {
  constructor(config = {}) {
    this.style = config.style || 'modern'; // modern, retro, minimalist, vibrant
    this.genre = config.genre || 'knowledge'; // knowledge, story, entertainment
  }

  async generateStyleBible(topic, script, options = {}) {
    console.log('🎨 生成视觉设定集...\n');
    
    return {
      overview: this.generateOverview(topic),
      characterDesign: this.designCharacters(topic, script),
      visualStyle: this.defineVisualStyle(),
      colorPalette: this.createColorPalette(),
      typography: this.defineTypography(),
      worldBuilding: this.buildWorld(topic),
      assetList: this.listRequiredAssets(script),
      promptTemplates: this.generatePromptTemplates()
    };
  }

  generateOverview(topic) {
    return {
      title: `${topic.keyword} - 视觉设定集`,
      version: '1.0',
      created: new Date().toISOString(),
      styleDirection: this.getStyleDirection(),
      moodKeywords: this.getMoodKeywords(topic),
      referenceWorks: this.getReferences()
    };
  }

  getStyleDirection() {
    const directions = {
      modern: '现代简约 - 扁平化设计，清晰的信息层级',
      retro: '复古风格 - 胶片质感，怀旧色调',
      minimalist: '极简主义 - 大量留白，核心突出',
      vibrant: '活力鲜艳 - 高饱和度，年轻化表达',
      tech: '科技未来 - 赛博朋克，数据可视化'
    };
    return directions[this.style] || directions.modern;
  }

  getMoodKeywords(topic) {
    const moodMap = {
      'AI取代工作': ['焦虑', '希望', '科技感', '紧迫感'],
      '普通人逆袭': ['励志', '温暖', '成长', '真实'],
      '00后整顿职场': ['叛逆', '爽感', '幽默', '反权威']
    };
    
    return moodMap[topic.keyword] || ['专业', '可信', '亲和'];
  }

  getReferences() {
    const refs = {
      modern: ['Apple 发布会', 'Google Material Design', 'Notion 界面'],
      retro: ['80年代海报', '老电影质感', '复古游戏'],
      minimalist: ['MUJI', '瑞士平面主义', '无印良品'],
      vibrant: ['抖音热门', 'B站鬼畜', '小红书爆款']
    };
    return refs[this.style] || refs.modern;
  }

  designCharacters(topic, script) {
    // 根据内容设计角色设定
    const hasProtagonist = script.some(s => s.name.includes('案例') || s.name.includes('故事'));
    
    if (!hasProtagonist) {
      return {
        protagonist: null,
        guide: this.designGuideCharacter(),
        note: '本视频以主讲人/旁白形式呈现，无需角色设定'
      };
    }

    return {
      protagonist: {
        name: '主角（可命名）',
        age: '25-30岁',
        appearance: '亲和力强，符合目标受众审美',
        personality: ['坚韧', '乐观', '真实'],
        signature: ['特定手势', '口头禅', '标志性表情'],
        arc: '从困境到突破的成长弧线'
      },
      supporting: [
        { role: 'mentor', description: '引导者角色，提供关键建议' },
        { role: 'antagonist', description: '对立面，制造冲突' }
      ]
    };
  }

  designGuideCharacter() {
    return {
      role: '主讲人/向导',
      presentation: '真人出镜或虚拟形象',
      style: '专业但亲和，像朋友一样交流',
      visualCues: ['标志性服装颜色', '固定站位/角度']
    };
  }

  defineVisualStyle() {
    const styles = {
      modern: {
        artDirection: '扁平化插画 + 微渐变',
        shapes: '圆角矩形，柔和曲线',
        textures: '轻微噪点，增加质感',
        effects: '柔和阴影，微动效'
      },
      retro: {
        artDirection: '复古插画，胶片颗粒感',
        shapes: '锐利边角，几何图形',
        textures: '纸张纹理，划痕效果',
        effects: '暗角，色差，老式电视扫描线'
      },
      minimalist: {
        artDirection: '极简图形，大量留白',
        shapes: '基础几何，直线为主',
        textures: '纯色，无纹理',
        effects: '无阴影，硬边切割'
      },
      vibrant: {
        artDirection: '高饱和插画，潮流元素',
        shapes: '不规则，动感线条',
        textures: '涂鸦，喷漆效果',
        effects: '霓虹光效，动态模糊'
      }
    };
    
    return styles[this.style] || styles.modern;
  }

  createColorPalette() {
    const palettes = {
      modern: {
        primary: '#1A1A2E',    // 深海军蓝
        secondary: '#16213E',  // 深蓝
        accent: '#E94560',     // 活力红
        background: '#F5F5F5', // 浅灰白
        text: '#333333',       // 深灰
        textLight: '#666666'   // 中灰
      },
      retro: {
        primary: '#D4A373',    // 暖棕
        secondary: '#FAEDCD',  // 米黄
        accent: '#CCD5AE',     // 橄榄绿
        background: '#FEFAE0', // 浅黄
        text: '#5C4033',       // 深棕
        textLight: '#8B7355'   // 中棕
      },
      minimalist: {
        primary: '#000000',    // 纯黑
        secondary: '#333333',  // 深灰
        accent: '#FF0000',     // 点缀红
        background: '#FFFFFF', // 纯白
        text: '#000000',       // 纯黑
        textLight: '#666666'   // 灰
      },
      vibrant: {
        primary: '#FF006E',    // 玫红
        secondary: '#FB5607',  // 橙
        accent: '#8338EC',     // 紫
        background: '#FFBE0B', // 黄
        text: '#1A1A2E',       // 深海军蓝
        textLight: '#3A86FF'   // 蓝
      }
    };
    
    const palette = palettes[this.style] || palettes.modern;
    
    return {
      colors: palette,
      usage: {
        primary: '主标题、关键按钮',
        secondary: '次要信息、背景区块',
        accent: '强调、CTA、高亮',
        background: '页面背景',
        text: '正文文字',
        textLight: '辅助文字、说明'
      },
      combinations: this.generateColorCombos(palette)
    };
  }

  generateColorCombos(palette) {
    return [
      { name: '标准', fg: palette.text, bg: palette.background, accent: palette.accent },
      { name: '强调', fg: palette.background, bg: palette.primary, accent: palette.accent },
      { name: '警告', fg: palette.text, bg: '#FFF3CD', accent: '#DC3545' }
    ];
  }

  defineTypography() {
    return {
      title: {
        font: '思源黑体 Bold / Montserrat Bold',
        size: '48-72px',
        weight: '700',
        letterSpacing: '-0.02em',
        lineHeight: '1.2'
      },
      subtitle: {
        font: '思源黑体 Medium / Montserrat SemiBold',
        size: '32-48px',
        weight: '600',
        letterSpacing: '-0.01em',
        lineHeight: '1.3'
      },
      body: {
        font: '思源黑体 Regular / Inter Regular',
        size: '24-32px',
        weight: '400',
        letterSpacing: '0',
        lineHeight: '1.5'
      },
      caption: {
        font: '思源黑体 Light / Inter Light',
        size: '18-24px',
        weight: '300',
        letterSpacing: '0.02em',
        lineHeight: '1.4'
      },
      rules: [
        '移动端最小字号：18px',
        '正文每行25-35个中文字符',
        '标题与正文对比度至少3:1',
        '重要信息用颜色+粗细双重强调'
      ]
    };
  }

  buildWorld(topic) {
    return {
      setting: {
        time: '当代/近未来',
        place: '都市/线上空间',
        atmosphere: this.getMoodKeywords(topic).join('、')
      },
      visualMotifs: this.getVisualMotifs(topic),
      recurringElements: [
        '品牌Logo水印',
        '固定转场动画',
        '标志性BGM片段'
      ]
    };
  }

  getVisualMotifs(topic) {
    const motifs = {
      'AI取代工作': ['代码雨', '机器人剪影', '数据流', '人脑与芯片'],
      '普通人逆袭': ['阶梯/上升箭头', '曙光', '城市夜景', '办公桌'],
      '00后整顿职场': ['咖啡杯', '笔记本电脑', '表情包', '办公室场景']
    };
    
    return motifs[topic.keyword] || ['几何图形', '渐变光效'];
  }

  listRequiredAssets(script) {
    const assets = {
      images: [],
      icons: [],
      animations: [],
      audio: []
    };
    
    script.forEach(part => {
      if (part.name.includes('开场')) {
        assets.images.push('封面图/开场背景');
        assets.animations.push('标题入场动画');
      }
      if (part.name.includes('知识') || part.name.includes('信息')) {
        assets.icons.push('信息图标集');
        assets.images.push('信息图表背景');
      }
      if (part.name.includes('案例') || part.name.includes('故事')) {
        assets.images.push('场景插画/照片');
        assets.audio.push('情节音效');
      }
    });
    
    return assets;
  }

  generatePromptTemplates() {
    return {
      forMidjourney: this.getMidjourneyPrompts(),
      forStableDiffusion: this.getSDPrompts(),
      forDALLE: this.getDALLEPrompts()
    };
  }

  getMidjourneyPrompts() {
    const baseStyle = this.style === 'modern' ? 'flat design, minimalistic' :
                      this.style === 'retro' ? 'retro style, film grain, vintage' :
                      this.style === 'vibrant' ? 'vibrant colors, dynamic, energetic' :
                      'minimalist, clean, lots of white space';
    
    return {
      cover: `${baseStyle}, video cover, bold typography, --ar 9:16 --v 6`,
      scene: `${baseStyle}, scene illustration, storytelling, --ar 16:9 --v 6`,
      character: `${baseStyle}, character design, friendly, professional, --ar 1:1 --v 6`
    };
  }

  getSDPrompts() {
    return {
      cover: 'masterpiece, best quality, video thumbnail, modern design, text space',
      scene: 'detailed illustration, scene, storytelling, high quality',
      character: 'character portrait, professional, friendly expression, detailed'
    };
  }

  getDALLEPrompts() {
    return {
      cover: `A modern video cover design with ${this.style} style, featuring bold text and clean layout`,
      scene: `An illustration scene in ${this.style} style, suitable for video content`,
      icon: `A set of icons in ${this.style} style, for video infographics`
    };
  }

  exportToMarkdown() {
    // 生成Markdown格式的设定集文档
    return `# 视觉设定集

## 概述
...
`;
  }
}

// 运行示例
if (require.main === module) {
  const bible = new StyleBible({
    style: 'modern',
    genre: 'knowledge'
  });
  
  const mockTopic = { keyword: 'AI取代工作' };
  const mockScript = [
    { name: '开场钩', content: 'AI不会取代你...' },
    { name: '核心知识', content: 'AI不会取代所有人...' }
  ];
  
  bible.generateStyleBible(mockTopic, mockScript).then(bible => {
    console.log('🎨 视觉设定集生成完成：\n');
    console.log(`风格方向：${bible.overview.styleDirection}`);
    console.log(`情绪关键词：${bible.overview.moodKeywords.join(', ')}`);
    console.log(`\n配色方案：`);
    console.log(`  主色：${bible.colorPalette.colors.primary}`);
    console.log(`  强调色：${bible.colorPalette.colors.accent}`);
    console.log(`\n字体规范：`);
    console.log(`  标题：${bible.typography.title.font}`);
    console.log(`  正文：${bible.typography.body.font}`);
  });
}

module.exports = StyleBible;
