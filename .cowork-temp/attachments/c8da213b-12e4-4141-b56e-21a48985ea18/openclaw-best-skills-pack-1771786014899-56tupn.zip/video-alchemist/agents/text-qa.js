#!/usr/bin/env node
/**
 * TextQA - 文本质检员 Sub-agent
 * 检查文案质量、可读性、viral 潜力
 */

class TextQA {
  constructor(config = {}) {
    this.threshold = config.threshold || 80;
    this.strictMode = config.strictMode || false;
  }

  async check(script, options = {}) {
    const results = {
      score: 0,
      passed: false,
      checks: {},
      issues: [],
      suggestions: []
    };

    // 1. 可读性检查
    results.checks.readability = this.checkReadability(script);
    
    // 2. 节奏感检查
    results.checks.rhythm = this.checkRhythm(script);
    
    // 3. 情绪密度检查
    results.checks.emotion = this.checkEmotionDensity(script);
    
    // 4. 钩子质量检查
    results.checks.hook = this.checkHook(script);
    
    // 5. 互动设计检查
    results.checks.interaction = this.checkInteraction(script);

    // 计算总分
    results.score = this.calculateScore(results.checks);
    results.passed = results.score >= this.threshold;

    // 收集问题和建议
    this.collectIssues(results);

    return results;
  }

  checkReadability(script) {
    const sentences = script.split(/[。！？]/).filter(s => s.trim());
    const longSentences = sentences.filter(s => s.length > 20);
    const paragraphs = script.split('\n\n').filter(p => p.trim());
    const longParagraphs = paragraphs.filter(p => p.split(/[。！？]/).length > 3);

    const score = Math.max(0, 100 - (longSentences.length * 5) - (longParagraphs.length * 10));

    return {
      score,
      totalSentences: sentences.length,
      longSentences: longSentences.length,
      longParagraphs: longParagraphs.length,
      passed: score >= 80
    };
  }

  checkRhythm(script) {
    const sentences = script.split(/[。！？]/).filter(s => s.trim());
    const lengths = sentences.map(s => s.length);
    const avgLength = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    const variance = lengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) / lengths.length;
    
    // 方差越大，节奏感越好（长短句交错）
    const score = Math.min(100, 60 + variance / 10);

    return {
      score: Math.round(score),
      avgSentenceLength: avgLength.toFixed(1),
      variance: variance.toFixed(1),
      passed: score >= 75
    };
  }

  checkEmotionDensity(script) {
    const emotionKeywords = [
      '焦虑', '希望', '恐惧', '期待', '愤怒', '感动',
      '震惊', '心疼', '温暖', '绝望', '激动', '平静',
      '紧张', '放松', '快乐', '悲伤', '兴奋', '孤独'
    ];
    
    const foundEmotions = emotionKeywords.filter(word => script.includes(word));
    const emotionCount = foundEmotions.length;
    
    // 估算时长（按4字/秒计算）
    const estimatedDuration = script.length / 4;
    const emotionDensity = emotionCount / (estimatedDuration / 30); // 每30秒的情绪点
    
    const score = Math.min(100, emotionDensity * 40);

    return {
      score: Math.round(score),
      emotionCount,
      foundEmotions,
      estimatedDuration: Math.round(estimatedDuration),
      passed: score >= 70
    };
  }

  checkHook(script) {
    const firstSentence = script.split(/[。！？]/)[0] || '';
    
    const hookPatterns = [
      { pattern: /你知道吗|你是否|你有没有/, score: 85, type: 'question' },
      { pattern: /震惊|惊人|不可思议|竟然/, score: 90, type: 'shock' },
      { pattern: /99%|90%|大多数人|所有人/, score: 88, type: 'statistics' },
      { pattern: /秘密|真相|揭秘|内幕/, score: 85, type: 'secret' },
      { pattern: /为什么|如何|怎样/, score: 80, type: 'curiosity' }
    ];

    let bestMatch = null;
    for (const hook of hookPatterns) {
      if (hook.pattern.test(firstSentence)) {
        if (!bestMatch || hook.score > bestMatch.score) {
          bestMatch = hook;
        }
      }
    }

    const score = bestMatch ? bestMatch.score : 50;

    return {
      score,
      firstSentence: firstSentence.substring(0, 50),
      hookType: bestMatch ? bestMatch.type : 'none',
      hasStrongHook: score >= 80,
      passed: score >= 75
    };
  }

  checkInteraction(script) {
    const interactionPatterns = [
      { pattern: /评论区|留言|说说你的|你怎么看/, score: 85, type: 'comment' },
      { pattern: /点赞|收藏|转发|分享/, score: 80, type: 'action' },
      { pattern: /你是不是也|有没有人和我一样/, score: 88, type: 'empathy' },
      { pattern: /槽点|争议|反对/, score: 85, type: 'controversy' }
    ];

    const foundPatterns = interactionPatterns.filter(p => p.pattern.test(script));
    const score = foundPatterns.length > 0 
      ? Math.max(...foundPatterns.map(p => p.score)) 
      : 40;

    return {
      score,
      foundPatterns: foundPatterns.map(p => p.type),
      passed: score >= 70
    };
  }

  calculateScore(checks) {
    const weights = {
      readability: 0.20,
      rhythm: 0.15,
      emotion: 0.20,
      hook: 0.25,
      interaction: 0.20
    };

    let totalScore = 0;
    for (const [key, weight] of Object.entries(weights)) {
      totalScore += (checks[key]?.score || 0) * weight;
    }

    return Math.round(totalScore);
  }

  collectIssues(results) {
    for (const [checkName, checkResult] of Object.entries(results.checks)) {
      if (!checkResult.passed) {
        results.issues.push({
          check: checkName,
          score: checkResult.score,
          message: this.getIssueMessage(checkName, checkResult)
        });
      }
    }

    // 生成建议
    results.suggestions = this.generateSuggestions(results.checks);
  }

  getIssueMessage(checkName, result) {
    const messages = {
      readability: `可读性不足：有${result.longSentences}个长句和${result.longParagraphs}个长段落`,
      rhythm: '节奏感欠佳：句子长度变化不够',
      emotion: `情绪密度偏低：仅找到${result.emotionCount}个情绪点`,
      hook: '开场钩子不够强，建议增加冲击力',
      interaction: '缺少互动设计，建议增加评论引导'
    };
    return messages[checkName] || `${checkName}检查未通过`;
  }

  generateSuggestions(checks) {
    const suggestions = [];

    if (checks.readability && !checks.readability.passed) {
      suggestions.push('将长句拆分为短句，每句控制在15-20字');
      suggestions.push('每段不超过3句话，增加留白');
    }

    if (checks.rhythm && !checks.rhythm.passed) {
      suggestions.push('长短句交错使用：短句（10字）+ 长句（20字）+ 短句（8字）');
    }

    if (checks.emotion && !checks.emotion.passed) {
      suggestions.push('每30秒增加一个情绪词：焦虑、希望、震惊、感动等');
    }

    if (checks.hook && !checks.hook.passed) {
      suggestions.push('开场3秒使用反常识或提问："99%的人都错了..."或"你知道吗..."');
    }

    if (checks.interaction && !checks.interaction.passed) {
      suggestions.push('结尾增加互动引导："你是不是也经历过？评论区聊聊"');
      suggestions.push('在文案中预埋槽点，引发评论争议');
    }

    return suggestions;
  }
}

// CLI 接口
if (require.main === module) {
  const qa = new TextQA({ threshold: 80 });
  
  const testScript = process.argv[2] || `AI不会取代你，但会用AI的人会。

你是不是也担心被AI取代？刷到别人逆袭的视频，心里焦虑却不知道从何开始？

先说结论：AI不会取代所有人，但会取代那些重复性强、规则明确的工作。第一类危险岗位：数据录入、简单翻译、基础客服。第二类过渡岗位：初级设计、基础写作、表格处理。第三类安全岗位：需要创意、情感连接、复杂决策的工作。

所以，AI取代工作不是不可能，而是你需要正确的方法。记住这3点：选对赛道、持续学习、快速执行。你同意吗？评论区说说你的看法。`;

  qa.check(testScript).then(result => {
    console.log('📝 文本质检报告');
    console.log('================');
    console.log(`总分：${result.score}/100`);
    console.log(`状态：${result.passed ? '✅ 通过' : '❌ 未通过'}`);
    console.log('');
    
    console.log('详细检查：');
    for (const [name, check] of Object.entries(result.checks)) {
      console.log(`  ${name}: ${check.score}分 ${check.passed ? '✓' : '✗'}`);
    }
    
    if (result.issues.length > 0) {
      console.log('\n问题：');
      result.issues.forEach(issue => {
        console.log(`  ⚠️  ${issue.message}`);
      });
    }
    
    if (result.suggestions.length > 0) {
      console.log('\n建议：');
      result.suggestions.forEach((s, i) => {
        console.log(`  ${i + 1}. ${s}`);
      });
    }
  });
}

module.exports = TextQA;
