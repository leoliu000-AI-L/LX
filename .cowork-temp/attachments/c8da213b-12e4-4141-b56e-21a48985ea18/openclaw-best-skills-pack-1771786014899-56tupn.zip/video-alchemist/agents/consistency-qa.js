#!/usr/bin/env node
/**
 * ConsistencyQA - 一致性质检员 Sub-agent
 * 检查各步骤产出的一致性
 */

class ConsistencyQA {
  constructor(config = {}) {
    this.threshold = config.threshold || 90;
    this.strictMode = config.strictMode || false;
  }

  async check(inputs, options = {}) {
    // inputs: [step1Result, step2Result, ...]
    const [prevStep, currentStep] = inputs;
    
    const results = {
      score: 0,
      passed: false,
      checks: {},
      drift: 0,
      issues: [],
      suggestions: []
    };

    // 1. 检查主题一致性
    results.checks.topicAlignment = this.checkTopicAlignment(prevStep, currentStep);
    
    // 2. 检查情绪一致性
    results.checks.emotionConsistency = this.checkEmotionConsistency(prevStep, currentStep);
    
    // 3. 检查角色一致性
    results.checks.characterConsistency = this.checkCharacterConsistency(prevStep, currentStep);
    
    // 4. 检查风格一致性
    results.checks.styleConsistency = this.checkStyleConsistency(prevStep, currentStep);

    // 计算总分和漂移
    results.score = this.calculateScore(results.checks);
    results.drift = this.calculateDrift(results.checks);
    results.passed = results.score >= this.threshold && results.drift < 0.2;

    // 收集问题
    this.collectIssues(results);

    return results;
  }

  checkTopicAlignment(prev, current) {
    // 提取关键词进行比较
    const prevKeywords = this.extractKeywords(prev);
    const currentKeywords = this.extractKeywords(current);
    
    const overlap = prevKeywords.filter(k => currentKeywords.includes(k));
    const similarity = overlap.length / Math.max(prevKeywords.length, currentKeywords.length);
    
    const score = Math.round(similarity * 100);

    return {
      score,
      prevKeywords: prevKeywords.slice(0, 5),
      currentKeywords: currentKeywords.slice(0, 5),
      overlap,
      similarity: similarity.toFixed(2),
      passed: score >= 85
    };
  }

  checkEmotionConsistency(prev, current) {
    const emotionMap = {
      '焦虑': -2, '绝望': -3, '恐惧': -2,
      '平静': 0, '思考': 0,
      '希望': 2, '励志': 3, '感动': 2,
      '兴奋': 3, '激动': 2
    };

    const prevEmotion = this.detectEmotion(prev);
    const currentEmotion = this.detectEmotion(current);
    
    const prevValence = emotionMap[prevEmotion] || 0;
    const currentValence = emotionMap[currentEmotion] || 0;
    const diff = Math.abs(prevValence - currentValence);
    
    // 情绪变化不应超过2个等级
    const score = Math.max(0, 100 - diff * 25);

    return {
      score,
      prevEmotion,
      currentEmotion,
      emotionShift: diff,
      passed: score >= 75
    };
  }

  checkCharacterConsistency(prev, current) {
    // 检查角色设定是否一致
    const prevCharacters = this.extractCharacters(prev);
    const currentCharacters = this.extractCharacters(current);

    if (prevCharacters.length === 0) {
      return { score: 100, passed: true, note: '无角色设定' };
    }

    const consistent = prevCharacters.every(pc => 
      currentCharacters.some(cc => this.similarCharacter(pc, cc))
    );

    const score = consistent ? 95 : 60;

    return {
      score,
      prevCharacters: prevCharacters.map(c => c.name),
      currentCharacters: currentCharacters.map(c => c.name),
      consistent,
      passed: consistent
    };
  }

  checkStyleConsistency(prev, current) {
    // 检查视觉/语言风格
    const styleAttributes = ['formal', 'casual', 'humorous', 'serious', 'warm', 'cool'];
    
    const prevStyle = this.detectStyle(prev);
    const currentStyle = this.detectStyle(current);
    
    const match = prevStyle === currentStyle;
    const score = match ? 95 : 70;

    return {
      score,
      prevStyle,
      currentStyle,
      match,
      passed: score >= 80
    };
  }

  extractKeywords(text) {
    if (typeof text !== 'string') {
      text = JSON.stringify(text);
    }
    
    // 简单关键词提取
    const words = text.match(/[\u4e00-\u9fa5]{2,6}/g) || [];
    const freq = {};
    words.forEach(w => freq[w] = (freq[w] || 0) + 1);
    
    return Object.entries(freq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([word]) => word);
  }

  detectEmotion(text) {
    const emotionKeywords = {
      '焦虑': ['焦虑', '担心', '害怕', '压力'],
      '绝望': ['绝望', '无助', '放弃', '毁灭'],
      '希望': ['希望', '期待', '相信', '未来'],
      '励志': ['努力', '坚持', '奋斗', '成功'],
      '感动': ['感动', '温暖', '泪目', '心疼'],
      '平静': ['平静', '冷静', '理性', '客观']
    };

    const textStr = typeof text === 'string' ? text : JSON.stringify(text);
    
    for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
      if (keywords.some(k => textStr.includes(k))) {
        return emotion;
      }
    }
    
    return 'neutral';
  }

  extractCharacters(content) {
    // 从内容中提取角色设定
    const characters = [];
    
    if (content.characterDesign) {
      characters.push(...content.characterDesign);
    }
    
    if (content.protagonist) {
      characters.push(content.protagonist);
    }
    
    return characters;
  }

  similarCharacter(char1, char2) {
    // 判断两个角色是否相似
    const nameMatch = char1.name === char2.name;
    const ageMatch = Math.abs((char1.age || 0) - (char2.age || 0)) < 5;
    return nameMatch || ageMatch;
  }

  detectStyle(content) {
    const text = typeof content === 'string' ? content : JSON.stringify(content);
    
    if (/幽默|搞笑|梗|段子/.test(text)) return 'humorous';
    if (/严肃|深刻|沉重/.test(text)) return 'serious';
    if (/正式|官方|规范/.test(text)) return 'formal';
    if (/温暖|治愈|感动/.test(text)) return 'warm';
    
    return 'casual';
  }

  calculateScore(checks) {
    const weights = {
      topicAlignment: 0.30,
      emotionConsistency: 0.25,
      characterConsistency: 0.25,
      styleConsistency: 0.20
    };

    let total = 0;
    for (const [key, weight] of Object.entries(weights)) {
      total += (checks[key]?.score || 0) * weight;
    }

    return Math.round(total);
  }

  calculateDrift(checks) {
    // 计算整体漂移程度
    const drifts = [
      1 - (checks.topicAlignment?.similarity || 0),
      (checks.emotionConsistency?.emotionShift || 0) / 5,
      checks.characterConsistency?.consistent ? 0 : 0.3,
      checks.styleConsistency?.match ? 0 : 0.2
    ];
    
    return drifts.reduce((a, b) => a + b, 0) / drifts.length;
  }

  collectIssues(results) {
    for (const [checkName, checkResult] of Object.entries(results.checks)) {
      if (!checkResult.passed) {
        results.issues.push({
          check: checkName,
          severity: checkResult.score < 60 ? 'high' : 'medium',
          message: this.getIssueMessage(checkName, checkResult)
        });
      }
    }

    results.suggestions = this.generateSuggestions(results);
  }

  getIssueMessage(checkName, result) {
    const messages = {
      topicAlignment: `主题偏离：相似度仅${result.similarity * 100}%`,
      emotionConsistency: `情绪突变：从"${result.prevEmotion}"变为"${result.currentEmotion}"`,
      characterConsistency: '角色不一致：设定前后矛盾',
      styleConsistency: `风格突变：从"${result.prevStyle}"变为"${result.currentStyle}"`
    };
    return messages[checkName] || `${checkName}检查未通过`;
  }

  generateSuggestions(results) {
    const suggestions = [];

    if (!results.checks.topicAlignment?.passed) {
      suggestions.push('调整后续内容，回归原始主题');
      suggestions.push(`核心关键词应保持：${results.checks.topicAlignment?.prevKeywords?.join(', ')}`);
    }

    if (!results.checks.emotionConsistency?.passed) {
      suggestions.push('情绪转折过于突兀，建议增加过渡');
    }

    if (!results.checks.characterConsistency?.passed) {
      suggestions.push('检查角色设定，确保前后统一');
    }

    if (!results.checks.styleConsistency?.passed) {
      suggestions.push('调整表达方式，保持风格统一');
    }

    return suggestions;
  }
}

// CLI 接口
if (require.main === module) {
  const qa = new ConsistencyQA({ threshold: 90 });
  
  const prevStep = {
    keyword: 'AI取代工作',
    angle: '焦虑转希望',
    emotion: '焦虑'
  };
  
  const currentStep = {
    text: 'AI不会取代你，但会用AI的人会。你是不是也担心被AI取代？',
    emotion: '希望'
  };

  qa.check([prevStep, currentStep]).then(result => {
    console.log('🔍 一致性质检报告');
    console.log('==================');
    console.log(`总分：${result.score}/100`);
    console.log(`漂移度：${(result.drift * 100).toFixed(1)}%`);
    console.log(`状态：${result.passed ? '✅ 通过' : '❌ 未通过'}`);
    console.log('');
    
    console.log('详细检查：');
    for (const [name, check] of Object.entries(result.checks)) {
      console.log(`  ${name}: ${check.score}分 ${check.passed ? '✓' : '✗'}`);
    }
    
    if (result.issues.length > 0) {
      console.log('\n问题：');
      result.issues.forEach(issue => {
        console.log(`  ${issue.severity === 'high' ? '🔴' : '🟡'} ${issue.message}`);
      });
    }
  });
}

module.exports = ConsistencyQA;
