#!/usr/bin/env node
/**
 * VideoAlchemist - ShotDesign 分镜脚本
 * 将文案转化为详细的分镜描述
 */

class ShotDesign {
  constructor(config = {}) {
    this.platform = config.platform || 'douyin';
    this.aspectRatio = config.aspectRatio || '9:16';
    this.resolution = config.resolution || '1080x1920';
  }

  async generateShotList(script, options = {}) {
    console.log('🎬 生成分镜脚本...\n');
    
    const shots = [];
    let currentTime = 0;
    
    for (const part of script) {
      const shot = this.designShot(part, currentTime);
      shots.push(shot);
      currentTime += this.parseDuration(part.duration);
    }
    
    // 添加转场
    const shotsWithTransitions = this.addTransitions(shots);
    
    // 添加视觉提示
    const enhancedShots = this.addVisualCues(shotsWithTransitions);
    
    return {
      shots: enhancedShots,
      summary: {
        totalShots: enhancedShots.length,
        totalDuration: currentTime,
        keyVisuals: this.identifyKeyVisuals(enhancedShots),
        textOverlays: this.countTextOverlays(enhancedShots)
      }
    };
  }

  designShot(part, startTime) {
    const duration = this.parseDuration(part.duration);
    
    return {
      id: `shot_${String(startTime).padStart(3, '0')}`,
      timecode: {
        start: this.formatTime(startTime),
        end: this.formatTime(startTime + duration),
        duration: duration
      },
      type: this.determineShotType(part),
      visual: this.designVisual(part),
      audio: this.designAudio(part),
      text: this.designTextOverlay(part),
      camera: this.designCameraMovement(part)
    };
  }

  determineShotType(part) {
    const typeMap = {
      '开场钩': 'impact',
      '痛点共鸣': 'medium',
      '核心知识': 'info_graphic',
      '案例佐证': 'story',
      '总结升华': 'close_up',
      '互动引导': 'call_to_action',
      '悬念开场': 'mystery',
      '背景铺垫': 'establishing',
      '冲突升级': 'dynamic',
      '高潮转折': 'dramatic',
      '结局落点': 'emotional',
      '留白思考': 'minimal'
    };
    
    return typeMap[part.name] || 'medium';
  }

  designVisual(part) {
    const designs = {
      impact: {
        description: '大字标题冲击画面，黑底白字或高对比配色',
        elements: ['大标题', '动态文字效果', '背景光效'],
        color: '高对比（黑底白字或反色）',
        mood: '紧张、冲击'
      },
      medium: {
        description: '主讲人出镜，或关键信息展示',
        elements: ['主讲人', '关键信息卡片'],
        color: '品牌主色',
        mood: '亲切、可信'
      },
      info_graphic: {
        description: '信息图表、数据可视化',
        elements: ['图表', '图标', '进度条', '对比图'],
        color: '信息层级配色',
        mood: '专业、清晰'
      },
      story: {
        description: '场景画面或角色动画',
        elements: ['场景插画', '角色动画', '情节画面'],
        color: '故事氛围色',
        mood: '叙事、沉浸'
      },
      close_up: {
        description: '特写镜头，强调表情或关键信息',
        elements: ['面部特写', '手势特写', '关键文字特写'],
        color: '温暖或激励色调',
        mood: '真诚、感染'
      },
      call_to_action: {
        description: '引导互动画面',
        elements: ['关注按钮动画', '评论区截图', '点赞手势'],
        color: '行动号召色（通常红/橙）',
        mood: '积极、引导'
      }
    };
    
    const type = this.determineShotType(part);
    return designs[type] || designs.medium;
  }

  designAudio(part) {
    const audios = {
      '开场钩': { bgm: '悬疑/紧张', volume: '80%', sfx: '重低音冲击' },
      '痛点共鸣': { bgm: '柔和/共情', volume: '40%', sfx: '轻微氛围音' },
      '核心知识': { bgm: '轻快/积极', volume: '30%', sfx: '无' },
      '案例佐证': { bgm: '叙事/情感', volume: '50%', sfx: '情节音效' },
      '总结升华': { bgm: '激昂/振奋', volume: '60%', sfx: '渐进鼓点' },
      '互动引导': { bgm: '轻快/活泼', volume: '70%', sfx: '提示音效' }
    };
    
    return audios[part.name] || { bgm: '中性', volume: '40%', sfx: '无' };
  }

  designTextOverlay(part) {
    const texts = {
      '开场钩': {
        content: this.extractKeySentence(part.content, 10),
        style: '大字标题，居中，动态入场',
        animation: '弹跳/冲击入场',
        position: 'center'
      },
      '痛点共鸣': {
        content: this.extractKeySentence(part.content, 15),
        style: '中等字幕，情绪化配色',
        animation: '渐显',
        position: 'bottom'
      },
      '核心知识': {
        content: this.extractKeySentence(part.content, 20),
        style: '要点列表，图标标注',
        animation: '逐个出现',
        position: 'center-left'
      },
      '案例佐证': {
        content: '案例时间/地点标注',
        style: '小字幕，辅助信息',
        animation: '淡入',
        position: 'bottom'
      },
      '总结升华': {
        content: this.extractKeySentence(part.content, 15),
        style: '金句卡片，突出显示',
        animation: '放大强调',
        position: 'center'
      },
      '互动引导': {
        content: '评论区等你/点个赞',
        style: '引导按钮样式',
        animation: '闪烁/跳动',
        position: 'bottom-center'
      }
    };
    
    return texts[part.name] || {
      content: part.content.substring(0, 20),
      style: '标准字幕',
      animation: '渐显',
      position: 'bottom'
    };
  }

  designCameraMovement(part) {
    const movements = {
      '开场钩': '快速推进（Zoom In）',
      '痛点共鸣': '轻微推拉（Breathing）',
      '核心知识': '静态或慢速平移',
      '案例佐证': '跟随叙事节奏',
      '总结升华': '缓慢拉近',
      '互动引导': '轻微抖动吸引注意'
    };
    
    return movements[part.name] || '静态';
  }

  addTransitions(shots) {
    return shots.map((shot, index) => {
      if (index === 0) return { ...shot, transition: 'hard_cut' };
      
      const prevType = shots[index - 1].type;
      const currType = shot.type;
      
      const transition = this.selectTransition(prevType, currType);
      
      return {
        ...shot,
        transition: transition
      };
    });
  }

  selectTransition(from, to) {
    // 根据前后镜头类型选择转场
    if (from === 'impact' || to === 'impact') {
      return 'cut_with_impact';
    }
    if (from === 'story' && to === 'info_graphic') {
      return 'dissolve';
    }
    if (from === 'info_graphic' && to === 'close_up') {
      return 'slide';
    }
    return 'smooth_fade';
  }

  addVisualCues(shots) {
    return shots.map(shot => ({
      ...shot,
      visualCues: this.generateVisualCues(shot)
    }));
  }

  generateVisualCues(shot) {
    const cues = [];
    
    // 根据镜头类型添加视觉提示
    if (shot.type === 'info_graphic') {
      cues.push('📊 数据可视化：柱状图/饼图');
      cues.push('🎨 配色：信息层级区分');
    }
    
    if (shot.type === 'story') {
      cues.push('🎭 角色表情特写');
      cues.push('🌆 场景氛围营造');
    }
    
    if (shot.text.animation.includes('动态')) {
      cues.push('✨ 文字动效：入场/强调/退场');
    }
    
    return cues;
  }

  parseDuration(durationStr) {
    // 解析 "0-3s" 格式的时长
    const match = durationStr.match(/(\d+)-(\d+)s/);
    if (match) {
      return parseInt(match[2]) - parseInt(match[1]);
    }
    return 5; // 默认5秒
  }

  formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  extractKeySentence(content, maxLength) {
    // 提取关键句（简化实现）
    const sentences = content.split(/[。！？]/);
    for (const sentence of sentences) {
      if (sentence.length <= maxLength && sentence.length > 5) {
        return sentence.trim();
      }
    }
    return content.substring(0, maxLength);
  }

  identifyKeyVisuals(shots) {
    return shots
      .filter(s => ['impact', 'info_graphic', 'dramatic'].includes(s.type))
      .map(s => ({
        time: s.timecode.start,
        type: s.type,
        description: s.visual.description
      }));
  }

  countTextOverlays(shots) {
    return shots.filter(s => s.text && s.text.content).length;
  }

  exportToFormat(shots, format = 'markdown') {
    if (format === 'markdown') {
      return this.exportToMarkdown(shots);
    }
    if (format === 'json') {
      return JSON.stringify(shots, null, 2);
    }
    return shots;
  }

  exportToMarkdown(shots) {
    let md = '# 分镜脚本\n\n';
    md += `平台：${this.platform} | 画幅：${this.aspectRatio}\n\n`;
    
    shots.forEach(shot => {
      md += `## ${shot.id} [${shot.timecode.start} - ${shot.timecode.end}]\n\n`;
      md += `- **类型**：${shot.type}\n`;
      md += `- **画面**：${shot.visual.description}\n`;
      md += `- **文案**：${shot.text.content}\n`;
      md += `- **BGM**：${shot.audio.bgm}（${shot.audio.volume}）\n`;
      md += `- **运镜**：${shot.camera}\n`;
      md += `- **转场**：${shot.transition}\n\n`;
    });
    
    return md;
  }
}

// 运行示例
if (require.main === module) {
  const designer = new ShotDesign({
    platform: 'douyin',
    aspectRatio: '9:16'
  });
  
  const mockScript = [
    { name: '开场钩', duration: '0-3s', content: 'AI不会取代你，但会用AI的人会。' },
    { name: '痛点共鸣', duration: '3-8s', content: '你是不是也担心被AI取代？' },
    { name: '核心知识', duration: '8-40s', content: 'AI不会取代所有人，但会取代重复性强的工作。' }
  ];
  
  designer.generateShotList(mockScript).then(result => {
    console.log('🎬 分镜脚本生成完成：\n');
    console.log(`总镜头数：${result.summary.totalShots}`);
    console.log(`总时长：${result.summary.totalDuration}秒`);
    console.log(`关键视觉：${result.summary.keyVisuals.length}个\n`);
    
    console.log('镜头列表：\n');
    result.shots.forEach(shot => {
      console.log(`${shot.id} [${shot.timecode.start}-${shot.timecode.end}]`);
      console.log(`  画面：${shot.visual.description}`);
      console.log(`  文案：${shot.text.content}`);
      console.log(`  转场：${shot.transition}\n`);
    });
  });
}

module.exports = ShotDesign;
