#!/usr/bin/env node
/**
 * VideoAlchemist - TopicMiner 选题引擎
 * 从多平台热点挖掘高潜力视频选题
 */

class TopicMiner {
  constructor(config = {}) {
    this.platforms = config.platforms || ['douyin', 'bilibili', 'xiaohongshu', 'weibo'];
    this.minHeatScore = config.minHeatScore || 70;
    this.maxCompetition = config.maxCompetition || 50;
  }

  async mineTopics(options = {}) {
    console.log('🔍 启动选题挖掘...\n');
    
    // 1. 收集热点数据
    const hotTrends = await this.fetchHotTrends();
    
    // 2. 分析受众画像
    const audienceProfile = await this.analyzeAudience(options.targetAudience);
    
    // 3. 竞争分析
    const competitionData = await this.analyzeCompetition(hotTrends);
    
    // 4. 评分排序
    const scoredTopics = this.scoreTopics(hotTrends, audienceProfile, competitionData);
    
    // 5. 生成差异化角度
    const finalTopics = this.generateAngles(scoredTopics.slice(0, 10));
    
    return {
      topics: finalTopics,
      summary: {
        totalScanned: hotTrends.length,
        highPotential: finalTopics.filter(t => t.score >= 80).length,
        recommended: finalTopics.slice(0, 3)
      }
    };
  }

  async fetchHotTrends() {
    // 模拟多平台热点抓取
    const mockTrends = [
      {
        id: 'trend_001',
        keyword: 'AI取代工作',
        platform: 'douyin',
        heat: 95,
        views: '1200w',
        growth: '+45%/24h',
        sentiment: '焦虑+好奇'
      },
      {
        id: 'trend_002',
        keyword: '普通人逆袭',
        platform: 'xiaohongshu',
        heat: 88,
        views: '800w',
        growth: '+32%/24h',
        sentiment: '渴望+共鸣'
      },
      {
        id: 'trend_003',
        keyword: '00后整顿职场',
        platform: 'bilibili',
        heat: 82,
        views: '650w',
        growth: '+28%/24h',
        sentiment: '爽点+争议'
      }
    ];
    
    return mockTrends;
  }

  analyzeAudience(targetAudience) {
    const profiles = {
      'gen-z': {
        age: '18-25',
        preferences: ['快节奏', '强情绪', '身份认同', '反权威'],
        platforms: ['douyin', 'bilibili'],
        activeHours: '19:00-01:00'
      },
      'millennials': {
        age: '26-35',
        preferences: ['实用价值', '情感共鸣', '成长话题'],
        platforms: ['xiaohongshu', 'weibo'],
        activeHours: '12:00-14:00, 20:00-22:00'
      },
      'general': {
        age: 'all',
        preferences: ['猎奇', '实用', '娱乐'],
        platforms: ['all'],
        activeHours: 'varied'
      }
    };
    
    return profiles[targetAudience] || profiles['general'];
  }

  async analyzeCompetition(trends) {
    // 模拟竞争度分析
    return trends.map(trend => ({
      ...trend,
      competitionCount: Math.floor(Math.random() * 100),
      avgQuality: Math.random() * 0.5 + 0.5,
      gapOpportunity: this.identifyGap(trend)
    }));
  }

  identifyGap(trend) {
    const gaps = [
      '缺乏深度分析',
      '视角单一',
      '没有实操指南',
      '忽略反面观点',
      '数据支撑不足'
    ];
    return gaps[Math.floor(Math.random() * gaps.length)];
  }

  scoreTopics(trends, audience, competition) {
    return trends.map(trend => {
      // 热度分 (40%)
      const heatScore = trend.heat * 0.4;
      
      // 受众匹配度 (30%)
      const audienceMatch = this.calculateAudienceMatch(trend, audience) * 30;
      
      // 竞争机会分 (20%)
      const competitionScore = (100 - trend.competitionCount) * 0.2;
      
      // 时效性分 (10%)
      const freshnessScore = parseInt(trend.growth) * 0.1;
      
      const totalScore = heatScore + audienceMatch + competitionScore + freshnessScore;
      
      return {
        ...trend,
        score: Math.round(totalScore),
        breakdown: {
          heat: heatScore,
          audience: audienceMatch,
          competition: competitionScore,
          freshness: freshnessScore
        }
      };
    }).sort((a, b) => b.score - a.score);
  }

  calculateAudienceMatch(trend, audience) {
    // 简化计算
    const keywordMatch = {
      'gen-z': ['00后', '整顿', '职场', '大学'],
      'millennials': ['逆袭', '搞钱', '副业', '成长'],
      'general': ['AI', '热点', '揭秘']
    };
    
    const keywords = keywordMatch[audience.age === '18-25' ? 'gen-z' : 
                                   audience.age === '26-35' ? 'millennials' : 'general'];
    return keywords.some(k => trend.keyword.includes(k)) ? 0.9 : 0.6;
  }

  generateAngles(topTopics) {
    return topTopics.map(topic => ({
      ...topic,
      titleOptions: this.generateTitles(topic),
      angle: this.generateAngle(topic),
      hook: this.generateHook(topic),
      estimatedPerformance: {
        viralProbability: topic.score > 85 ? 'high' : topic.score > 70 ? 'medium' : 'low',
        estimatedViews: this.estimateViews(topic),
        completionRate: this.estimateCompletion(topic)
      }
    }));
  }

  generateTitles(topic) {
    const templates = {
      'AI取代工作': [
        'AI不会取代你，但会用AI的人会',
        '测试了100个岗位，这些工作最先被AI取代',
        '老板用AI干了我3天的活，我该怎么办'
      ],
      '普通人逆袭': [
        '月入3千到3万，我只做了这3件事',
        '普通人逆袭的唯一路径（亲测有效）',
        '为什么你努力却没有结果？因为你不懂这个'
      ],
      '00后整顿职场': [
        '00后：我不是整顿职场，我只是不惯着',
        '领导让我加班，00后同事这样回复',
        '当00后开始上班，职场规则变了'
      ]
    };
    
    return templates[topic.keyword] || [
      `${topic.keyword}，99%的人都理解错了`,
      `${topic.keyword}的真相（颠覆认知）`,
      `关于${topic.keyword}，没人告诉你的事`
    ];
  }

  generateAngle(topic) {
    const angles = {
      '反常识': `你以为${topic.keyword}是这样，实际上...`,
      '独家揭秘': `从业5年，今天揭秘${topic.keyword}的真相`,
      '实操指南': `${topic.keyword}？这份避坑指南请收好`,
      '情感共鸣': `${topic.keyword}，戳中了多少人的痛点`,
      '争议对立': `${topic.keyword}：支持 vs 反对，你站哪边？`
    };
    
    const keys = Object.keys(angles);
    return angles[keys[Math.floor(Math.random() * keys.length)]];
  }

  generateHook(topic) {
    const hooks = [
      `3个数据让你重新认识${topic.keyword}`,
      `${topic.keyword}的第3个真相，看完沉默了`,
      `如果你正在经历${topic.keyword}，请一定看到最后`
    ];
    return hooks[Math.floor(Math.random() * hooks.length)];
  }

  estimateViews(topic) {
    if (topic.score >= 90) return '100w+';
    if (topic.score >= 80) return '50-100w';
    if (topic.score >= 70) return '10-50w';
    return '1-10w';
  }

  estimateCompletion(topic) {
    if (topic.sentiment.includes('焦虑')) return '35-45%';
    if (topic.sentiment.includes('爽点')) return '45-60%';
    return '40-50%';
  }
}

// 运行示例
if (require.main === module) {
  const miner = new TopicMiner({
    platforms: ['douyin', 'bilibili'],
    targetAudience: 'gen-z'
  });
  
  miner.mineTopics().then(result => {
    console.log('\n📊 选题报告：');
    console.log(`扫描了 ${result.summary.totalScanned} 个热点`);
    console.log(`高潜力选题：${result.summary.highPotential} 个`);
    console.log('\n🎯 Top 3 推荐：\n');
    
    result.summary.recommended.forEach((topic, i) => {
      console.log(`${i + 1}. ${topic.keyword}`);
      console.log(`   评分：${topic.score}/100`);
      console.log(`   标题选项：${topic.titleOptions[0]}`);
      console.log(`   差异化角度：${topic.angle}`);
      console.log(`   预估播放量：${topic.estimatedPerformance.estimatedViews}`);
      console.log('');
    });
  });
}

module.exports = TopicMiner;
