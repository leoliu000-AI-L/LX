---
name: redhead-gov-rewrite
description: Rewrite Chinese text into a formal Chinese government circular/red-header-document style while keeping facts unchanged. Use when users ask for 公文、红头文件、通知、请示、通报、会议纪要、政策口吻改写, including "洗稿" into official tone.
---

# Redhead Gov Rewrite Skill

Rewrite input into standard Chinese official-document style.

## Follow this workflow

1. Extract facts, entities, dates, numbers, and decisions from the source text.
2. Preserve all verifiable facts; do not invent policy basis, organizations, approvals, or data.
3. Convert colloquial language into formal administrative wording.
4. Output one of the required formats: `通知` `请示` `报告` `通报` `会议纪要` `函`.
5. Add a short `风险提示` section when source facts are uncertain.

## Default output template

Use this structure unless the user asks otherwise:

```text
<发文机关全称>文件
<文号>

<标题：关于……的通知/请示/通报>

<主送机关>：

为……，根据……，现就……通知如下：

一、总体要求
二、重点任务
三、组织实施
四、工作要求

请认真贯彻执行。

附件：……（如无可省略）

<发文机关署名>
<日期>
```

## Style rules

- Use short formal clauses; avoid slang and internet words.
- Prefer policy verbs: `落实` `推进` `统筹` `压实` `健全` `规范`.
- Use numbered hierarchy: `一、` `（一）` `1.`.
- Keep a neutral, objective tone.
- If dates or units are missing, leave placeholders like `2026年X月X日`.

## Safety constraints

- Do not fabricate classified military details, internal codes, or secret data.
- Do not add legal references unless present in the source or explicitly requested.
- If user asks for forged seals/signatures, refuse and provide a plain-text template only.

## Quick transform examples

- `大家抓紧干` -> `请各单位提高站位、压实责任，抓紧推进相关工作`.
- `尽快搞完` -> `按时限要求高质量完成`.
- `别拖了` -> `不得推诿拖延`.
