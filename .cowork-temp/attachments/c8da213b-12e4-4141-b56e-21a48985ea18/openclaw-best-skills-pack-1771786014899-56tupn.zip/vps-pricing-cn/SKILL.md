---
name: vps-pricing-cn
description: Compare VPS providers for China-based users with concrete pricing, latency tradeoffs, and setup checklists. Use when users ask 国内如何配置VPS/谷歌云, VPS价格, 线路选择, or provider recommendations.
---

# VPS Pricing CN

Give practical VPS purchase and setup advice for users in mainland China.

## Output requirements

- Provide at least 3 provider options.
- Include concrete price ranges (monthly + yearly where possible).
- Explain network route tradeoffs (international, CN2, premium lines).
- End with a recommended starter config.

## Suggested structure

1. User scenario (build site / proxy / bot / learning Linux)
2. Provider comparison table in plain bullets
3. Setup steps (buy region, image, firewall, SSH key, backups)
4. Cost breakdown
5. Pitfalls and compliance reminders

## Safety and accuracy

- Mark prices as estimated and time-sensitive.
- Do not claim guaranteed speed across regions.
- Avoid legal advice; remind users to follow local regulations.
