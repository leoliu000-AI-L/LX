#!/usr/bin/env python3
"""
苏格拉底式十轮迭代引擎
通过不断自我质疑和问答来完善 skill
"""

import json
import os
import time
from datetime import datetime

class SocraticIterator:
    """苏格拉底迭代器"""
    
    def __init__(self, skill_path, max_rounds=10):
        self.skill_path = skill_path
        self.max_rounds = max_rounds
        self.current_round = 0
        self.insights = []
        self.questions = []
        self.improvements = []
        
        # 苏格拉底问题模板
        self.socratic_questions = [
            "这个设计的根本假设是什么？",
            "如果用户不按照预期使用会怎样？",
            "什么情况下这个方案会失败？",
            "有没有更简单的实现方式？",
            "这个功能真正解决的是什么问题？",
            "如果资源受限，哪些可以砍掉？",
            "用户最可能在哪里遇到困难？",
            "这个设计和现有方案的区别是什么？",
            "如何验证这个设计是否有效？",
            "如果重新设计，会有哪些不同？"
        ]
    
    def analyze_current_state(self):
        """分析当前 skill 状态"""
        analysis = {
            "timestamp": datetime.now().isoformat(),
            "round": self.current_round + 1,
            "files_count": 0,
            "scripts": [],
            "issues": [],
            "opportunities": []
        }
        
        # 扫描文件
        scripts_dir = os.path.join(self.skill_path, "scripts")
        if os.path.exists(scripts_dir):
            for f in os.listdir(scripts_dir):
                if f.endswith('.py'):
                    analysis["scripts"].append(f)
                    analysis["files_count"] += 1
        
        # 基于轮次生成不同角度的分析
        if self.current_round == 0:
            analysis["focus"] = "核心假设检验"
            analysis["questions"] = [
                "用户模拟=压缩/解压缩的假设是否成立？",
                "熵值计算是否能准确预测沟通难度？",
                "五轮压缩的频率是否合适？"
            ]
        elif self.current_round == 1:
            analysis["focus"] = "边缘情况"
            analysis["questions"] = [
                "如果用户只有一句话，如何压缩？",
                "如果用户突然改变风格，如何检测？",
                "群聊中多个用户同时活跃，如何处理？"
            ]
        elif self.current_round == 2:
            analysis["focus"] = "简化优化"
            analysis["questions"] = [
                "能否合并 communication_entropy 和 auto_learn？",
                "hooks.py 和 compression_scheduler 是否有重复？",
                "是否可以减少配置文件数量？"
            ]
        elif self.current_round == 3:
            analysis["focus"] = "问题溯源"
            analysis["questions"] = [
                "用户真正需要的是什么？是分析还是预测？",
                "沟通熵是手段还是目的？",
                "SubAgent模拟验证的必要性？"
            ]
        elif self.current_round == 4:
            analysis["focus"] = "资源约束"
            analysis["questions"] = [
                "如果没有 jieba，分词质量下降多少？",
                "数据文件过多是否会影响性能？",
                "哪些功能可以延迟加载？"
            ]
        elif self.current_round == 5:
            analysis["focus"] = "用户体验"
            analysis["questions"] = [
                "用户如何知道自己的压缩档案？",
                "模拟效果不佳时如何反馈？",
                "如何让压缩过程更透明？"
            ]
        elif self.current_round == 6:
            analysis["focus"] = "差异化"
            analysis["questions"] = [
                "和现有的用户画像工具区别在哪？",
                "信息论熵的独特价值是什么？",
                "什么情况下不需要这个工具？"
            ]
        elif self.current_round == 7:
            analysis["focus"] = "验证机制"
            analysis["questions"] = [
                "如何验证压缩后的模拟准确度？",
                "需要哪些指标来衡量效果？",
                "A/B测试如何设计？"
            ]
        elif self.current_round == 8:
            analysis["focus"] = "重构思考"
            analysis["questions"] = [
                "如果只用3个脚本实现核心功能，是哪3个？",
                "数据存储格式是否需要重新设计？",
                "API接口是否应该统一？"
            ]
        else:  # round 9
            analysis["focus"] = "终极简化"
            analysis["questions"] = [
                "如果只有1天时间，保留哪些功能？",
                "什么是最小可用版本(MVP)？",
                "哪些是可以砍掉的'锦上添花'？"
            ]
        
        return analysis
    
    def generate_insight(self, analysis):
        """基于分析生成洞察"""
        round_num = self.current_round
        
        insights_map = {
            0: {
                "insight": "核心假设：用户沟通模式具有统计规律性，可用熵值量化",
                "improvement": "增加假设验证机制，定期检测用户风格漂移",
                "action": "添加 style_drift_detector.py"
            },
            1: {
                "insight": "边缘情况：冷启动用户需要特殊处理",
                "improvement": "为少于5条消息的用户提供快速画像模板",
                "action": "修改 compression_scheduler.py，支持冷启动模式"
            },
            2: {
                "insight": "可合并：communication_entropy 和 auto_learn 有重叠",
                "improvement": "统一为 user_profiler.py，减少代码重复",
                "action": "重构：合并两个脚本的核心逻辑"
            },
            3: {
                "insight": "本质需求：用户需要的是'预测对方如何回应'而非单纯分析",
                "improvement": "强化预测功能，提供'如果我说X，对方可能如何回应'",
                "action": "新增 response_predictor.py"
            },
            4: {
                "insight": "资源优化：可以延迟加载 jieba，使用 LRU 缓存",
                "improvement": "添加智能缓存机制，减少内存占用",
                "action": "添加 cache_manager.py"
            },
            5: {
                "insight": "透明度：用户需要看到自己的'语言指纹'",
                "improvement": "提供可视化/可读的压缩档案展示",
                "action": "添加 profile_visualizer.py"
            },
            6: {
                "insight": "差异化：独特之处在于'量化不确定性'和'动态压缩'",
                "improvement": "强化这两点的展示和教育",
                "action": "更新 SKILL.md，突出核心卖点"
            },
            7: {
                "insight": "验证：需要模拟-反馈-调整的闭环",
                "improvement": "设计 SubAgent 模拟测试框架",
                "action": "实现 simulation_validator.py"
            },
            8: {
                "insight": "重构：核心只需 entropy_calc + compression + hook",
                "improvement": "将 9 个脚本合并为 3 个核心+3个扩展",
                "action": "规划 v3.0 重构路线图"
            },
            9: {
                "insight": "MVP：只需 entropy + compress + simulate 三个功能",
                "improvement": "准备 v3.0 极简版本，砍掉非核心功能",
                "action": "创建 user-persona-analyzer-minimal/"
            }
        }
        
        return insights_map.get(round_num, {
            "insight": "持续优化",
            "improvement": "迭代改进",
            "action": "继续完善"
        })
    
    def run_iteration(self):
        """运行一轮迭代"""
        print(f"\n{'='*60}")
        print(f"🔄 苏格拉底迭代第 {self.current_round + 1}/{self.max_rounds} 轮")
        print(f"{'='*60}")
        
        # 1. 分析当前状态
        analysis = self.analyze_current_state()
        print(f"\n📊 本轮焦点: {analysis['focus']}")
        print(f"\n❓ 苏格拉底三问:")
        for i, q in enumerate(analysis['questions'][:3], 1):
            print(f"   {i}. {q}")
        
        # 2. 生成洞察
        insight = self.generate_insight(analysis)
        print(f"\n💡 核心洞察: {insight['insight']}")
        print(f"\n🔧 改进方向: {insight['improvement']}")
        print(f"\n⚡ 具体行动: {insight['action']}")
        
        # 3. 记录
        self.insights.append(insight)
        self.questions.append(analysis['questions'])
        self.improvements.append({
            "round": self.current_round + 1,
            "focus": analysis['focus'],
            **insight
        })
        
        self.current_round += 1
        
        # 4. 保存进度
        self.save_progress()
        
        return insight
    
    def save_progress(self):
        """保存迭代进度"""
        progress = {
            "skill": "user-persona-analyzer",
            "iteration_type": "socratic",
            "current_round": self.current_round,
            "max_rounds": self.max_rounds,
            "completed": self.current_round >= self.max_rounds,
            "improvements": self.improvements,
            "timestamp": datetime.now().isoformat()
        }
        
        progress_file = os.path.join(
            self.skill_path, "data", "socratic_iteration.json"
        )
        os.makedirs(os.path.dirname(progress_file), exist_ok=True)
        
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 进度已保存: {progress_file}")
    
    def run_all_iterations(self):
        """运行全部迭代"""
        print("🚀 启动苏格拉底式十轮迭代")
        print(f"目标: 深度审视并优化 {self.skill_path}")
        print("="*60)
        
        while self.current_round < self.max_rounds:
            self.run_iteration()
            time.sleep(1)  # 模拟思考时间
        
        # 生成最终报告
        self.generate_final_report()
    
    def generate_final_report(self):
        """生成最终迭代报告"""
        print(f"\n{'='*60}")
        print("📋 苏格拉底十轮迭代 - 最终报告")
        print(f"{'='*60}")
        
        print("\n🎯 十大核心洞察:")
        for i, imp in enumerate(self.improvements, 1):
            print(f"\n{i}. [{imp['focus']}] {imp['insight']}")
            print(f"   → {imp['action']}")
        
        print("\n\n🛠️  建议实施优先级:")
        high_priority = [imp for imp in self.improvements if imp['round'] in [1, 3, 7]]
        medium_priority = [imp for imp in self.improvements if imp['round'] in [2, 5, 6]]
        low_priority = [imp for imp in self.improvements if imp['round'] in [4, 8, 9, 10]]
        
        print("\n🔴 高优先级 (立即实施):")
        for imp in high_priority:
            print(f"   - {imp['action']}")
        
        print("\n🟡 中优先级 (近期实施):")
        for imp in medium_priority:
            print(f"   - {imp['action']}")
        
        print("\n🟢 低优先级 (后续优化):")
        for imp in low_priority:
            print(f"   - {imp['action']}")
        
        # 保存报告
        report = {
            "title": "苏格拉底十轮迭代报告",
            "timestamp": datetime.now().isoformat(),
            "iterations": self.improvements,
            "summary": {
                "total_rounds": self.max_rounds,
                "high_priority_actions": [imp['action'] for imp in high_priority],
                "medium_priority_actions": [imp['action'] for imp in medium_priority],
                "low_priority_actions": [imp['action'] for imp in low_priority]
            }
        }
        
        report_file = os.path.join(
            self.skill_path, "data", "socratic_report.json"
        )
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"\n\n📄 完整报告已保存: {report_file}")
        print("\n✅ 苏格拉底式迭代完成！")

if __name__ == "__main__":
    import sys
    
    # 获取 skill 路径
    skill_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    print(f"🎭 苏格拉底迭代引擎")
    print(f"目标: {skill_path}")
    
    iterator = SocraticIterator(skill_path, max_rounds=10)
    iterator.run_all_iterations()
