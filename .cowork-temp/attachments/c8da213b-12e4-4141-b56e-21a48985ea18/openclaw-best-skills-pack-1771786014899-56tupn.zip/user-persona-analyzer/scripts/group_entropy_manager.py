#!/usr/bin/env python3
"""
群聊全局熵值管理 - 设置和管理群聊级别的沟通熵配置
"""

import sys
import json
import os
from datetime import datetime

# 数据目录
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

def get_group_config_path(chat_id):
    """获取群聊配置文件路径"""
    safe_id = "".join(c for c in chat_id if c.isalnum() or c in "_-").lower()
    return os.path.join(DATA_DIR, f"group_{safe_id}_entropy.json")

def load_group_entropy_config(chat_id):
    """加载群聊熵配置"""
    path = get_group_config_path(chat_id)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return create_default_group_config(chat_id)

def create_default_group_config(chat_id):
    """创建默认群聊配置"""
    return {
        "chat_id": chat_id,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "global_entropy_thresholds": {
            "high_predictability": 70,  # 可预测性高于此值为高
            "low_predictability": 40,   # 可预测性低于此值为低
            "high_entropy": 7.0,        # 词汇熵高于此值为高
            "low_entropy": 4.0          # 词汇熵低于此值为低
        },
        "user_entropy_profiles": {},   # 用户熵档案
        "communication_policies": {
            "high_predictability_strategy": "关键词+指标精准模拟",
            "medium_predictability_strategy": "保留关键词+部分语料",
            "low_predictability_strategy": "保留完整语料+动态学习"
        },
        "compression_settings": {
            "default_compression_ratio": 0.3,  # 默认压缩率
            "min_samples_for_compression": 10,  # 最小样本数
            "keywords_per_user": 10            # 每用户关键词数
        },
        "last_calculation": None
    }

def save_group_config(chat_id, config):
    """保存群聊配置"""
    path = get_group_config_path(chat_id)
    config["updated_at"] = datetime.now().isoformat()
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    return config

def set_user_entropy_profile(chat_id, user_id, entropy_data):
    """设置用户熵档案"""
    config = load_group_entropy_config(chat_id)
    
    # 提取关键信息
    profile = {
        "user_id": user_id,
        "last_updated": datetime.now().isoformat(),
        "lexical_entropy": entropy_data.get("entropy_metrics", {}).get("lexical_entropy"),
        "predictability_score": entropy_data.get("predictability_score"),
        "compression_profile": entropy_data.get("compression_profile", {}),
        "summary": entropy_data.get("summary", ""),
        "communication_strategy": determine_strategy(
            entropy_data.get("predictability_score", 50),
            config["global_entropy_thresholds"]
        )
    }
    
    config["user_entropy_profiles"][user_id] = profile
    
    # 更新群聊整体统计
    update_group_statistics(config)
    
    save_group_config(chat_id, config)
    return profile

def determine_strategy(predictability, thresholds):
    """根据可预测性确定沟通策略"""
    if predictability >= thresholds["high_predictability"]:
        return "high_predictability"
    elif predictability <= thresholds["low_predictability"]:
        return "low_predictability"
    else:
        return "medium_predictability"

def update_group_statistics(config):
    """更新群聊统计信息"""
    profiles = config["user_entropy_profiles"].values()
    
    if not profiles:
        return
    
    predictabilities = [p["predictability_score"] for p in profiles if p.get("predictability_score")]
    entropies = [p["lexical_entropy"] for p in profiles if p.get("lexical_entropy")]
    
    if predictabilities:
        config["group_statistics"] = {
            "user_count": len(profiles),
            "avg_predictability": round(sum(predictabilities) / len(predictabilities), 2),
            "avg_lexical_entropy": round(sum(entropies) / len(entropies), 4) if entropies else 0,
            "high_predictability_count": sum(1 for p in predictabilities if p >= config["global_entropy_thresholds"]["high_predictability"]),
            "low_predictability_count": sum(1 for p in predictabilities if p <= config["global_entropy_thresholds"]["low_predictability"])
        }

def get_user_compression_params(chat_id, user_id):
    """获取用户的压缩参数（用于模拟用户发言）"""
    config = load_group_entropy_config(chat_id)
    profile = config["user_entropy_profiles"].get(user_id)
    
    if not profile:
        return None
    
    strategy = profile.get("communication_strategy")
    settings = config["compression_settings"]
    
    if strategy == "high_predictability":
        return {
            "strategy": "high_compression",
            "compression_ratio": 0.1,  # 高压缩，只保留关键词+指标
            "keywords": profile.get("compression_profile", {}).get("keywords", []),
            "avg_length": profile.get("compression_profile", {}).get("avg_length", 15),
            "template_based": True  # 使用模板生成
        }
    elif strategy == "medium_predictability":
        return {
            "strategy": "medium_compression",
            "compression_ratio": 0.3,
            "keywords": profile.get("compression_profile", {}).get("keywords", []),
            "avg_length": profile.get("compression_profile", {}).get("avg_length", 20),
            "template_based": False
        }
    else:  # low_predictability
        return {
            "strategy": "low_compression",
            "compression_ratio": 0.7,  # 低压缩，保留更多语料
            "keywords": profile.get("compression_profile", {}).get("keywords", []),
            "avg_length": profile.get("compression_profile", {}).get("avg_length", 25),
            "template_based": False,
            "retain_full_corpus": True
        }

def update_entropy_thresholds(chat_id, thresholds):
    """更新全局熵阈值"""
    config = load_group_entropy_config(chat_id)
    config["global_entropy_thresholds"].update(thresholds)
    save_group_config(chat_id, config)
    return config["global_entropy_thresholds"]

def get_group_report(chat_id):
    """获取群聊熵值报告"""
    config = load_group_entropy_config(chat_id)
    
    return {
        "chat_id": chat_id,
        "configuration": {
            "thresholds": config["global_entropy_thresholds"],
            "policies": config["communication_policies"],
            "compression_settings": config["compression_settings"]
        },
        "statistics": config.get("group_statistics", {}),
        "user_profiles": list(config["user_entropy_profiles"].values()),
        "compression_recommendations": generate_recommendations(config)
    }

def generate_recommendations(config):
    """生成压缩建议"""
    stats = config.get("group_statistics", {})
    recommendations = []
    
    user_count = stats.get("user_count", 0)
    high_count = stats.get("high_predictability_count", 0)
    low_count = stats.get("low_predictability_count", 0)
    
    if user_count > 0:
        high_ratio = high_count / user_count
        low_ratio = low_count / user_count
        
        if high_ratio > 0.5:
            recommendations.append("群聊高可预测用户占多数，建议启用模板化回复系统")
        
        if low_ratio > 0.3:
            recommendations.append("存在较多低可预测用户，建议保留更多原始语料用于学习")
        
        if high_ratio < 0.3 and low_ratio < 0.3:
            recommendations.append("群聊用户风格分布均匀，建议采用混合策略")
    
    return recommendations

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="群聊全局熵值管理")
    parser.add_argument("action", choices=[
        "init", "set-user", "get-user", "get-report", 
        "update-thresholds", "get-compression-params", "list"
    ])
    parser.add_argument("--chat-id", "-c", required=True, help="群聊ID")
    parser.add_argument("--user-id", "-u", help="用户ID")
    parser.add_argument("--entropy-data", "-e", help="JSON格式的熵数据")
    parser.add_argument("--thresholds", "-t", help="JSON格式的阈值设置")
    
    args = parser.parse_args()
    
    if args.action == "init":
        config = create_default_group_config(args.chat_id)
        save_group_config(args.chat_id, config)
        print(json.dumps({"status": "initialized", "chat_id": args.chat_id}, ensure_ascii=False))
    
    elif args.action == "set-user":
        if not args.user_id or not args.entropy_data:
            print("Error: --user-id and --entropy-data required", file=sys.stderr)
            sys.exit(1)
        
        entropy_data = json.loads(args.entropy_data)
        profile = set_user_entropy_profile(args.chat_id, args.user_id, entropy_data)
        print(json.dumps(profile, ensure_ascii=False, indent=2))
    
    elif args.action == "get-user":
        if not args.user_id:
            print("Error: --user-id required", file=sys.stderr)
            sys.exit(1)
        
        config = load_group_entropy_config(args.chat_id)
        profile = config["user_entropy_profiles"].get(args.user_id)
        if profile:
            print(json.dumps(profile, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"error": "User not found"}, ensure_ascii=False))
    
    elif args.action == "get-report":
        report = get_group_report(args.chat_id)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    
    elif args.action == "update-thresholds":
        if not args.thresholds:
            print("Error: --thresholds required", file=sys.stderr)
            sys.exit(1)
        
        thresholds = json.loads(args.thresholds)
        updated = update_entropy_thresholds(args.chat_id, thresholds)
        print(json.dumps(updated, ensure_ascii=False, indent=2))
    
    elif args.action == "get-compression-params":
        if not args.user_id:
            print("Error: --user-id required", file=sys.stderr)
            sys.exit(1)
        
        params = get_user_compression_params(args.chat_id, args.user_id)
        if params:
            print(json.dumps(params, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"error": "User not found"}, ensure_ascii=False))
    
    elif args.action == "list":
        # 列出所有群聊配置
        import glob
        files = glob.glob(os.path.join(DATA_DIR, "group_*_entropy.json"))
        groups = []
        for f in files:
            with open(f, 'r') as file:
                data = json.load(file)
                groups.append({
                    "chat_id": data.get("chat_id"),
                    "user_count": len(data.get("user_entropy_profiles", {})),
                    "updated_at": data.get("updated_at")
                })
        print(json.dumps(groups, ensure_ascii=False, indent=2))
