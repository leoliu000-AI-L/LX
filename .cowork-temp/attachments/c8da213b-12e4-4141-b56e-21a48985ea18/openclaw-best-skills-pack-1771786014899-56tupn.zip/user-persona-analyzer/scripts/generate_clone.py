#!/usr/bin/env python3
"""
生成用户分身描述文档
"""

import sys
import json

def generate_persona_clone(name, name_analysis, chat_analysis, user_notes=None):
    """
    基于分析结果生成分身档案
    """
    
    clone_profile = {
        "name": name,
        "base_description": f"基于{name}的历史数据构建的AI分身",
        "speaking_style": {},
        "typical_responses": {},
        "knowledge_areas": [],
        "interaction_preferences": {},
        "sample_phrases": []
    }
    
    # 从聊天分析中提取说话风格
    style = chat_analysis.get("language_style", {})
    
    clone_profile["speaking_style"] = {
        "sentence_length": "长句" if style.get("avg_sentence_length", 0) > 20 else "短句",
        "emotional_expression": "外显" if style.get("exclamation_ratio", 0) > 0.2 else "内敛",
        "question_tendency": "喜欢提问" if style.get("question_ratio", 0) > 0.2 else "陈述为主",
        "parenthesis_habit": style.get("uses_brackets", False),
        "modal_words": [w[0] for w in style.get("modal_words_top", [])]
    }
    
    # 典型反应模板（需要根据更多数据训练，这里是框架）
    clone_profile["typical_responses"] = {
        "when_praised": "（根据用户实际反应模式填充）",
        "when_challenged": "（根据用户实际反应模式填充）",
        "when_bored": "（根据用户实际反应模式填充）",
        "when_excited": "（根据用户实际反应模式填充）"
    }
    
    # 知识领域（需要用户主动提供或从聊天中提取）
    clone_profile["knowledge_areas"] = user_notes.get("expertise", []) if user_notes else []
    
    # 互动偏好
    activity = chat_analysis.get("interaction_pattern", {}).get("activity_level", "medium")
    clone_profile["interaction_preferences"] = {
        "activity_level": activity,
        "initiation_tendency": "主动" if activity == "high" else "被动",
        "group_role": "center" if activity == "high" else "responder" if activity == "medium" else "observer"
    }
    
    # 用户备注
    if user_notes:
        clone_profile["user_notes"] = user_notes
    
    return clone_profile

if __name__ == "__main__":
    # 从 stdin 读取 JSON
    try:
        data = json.load(sys.stdin)
        
        name = data.get("name")
        name_analysis = data.get("name_analysis", {})
        chat_analysis = data.get("chat_analysis", {})
        user_notes = data.get("user_notes")
        
        if not name:
            print(json.dumps({"error": "Name is required"}), file=sys.stderr)
            sys.exit(1)
        
        result = generate_persona_clone(name, name_analysis, chat_analysis, user_notes)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
