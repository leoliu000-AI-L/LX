#!/usr/bin/env python3
"""
沟通熵计算脚本 - 量化用户的沟通可预测性和信息密度

核心概念：
- 熵值高 = 信息不确定性大 = 沟通风格多变 = 难以预测
- 熵值低 = 沟通有规律 = 习惯明显 = 容易模拟
- 模拟用户 = 压缩/解压缩过程，用关键词+指标作为压缩表示
"""

import sys
import json
import math
import os
from collections import Counter
from datetime import datetime

# 尝试导入 jieba，如果没有则使用简单分词
try:
    import jieba
    JIEBA_AVAILABLE = True
except ImportError:
    JIEBA_AVAILABLE = False
    print("Warning: jieba not available, using simple tokenization", file=sys.stderr)

def tokenize(text):
    """分词 - 优先使用 jieba，否则按字/词简单分"""
    if not text:
        return []
    
    if JIEBA_AVAILABLE:
        # 使用 jieba 分词
        return list(jieba.cut(text.strip()))
    else:
        # 简单分词：按非中文/英文数字字符分割
        import re
        # 保留中文词组（2-4字）和英文单词
        tokens = []
        # 中文分词（按字，但连续字组成词）
        chinese_pattern = re.compile(r'[\u4e00-\u9fff]+')
        english_pattern = re.compile(r'[a-zA-Z0-9_]+')
        
        for match in chinese_pattern.finditer(text):
            word = match.group()
            # 简单处理：2字以上视为词
            if len(word) >= 2:
                tokens.append(word)
            else:
                tokens.extend(list(word))
        
        for match in english_pattern.finditer(text):
            tokens.append(match.group().lower())
        
        return tokens

def calculate_entropy(tokens):
    """
    计算信息熵（香农熵）
    H = -Σ(p(x) * log2(p(x)))
    
    熵值解释：
    - 0: 完全可预测（只说同一句话）
    - 高: 完全随机（每个词都不同）
    - 典型中文文本: 4-8 bits
    """
    if not tokens:
        return 0.0
    
    # 词频统计
    freq = Counter(tokens)
    total = len(tokens)
    
    # 计算熵
    entropy = 0.0
    for count in freq.values():
        p = count / total
        if p > 0:
            entropy -= p * math.log2(p)
    
    return round(entropy, 4)

def calculate_conditional_entropy(messages):
    """
    计算条件熵 - 基于上下文的可预测性
    衡量：知道上一条消息后，下一条消息还有多少不确定性
    """
    if len(messages) < 2:
        return 0.0
    
    # 构建转移概率矩阵（简化版）
    bigrams = []
    for i in range(len(messages) - 1):
        curr_tokens = set(tokenize(messages[i].get("content", "")))
        next_tokens = set(tokenize(messages[i + 1].get("content", "")))
        
        # 计算词语重叠度作为"可预测性"指标
        if curr_tokens and next_tokens:
            overlap = len(curr_tokens & next_tokens)
            total = len(curr_tokens | next_tokens)
            if total > 0:
                bigrams.append(overlap / total)
    
    if not bigrams:
        return 0.0
    
    # 条件熵估算：重叠度越高，条件熵越低（越可预测）
    avg_overlap = sum(bigrams) / len(bigrams)
    conditional_entropy = 1 - avg_overlap  # 归一化
    
    return round(conditional_entropy, 4)

def calculate_user_entropy(user_id, messages):
    """
    计算用户的综合沟通熵值
    
    返回结构：
    {
        "user_id": "...",
        "message_count": N,
        "entropy_metrics": {
            "lexical_entropy": 词汇熵（用词多样性）,
            "structural_entropy": 结构熵（句式多样性）,
            "temporal_entropy": 时间熵（回复时机不确定性）,
            "conditional_entropy": 条件熵（上下文可预测性）
        },
        "predictability_score": 可预测性分数 (0-100),
        "compression_ratio": 压缩率（用指标表示用户所需信息量）,
        "summary": "熵值解读"
    }
    """
    if not messages:
        return {"error": "No messages provided"}
    
    user_messages = [m for m in messages if m.get("sender") == user_id]
    if not user_messages:
        return {"error": f"No messages found for user {user_id}"}
    
    # 1. 词汇熵 - 用词多样性
    all_text = " ".join([m.get("content", "") for m in user_messages])
    all_tokens = tokenize(all_text)
    lexical_entropy = calculate_entropy(all_tokens)
    
    # 2. 结构熵 - 句式长度分布
    sentence_lengths = [len(m.get("content", "")) for m in user_messages]
    if sentence_lengths:
        # 长度分布的熵
        length_bins = Counter([round(l / 10) * 10 for l in sentence_lengths])  # 按10字分箱
        total_len = sum(length_bins.values())
        structural_entropy = 0.0
        for count in length_bins.values():
            p = count / total_len
            if p > 0:
                structural_entropy -= p * math.log2(p)
    else:
        structural_entropy = 0.0
    
    # 3. 时间熵 - 回复时机的不确定性
    timestamps = []
    for m in user_messages:
        ts = m.get("timestamp")
        if ts:
            try:
                if isinstance(ts, str):
                    from datetime import datetime
                    dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                else:
                    dt = datetime.fromtimestamp(ts / 1000)
                timestamps.append(dt.hour)  # 记录小时
            except:
                pass
    
    if timestamps:
        hour_dist = Counter(timestamps)
        total_hours = sum(hour_dist.values())
        temporal_entropy = 0.0
        for count in hour_dist.values():
            p = count / total_hours
            if p > 0:
                temporal_entropy -= p * math.log2(p)
    else:
        temporal_entropy = 0.0
    
    # 4. 条件熵 - 上下文可预测性
    conditional_entropy = calculate_conditional_entropy(user_messages)
    
    # 5. 可预测性分数 (0-100)
    # 综合所有熵值，越低越可预测
    max_entropy = 10  # 理论最大值
    normalized_entropy = min(lexical_entropy / max_entropy, 1.0)
    predictability = round((1 - normalized_entropy) * 100)
    
    # 6. 压缩率表示
    # 原始信息量 vs 压缩后信息量（关键词+指标）
    unique_tokens = len(set(all_tokens))
    total_tokens = len(all_tokens)
    if total_tokens > 0:
        compression_ratio = round(unique_tokens / total_tokens, 4)
    else:
        compression_ratio = 0.0
    
    # 7. 关键词提取（压缩表示）
    keywords = extract_keywords(all_tokens, top_k=10)
    
    # 8. 生成解读
    summary = generate_entropy_summary(
        lexical_entropy, structural_entropy, 
        temporal_entropy, predictability
    )
    
    return {
        "user_id": user_id,
        "message_count": len(user_messages),
        "entropy_metrics": {
            "lexical_entropy": round(lexical_entropy, 4),
            "structural_entropy": round(structural_entropy, 4),
            "temporal_entropy": round(temporal_entropy, 4),
            "conditional_entropy": conditional_entropy
        },
        "predictability_score": predictability,
        "compression_ratio": compression_ratio,
        "compression_profile": {
            "keywords": keywords,
            "avg_length": round(sum(sentence_lengths) / len(sentence_lengths), 1) if sentence_lengths else 0,
            "active_hours": list(hour_dist.keys()) if timestamps else [],
            "sentence_length_variance": calculate_variance(sentence_lengths) if sentence_lengths else 0
        },
        "summary": summary,
        "calculated_at": datetime.now().isoformat()
    }

def extract_keywords(tokens, top_k=10):
    """提取关键词（高频词，过滤停用词）"""
    # 简单停用词
    stopwords = set(['的', '了', '是', '我', '你', '在', '有', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '可以', '这', '那', '啊', '呢', '吧', '吗', '嗯', '哦', '哈', 'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'to', 'of', 'and', 'in', 'that', 'have', 'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at'])
    
    # 过滤停用词和单字
    filtered = [t for t in tokens if len(t) > 1 and t.lower() not in stopwords]
    
    # 返回高频词
    freq = Counter(filtered)
    return [word for word, _ in freq.most_common(top_k)]

def calculate_variance(values):
    """计算方差"""
    if not values or len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return round(variance, 2)

def generate_entropy_summary(lexical, structural, temporal, predictability):
    """生成熵值解读"""
    summaries = []
    
    if lexical < 4:
        summaries.append("词汇使用高度重复，表达习惯固定")
    elif lexical > 7:
        summaries.append("词汇丰富多变，表达风格多样")
    else:
        summaries.append("词汇使用适中，有一定规律性")
    
    if structural < 1.5:
        summaries.append("句式长度稳定，结构可预测")
    elif structural > 2.5:
        summaries.append("句式长度变化大，结构灵活")
    
    if predictability > 70:
        summaries.append("整体可预测性高，容易模拟")
    elif predictability < 40:
        summaries.append("整体可预测性低，难以捉摸")
    else:
        summaries.append("可预测性中等，有规律但有个性")
    
    return "；".join(summaries)

def calculate_group_entropy(chat_id, user_entropies):
    """
    计算群聊全局熵值
    
    群聊熵 = 平均用户熵 + 用户间差异熵
    """
    if not user_entropies:
        return {"error": "No user entropies provided"}
    
    # 提取所有用户的词汇熵
    lexical_entropies = [u["entropy_metrics"]["lexical_entropy"] for u in user_entropies if "entropy_metrics" in u]
    predictabilities = [u["predictability_score"] for u in user_entropies if "predictability_score" in u]
    
    if not lexical_entropies:
        return {"error": "No valid entropy data"}
    
    # 群聊平均熵
    avg_entropy = sum(lexical_entropies) / len(lexical_entropies)
    
    # 用户间差异熵（多样性）
    entropy_variance = calculate_variance(lexical_entropies)
    
    # 群聊可预测性
    avg_predictability = sum(predictabilities) / len(predictabilities) if predictabilities else 0
    
    # 群聊类型判断
    if avg_entropy < 4 and entropy_variance < 1:
        group_type = "同质化群聊 - 成员表达风格相似"
    elif avg_entropy > 6 and entropy_variance > 2:
        group_type = "多元化群聊 - 成员风格各异，难以统一预测"
    elif entropy_variance > 2:
        group_type = "分层群聊 - 存在明显不同的表达群体"
    else:
        group_type = "平衡群聊 - 成员风格有差异但可控"
    
    return {
        "chat_id": chat_id,
        "user_count": len(user_entropies),
        "group_entropy": {
            "average_lexical_entropy": round(avg_entropy, 4),
            "entropy_variance": entropy_variance,
            "average_predictability": round(avg_predictability, 1)
        },
        "group_type": group_type,
        "compression_strategy": generate_group_compression_strategy(user_entropies),
        "calculated_at": datetime.now().isoformat()
    }

def generate_group_compression_strategy(user_entropies):
    """生成群聊级别的压缩策略"""
    strategies = []
    
    # 按可预测性排序
    sorted_users = sorted(user_entropies, key=lambda x: x.get("predictability_score", 0), reverse=True)
    
    high_predictable = [u for u in sorted_users if u.get("predictability_score", 0) > 70]
    low_predictable = [u for u in sorted_users if u.get("predictability_score", 0) < 50]
    
    if high_predictable:
        strategies.append(f"高可预测用户({len(high_predictable)}人): 可用关键词+指标精准模拟")
    
    if low_predictable:
        strategies.append(f"低可预测用户({len(low_predictable)}人): 需保留更多原始语料")
    
    # 提取群聊公共关键词
    all_keywords = []
    for u in user_entropies:
        all_keywords.extend(u.get("compression_profile", {}).get("keywords", []))
    
    if all_keywords:
        common_keywords = Counter(all_keywords).most_common(5)
        strategies.append(f"群聊高频词: {[k for k, _ in common_keywords]}")
    
    return strategies

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="沟通熵计算工具")
    parser.add_argument("action", choices=["user", "group", "compare"])
    parser.add_argument("--user-id", "-u", help="用户ID")
    parser.add_argument("--chat-id", "-c", help="群聊ID")
    parser.add_argument("--messages", "-m", help="JSON格式的消息列表")
    parser.add_argument("--file", "-f", help="消息数据文件路径")
    
    args = parser.parse_args()
    
    # 加载消息数据
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            messages = data.get("messages", [])
    elif args.messages:
        messages = json.loads(args.messages)
    else:
        # 从stdin读取
        messages = json.load(sys.stdin).get("messages", [])
    
    if args.action == "user":
        if not args.user_id:
            print("Error: --user-id required for user action", file=sys.stderr)
            sys.exit(1)
        result = calculate_user_entropy(args.user_id, messages)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "group":
        # 计算群聊中所有用户的熵值
        if not args.chat_id:
            args.chat_id = "unknown_group"
        
        # 获取所有用户ID
        user_ids = list(set(m.get("sender") for m in messages if m.get("sender")))
        
        user_entropies = []
        for uid in user_ids:
            entropy = calculate_user_entropy(uid, messages)
            if "error" not in entropy:
                user_entropies.append(entropy)
        
        # 计算群聊全局熵
        group_result = calculate_group_entropy(args.chat_id, user_entropies)
        
        output = {
            "group": group_result,
            "users": user_entropies
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    
    elif args.action == "compare":
        # 比较多个用户的熵值
        user_ids = list(set(m.get("sender") for m in messages if m.get("sender")))
        results = []
        for uid in user_ids:
            entropy = calculate_user_entropy(uid, messages)
            if "error" not in entropy:
                results.append({
                    "user_id": uid,
                    "lexical_entropy": entropy["entropy_metrics"]["lexical_entropy"],
                    "predictability": entropy["predictability_score"],
                    "keywords": entropy["compression_profile"]["keywords"][:3]
                })
        
        # 按可预测性排序
        results.sort(key=lambda x: x["predictability"], reverse=True)
        print(json.dumps(results, ensure_ascii=False, indent=2))
