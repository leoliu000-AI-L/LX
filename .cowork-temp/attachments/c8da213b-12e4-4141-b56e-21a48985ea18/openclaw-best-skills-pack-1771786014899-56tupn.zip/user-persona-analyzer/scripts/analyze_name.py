#!/usr/bin/env python3
"""
分析用户名字，推测家庭期望，生成破冰问题
"""

import sys
import json

# 常见字义映射
CHAR_MEANINGS = {
    # 品德期望
    "仁": "仁爱宽厚", "义": "正直正义", "礼": "知礼守礼", "智": "智慧聪慧", "信": "诚信可靠",
    "诚": "诚实守信", "善": "善良友善", "德": "品德高尚", "孝": "孝顺长辈", "忠": "忠诚可靠",
    # 才华期望
    "文": "文采出众", "博": "博学多才", "学": "好学上进", "思": "善于思考", "睿": "睿智聪明",
    "哲": "有哲思", "彦": "有才学", "俊": "才智出众", "杰": "杰出优秀", "英": "英才出众",
    "明": "明亮聪慧", "慧": "聪慧智慧", "敏": "聪敏机智", "颖": "聪颖出众",
    # 成就期望
    "伟": "伟大卓越", "强": "强大坚强", "胜": "胜利成功", "凯": "凯旋成功", "成": "有所成就",
    "功": "功成名就", "达": "发达通达", "兴": "兴旺发达", "隆": "兴隆昌盛", "盛": "兴盛繁荣",
    # 性格期望
    "静": "安静沉稳", "安": "平安安定", "乐": "乐观快乐", "和": "温和和睦", "平": "平和平稳",
    "宁": "宁静安宁", "怡": "怡然自得", "悦": "喜悦愉快", "舒": "舒心舒畅", "淡": "淡泊宁静",
    # 健康/平安期望
    "康": "健康安康", "健": "强健有力", "顺": "顺利顺遂", "福": "福气幸福",
    "泰": "平安康泰", "祥": "吉祥如意", "瑞": "祥瑞吉利", "佑": "庇佑保护", "保": "保佑平安",
    # 气质/外表期望
    "轩": "气宇轩昂", "宇": "器宇不凡", "航": "扬帆远航", "翔": "展翅高飞",
    "雅": "优雅文雅", "婷": "婷婷玉立", "娜": "婀娜多姿", "婉": "温婉柔顺",
    "浩": "浩然正气", "然": "自然率真", "天": "天真烂漫", "宇": "胸怀宇宙",
}

GENERATION_PATTERNS = {
    "50-60": ["建国", "建华", "援朝", "抗美", "跃进", "红旗", "卫东", "卫红"],
    "70-80-m": ["伟", "强", "军", "勇", "刚", "磊", "超", "涛", "波", "鹏"],
    "70-80-f": ["丽", "芳", "娟", "敏", "静", "秀", "玲", "燕", "华", "艳"],
    "90-00-m": ["浩", "宇", "鑫", "杰", "俊", "轩", "晨", "阳", "昊", "天"],
    "90-00-f": ["梓", "涵", "萱", "怡", "欣", "雨", "婷", "媛", "琳", "琪"],
}

def analyze_name(name):
    """分析名字含义"""
    result = {
        "name": name,
        "character_analysis": [],
        "family_expectations": [],
        "generation_hint": None,
        "ice_breaker_questions": []
    }
    
    # 单字分析
    for char in name:
        if char in CHAR_MEANINGS:
            result["character_analysis"].append({
                "char": char,
                "meaning": CHAR_MEANINGS[char]
            })
            # 归类家庭期望
            for category, chars in [
                ("品德", "仁义礼智信诚善德孝忠"),
                ("才华", "文博学思睿哲彦俊杰英"),
                ("成就", "伟强胜凯成功达兴隆盛"),
                ("性格", "静安乐和平宁怡悦舒淡"),
                ("平安", "康健宁顺福泰祥瑞佑保")
            ]:
                if char in chars and category not in result["family_expectations"]:
                    result["family_expectations"].append(category)
    
    # 代际推测
    for gen, patterns in GENERATION_PATTERNS.items():
        for pattern in patterns:
            if pattern in name:
                result["generation_hint"] = gen
                break
    
    # 生成破冰问题
    result["ice_breaker_questions"] = generate_questions(name, result)
    
    return result

def generate_questions(name, analysis):
    """生成破冰问题"""
    questions = []
    
    # 基于字义的问题
    if analysis["character_analysis"]:
        char = analysis["character_analysis"][0]
        questions.append(f"你名字里的'{char['char']}'字，是父母希望你{char['meaning']}吗？")
    
    # 基于家庭期望的问题
    if analysis["family_expectations"]:
        exp = analysis["family_expectations"][0]
        questions.append(f"看来你父母很看重{exp}这方面？")
    
    # 通用问题
    questions.extend([
        f"很少见到'{name}'这样的名字，有什么特别的来历吗？",
        f"如果让你给自己取个网名，会保留原名里的哪个字？",
        f"你觉得自己符合名字里蕴含的那种期待吗？"
    ])
    
    return questions[:3]  # 返回前3个问题

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 analyze_name.py <name>", file=sys.stderr)
        sys.exit(1)
    
    name = sys.argv[1]
    result = analyze_name(name)
    print(json.dumps(result, ensure_ascii=False, indent=2))
