#!/usr/bin/env python3
"""
EvoMap 发布脚本 - 将 user-persona-analyzer 发布到 EvoMap
"""

import json
import requests
import os
import sys
from datetime import datetime

# EvoMap Hub URL
HUB_URL = "https://evomap.ai"

# 生成唯一的 sender_id（首次运行后应保存并复用）
def get_or_create_sender_id():
    sender_file = os.path.expanduser("~/.evomap_node_id")
    if os.path.exists(sender_file):
        with open(sender_file, 'r') as f:
            return f.read().strip()
    
    # 生成新的 node_id
    import random
    import string
    node_id = "node_" + ''.join(random.choices(string.hexdigits.lower(), k=16))
    
    # 保存
    with open(sender_file, 'w') as f:
        f.write(node_id)
    
    return node_id

def make_envelope(message_type, payload):
    """创建 GEP-A2A 协议信封"""
    import random
    import string
    
    timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    message_id = f"msg_{int(datetime.utcnow().timestamp() * 1000)}_{''.join(random.choices(string.hexdigits.lower(), k=4))}"
    sender_id = get_or_create_sender_id()
    
    return {
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": message_type,
        "message_id": message_id,
        "sender_id": sender_id,
        "timestamp": timestamp,
        "payload": payload
    }

def hello():
    """注册节点到 EvoMap"""
    payload = {
        "capabilities": {
            "user_analysis": True,
            "persona_cloning": True,
            "auto_learning": True,
            "proactive_communication": True
        },
        "gene_count": 1,
        "capsule_count": 1,
        "env_fingerprint": {
            "platform": "linux",
            "arch": "arm64"
        }
    }
    
    envelope = make_envelope("hello", payload)
    
    try:
        resp = requests.post(f"{HUB_URL}/a2a/hello", json=envelope, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"Hello failed: {e}")
        return None

def publish_bundle(bundle_path):
    """发布 Gene + Capsule + EvolutionEvent bundle"""
    
    # 加载 bundle
    with open(bundle_path, 'r', encoding='utf-8') as f:
        bundle = json.load(f)
    
    # 构建 payload.assets
    payload = {
        "assets": [
            bundle["gene"],
            bundle["capsule"],
            bundle["evolution_event"]
        ]
    }
    
    envelope = make_envelope("publish", payload)
    
    try:
        resp = requests.post(f"{HUB_URL}/a2a/publish", json=envelope, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"Publish failed: {e}")
        return None

def fetch_promoted():
    """获取已推广的资源"""
    payload = {
        "asset_type": "Capsule"
    }
    
    envelope = make_envelope("fetch", payload)
    
    try:
        resp = requests.post(f"{HUB_URL}/a2a/fetch", json=envelope, timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"Fetch failed: {e}")
        return None

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="EvoMap 发布工具")
    parser.add_argument("action", choices=["hello", "publish", "fetch", "status"])
    parser.add_argument("--bundle", default="evomap_bundle/bundle.json", help="Bundle 文件路径")
    
    args = parser.parse_args()
    
    if args.action == "hello":
        result = hello()
        if result:
            print("✅ Node registered successfully!")
            print(json.dumps(result, indent=2))
            if "claim_url" in result:
                print(f"\n🔗 Claim URL: {result['claim_url']}")
                print("   请将此 URL 提供给用户以绑定账户")
    
    elif args.action == "publish":
        # 检查 bundle 文件
        if not os.path.exists(args.bundle):
            print(f"❌ Bundle not found: {args.bundle}")
            sys.exit(1)
        
        result = publish_bundle(args.bundle)
        if result:
            print("✅ Bundle published!")
            print(json.dumps(result, indent=2))
    
    elif args.action == "fetch":
        result = fetch_promoted()
        if result:
            print("✅ Fetched promoted assets:")
            print(json.dumps(result, indent=2))
    
    elif args.action == "status":
        # 检查节点状态
        sender_id = get_or_create_sender_id()
        print(f"Node ID: {sender_id}")
        print(f"Config file: ~/.evomap_node_id")
        
        # 尝试获取节点信息
        try:
            resp = requests.get(f"{HUB_URL}/a2a/nodes/{sender_id}", timeout=10)
            if resp.status_code == 200:
                print("\nNode info:")
                print(json.dumps(resp.json(), indent=2))
            else:
                print(f"\nNode not found on hub (status: {resp.status_code})")
                print("Run 'hello' first to register.")
        except Exception as e:
            print(f"\nFailed to check status: {e}")

if __name__ == "__main__":
    main()
