#!/usr/bin/env python3
"""
自动迭代学习引擎 - 在沟通过程中持续更新用户画像
"""

import sys
import json
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.user_taboos import load_user_taboos, save_user_taboos, get_user_taboos_path

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

def get_user_profile_path(user_id):
    """获取用户画像文件路径"""
    safe_id = "".join(c for c in user_id if c.isalnum() or c in "_-").lower()
    return os.path.join(DATA_DIR, f"{safe_id}_profile.json")

def load_user_profile(user_id):
    """加载用户完整画像"""
    path = get_user_profile_path(user_id)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return create_default_profile(user_id)

def create_default_profile(user_id):
    """创建默认画像"""
    return {
        "user_id": user_id,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "version": 1,
        "personality": {
            "mbti": None,
            "big_five": {},
            "communication_style": "unknown",
            "confidence": 0.0
        },
        "language_habits": {
            "avg_sentence_length": None,
            "question_ratio": None,
            "exclamation_ratio": None,
            "uses_brackets": None,
            "modal_words": [],
            "emoji_usage": None,
            "sample_count": 0
        },
        "interaction_pattern": {
            "activity_level": "unknown",
            "response_time_avg": None,
            "initiation_rate": None,
            "preferred_topics": []
        },
        "communication_evolution": [],
        "observed_traits": []
    }

def update_profile_from_message(user_id, message_data):
    """
    从单条消息更新用户画像
    message_data: {
        "content": "消息内容",
        "timestamp": "ISO时间",
        "is_reply": bool,
        "context_length": int
    }
    """
    profile = load_user_profile(user_id)
    content = message_data.get("content", "")
    
    # 提取语言特征
    lang_features = extract_language_features(content)
    
    # 更新语言习惯（滑动平均）
    update_language_habits(profile, lang_features)
    
    # 推断性格特征
    inferred_traits = infer_traits(profile, lang_features, message_data)
    
    # 更新观察到的特征
    for trait in inferred_traits:
        if trait not in profile["observed_traits"]:
            profile["observed_traits"].append(trait)
    
    # 更新MBTI推测
    update_mbti_inference(profile)
    
    # 记录进化轨迹
    profile["communication_evolution"].append({
        "timestamp": datetime.now().isoformat(),
        "message_features": lang_features,
        "inferred_traits": inferred_traits,
        "current_mbti": profile["personality"]["mbti"],
        "confidence": profile["personality"]["confidence"]
    })
    
    # 限制历史记录数量
    if len(profile["communication_evolution"]) > 100:
        profile["communication_evolution"] = profile["communication_evolution"][-50:]
    
    profile["updated_at"] = datetime.now().isoformat()
    profile["version"] += 1
    
    # 保存
    save_user_profile(user_id, profile)
    
    return profile

def extract_language_features(content):
    """提取语言特征"""
    import re
    
    sentences = re.split(r'[。！？\n]', content)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    return {
        "length": len(content),
        "sentence_count": len(sentences),
        "avg_sentence_length": sum(len(s) for s in sentences) / len(sentences) if sentences else 0,
        "question_count": len(re.findall(r'[？?]', content)),
        "exclamation_count": len(re.findall(r'[！!]', content)),
        "bracket_count": len(re.findall(r'[（(].*?[）)]', content)),
        "modal_words": re.findall(r'[啊呢吧嘛哦哈呀嘿]', content),
        "emoji_count": len(re.findall(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF]', content))
    }

def update_language_habits(profile, features):
    """更新语言习惯（滑动平均）"""
    habits = profile["language_habits"]
    count = habits["sample_count"]
    
    if count == 0:
        habits["avg_sentence_length"] = features["avg_sentence_length"]
        habits["question_ratio"] = features["question_count"] / max(features["sentence_count"], 1)
        habits["exclamation_ratio"] = features["exclamation_count"] / max(features["sentence_count"], 1)
        habits["uses_brackets"] = features["bracket_count"] > 0
        habits["modal_words"] = list(set(features["modal_words"]))
        habits["emoji_usage"] = "high" if features["emoji_count"] > 0 else "low"
    else:
        # 滑动平均更新
        alpha = 0.3  # 新数据权重
        habits["avg_sentence_length"] = (1-alpha) * habits["avg_sentence_length"] + alpha * features["avg_sentence_length"]
        habits["question_ratio"] = (1-alpha) * habits["question_ratio"] + alpha * (features["question_count"] / max(features["sentence_count"], 1))
        habits["exclamation_ratio"] = (1-alpha) * habits["exclamation_ratio"] + alpha * (features["exclamation_count"] / max(features["sentence_count"], 1))
        habits["uses_brackets"] = habits["uses_brackets"] or features["bracket_count"] > 0
        habits["modal_words"] = list(set(habits["modal_words"] + features["modal_words"]))
        
        # emoji使用更新
        current_emoji = features["emoji_count"] > 0
        if current_emoji:
            habits["emoji_usage"] = "high"
    
    habits["sample_count"] = count + 1

def infer_traits(profile, features, message_data):
    """从消息中推断性格特征"""
    traits = []
    
    # E/I 维度
    if features["length"] > 50:
        traits.append("倾向于详细表达(E倾向)")
    elif features["length"] < 15:
        traits.append("言简意赅(I倾向)")
    
    # 问句比例 -> 好奇心
    question_ratio = features["question_count"] / max(features["sentence_count"], 1)
    if question_ratio > 0.3:
        traits.append("好奇心强，喜欢探索")
    
    # 感叹号比例 -> 情绪外显
    exclaim_ratio = features["exclamation_count"] / max(features["sentence_count"], 1)
    if exclaim_ratio > 0.2:
        traits.append("情绪外显，表达直接")
    elif exclaim_ratio < 0.05:
        traits.append("情绪内敛，克制表达")
    
    # 括号使用 -> 思维发散
    if features["bracket_count"] > 0:
        traits.append("习惯补充说明，思维发散")
    
    # 回复速度推断
    if message_data.get("is_reply") and message_data.get("response_time", 0) < 60:
        traits.append("反应迅速，思考敏捷")
    
    return traits

def update_mbti_inference(profile):
    """基于累积数据更新MBTI推测"""
    habits = profile["language_habits"]
    traits = profile["observed_traits"]
    
    if habits["sample_count"] < 5:
        return  # 数据不足
    
    mbti = ["", "", "", ""]
    
    # E/I: 外向/内向
    if habits["avg_sentence_length"] > 30:
        mbti[0] = "E"
    else:
        mbti[0] = "I"
    
    # S/N: 实感/直觉（简化判断）
    if any("发散" in t for t in traits):
        mbti[1] = "N"
    else:
        mbti[1] = "S"
    
    # T/F: 思考/情感
    if habits["exclamation_ratio"] < 0.1:
        mbti[2] = "T"
    else:
        mbti[2] = "F"
    
    # J/P: 判断/知觉
    if habits["question_ratio"] > 0.2:
        mbti[3] = "P"
    else:
        mbti[3] = "J"
    
    # 计算置信度
    confidence = min(0.3 + habits["sample_count"] * 0.05, 0.9)
    
    profile["personality"]["mbti"] = "".join(mbti)
    profile["personality"]["confidence"] = round(confidence, 2)

def save_user_profile(user_id, profile):
    """保存用户画像"""
    path = get_user_profile_path(user_id)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)

def get_user_summary(user_id):
    """获取用户画像摘要"""
    profile = load_user_profile(user_id)
    return {
        "user_id": user_id,
        "mbti": profile["personality"]["mbti"],
        "confidence": profile["personality"]["confidence"],
        "sample_count": profile["language_habits"]["sample_count"],
        "key_traits": profile["observed_traits"][:5],
        "language_style": {
            "avg_length": round(profile["language_habits"]["avg_sentence_length"], 1) if profile["language_habits"]["avg_sentence_length"] else None,
            "question_ratio": round(profile["language_habits"]["question_ratio"], 2) if profile["language_habits"]["question_ratio"] else None,
            "emoji_usage": profile["language_habits"]["emoji_usage"]
        }
    }

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="自动迭代学习用户画像")
    parser.add_argument("action", choices=["update", "summary", "evolution"])
    parser.add_argument("--user-id", "-u", required=True)
    parser.add_argument("--message", "-m", help="JSON格式的消息数据")
    
    args = parser.parse_args()
    
    if args.action == "update":
        if not args.message:
            print(json.dumps({"error": "需要 --message 参数"}, ensure_ascii=False))
            sys.exit(1)
        msg_data = json.loads(args.message)
        result = update_profile_from_message(args.user_id, msg_data)
        print(json.dumps({"status": "updated", "version": result["version"]}, ensure_ascii=False))
    
    elif args.action == "summary":
        result = get_user_summary(args.user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "evolution":
        profile = load_user_profile(args.user_id)
        print(json.dumps(profile["communication_evolution"], ensure_ascii=False, indent=2))
