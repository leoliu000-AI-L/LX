#!/usr/bin/env python3
"""
EvoMap Bundle Generator v2.0 - 包含所有新功能
"""

import json
import hashlib
import os
from datetime import datetime

def canonical_json(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

def compute_asset_id(asset):
    asset_copy = {k: v for k, v in asset.items() if k != 'asset_id'}
    canonical = canonical_json(asset_copy)
    return f"sha256:{hashlib.sha256(canonical.encode('utf-8')).hexdigest()}"

def generate_gene_v2():
    """生成 Gene v2.0 - 增强版策略模板"""
    gene = {
        "type": "Gene",
        "schema_version": "1.5.0",
        "category": "innovate",
        "signals_match": [
            "user_persona_analysis",
            "communication_entropy_calculation",
            "auto_compression",
            "hook_integration",
            "background_processing",
            "proactive_communication"
        ],
        "summary": "用户人格分析系统 v2.0：通过信息论熵值量化沟通可预测性，自动轮询压缩用户语言习惯，后台Hook集成，支持主动非问题型沟通。核心思想：用户模拟 = 压缩/解压缩过程。",
        "validation": [
            "python3 scripts/communication_entropy.py user --user-id test",
            "python3 scripts/background_compression.py compress --chat-id test --user-id test --force",
            "python3 scripts/hooks.py check-ready --chat-id test --user-id test"
        ],
        "key_concepts": [
            "communication_entropy: 香农熵应用于用户语言分析",
            "compression_ratio: 根据可预测性动态调整压缩率",
            "round_based_compression: 每N轮自动压缩",
            "hook_integration: 消息处理流程自动Hook",
            "proactive_trigger: 非问题型主动沟通"
        ]
    }
    gene["asset_id"] = compute_asset_id(gene)
    return gene

def generate_capsule_v2(gene_id):
    """生成 Capsule v2.0 - 完整实现"""
    capsule = {
        "type": "Capsule",
        "schema_version": "1.5.0",
        "trigger": [
            "user_onboarding",
            "persona_clone_request",
            "communication_optimization",
            "entropy_calculation_request",
            "compression_scheduling",
            "hook_registration"
        ],
        "gene": gene_id,
        "summary": "User Persona Analyzer v2.0 - 包含：1) 沟通熵计算（词汇/结构/时间/条件熵）；2) 自动轮询压缩（每5轮触发）；3) 后台Hook集成；4) 群聊全局熵管理；5) 主动非问题型沟通触发；6) EvoMap进化集成。支持高/中/低可预测性用户的差异化压缩策略。",
        "confidence": 0.9,
        "blast_radius": {
            "files": 12,
            "lines": 2500
        },
        "outcome": {
            "status": "success",
            "score": 0.9
        },
        "success_streak": 3,
        "env_fingerprint": {
            "platform": "linux",
            "arch": "arm64",
            "python_version": "3.13",
            "dependencies": ["jieba(optional)"]
        },
        "features": [
            "communication_entropy.py: 多维度熵值计算",
            "group_entropy_manager.py: 群聊全局管理",
            "compression_scheduler.py: 轮询压缩调度",
            "background_compression.py: 后台执行+Prompt优化",
            "hooks.py: 消息处理Hook集成",
            "auto_learn.py: 单条消息实时学习",
            "post_chat_process.py: 对话后批量处理",
            "user_taboos.py: 沟通禁忌管理",
            "evomap_cli.py: EvoMap发布工具"
        ]
    }
    capsule["asset_id"] = compute_asset_id(capsule)
    return capsule

def generate_evolution_event_v2(capsule_id, gene_id):
    """生成 EvolutionEvent v2.0"""
    event = {
        "type": "EvolutionEvent",
        "intent": "innovate",
        "capsule_id": capsule_id,
        "genes_used": [gene_id],
        "outcome": {
            "status": "success",
            "score": 0.9
        },
        "mutations_tried": 8,
        "total_cycles": 15,
        "notes": "v1.0→v2.0进化：1) 增加信息论熵计算；2) 实现轮询压缩机制；3) 添加后台Hook集成；4) 支持主动沟通触发；5) 优化EvoMap集成流程；6) 新增SubAgent模拟验证规划。核心洞察：用户模拟本质是压缩/解压缩过程。",
        "evolution_path": [
            "v1.0: 基础用户分析（名字+聊天记录+分身）",
            "v1.5: 增加沟通禁忌管理",
            "v2.0: 信息论熵计算 + 自动压缩 + Hook集成"
        ]
    }
    event["asset_id"] = compute_asset_id(event)
    return event

def generate_bundle_v2():
    """生成 v2.0 Bundle"""
    gene = generate_gene_v2()
    capsule = generate_capsule_v2(gene["asset_id"])
    event = generate_evolution_event_v2(capsule["asset_id"], gene["asset_id"])
    
    bundle = {
        "gene": gene,
        "capsule": capsule,
        "evolution_event": event,
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "skill_name": "user-persona-analyzer",
            "version": "2.0.0",
            "changelog": [
                "新增沟通熵计算脚本",
                "新增轮询压缩调度器",
                "新增后台压缩执行器",
                "新增Hook集成系统",
                "优化EvoMap Bundle生成"
            ]
        }
    }
    
    return bundle

if __name__ == "__main__":
    bundle = generate_bundle_v2()
    print(json.dumps(bundle, ensure_ascii=False, indent=2))
    
    # 保存到文件
    output_dir = os.path.join(os.path.dirname(__file__), "..", "evomap_bundle")
    os.makedirs(output_dir, exist_ok=True)
    
    output_file = os.path.join(output_dir, "bundle_v2.0.json")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(bundle, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Bundle v2.0 saved to: {output_file}")
    print(f"   Gene ID: {bundle['gene']['asset_id'][:25]}...")
    print(f"   Capsule ID: {bundle['capsule']['asset_id'][:25]}...")
    print(f"   Event ID: {bundle['evolution_event']['asset_id'][:25]}...")
    print(f"\n🚀 Ready to publish to EvoMap!")
