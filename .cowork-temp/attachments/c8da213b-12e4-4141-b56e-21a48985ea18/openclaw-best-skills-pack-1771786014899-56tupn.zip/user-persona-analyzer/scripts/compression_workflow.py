#!/usr/bin/env python3
"""
压缩-验证完整工作流

流程：
1. 每5轮对话触发压缩
2. 压缩后自动启动SubAgent模拟3轮对话
3. 验证模拟效果
4. 根据结果调整压缩参数或接受当前配置
"""

import sys
import json
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.compression_scheduler import CompressionScheduler
from scripts.compression_validator import CompressionValidator, run_simulation_validation

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def run_compression_workflow(chat_id, user_id, message=None, role="user", 
                             auto_simulate=False, test_questions=None):
    """
    运行完整的压缩工作流
    
    Args:
        chat_id: 群聊ID
        user_id: 用户ID  
        message: 当前消息（可选）
        role: 角色（user/assistant）
        auto_simulate: 是否自动启动模拟
        test_questions: 测试问题列表
    
    Returns:
        workflow_result: 工作流结果
    """
    scheduler = CompressionScheduler(chat_id, compression_interval=5)
    result = {
        "chat_id": chat_id,
        "user_id": user_id,
        "timestamp": datetime.now().isoformat(),
        "steps": []
    }
    
    # Step 1: 记录互动
    if message:
        should_compress = scheduler.record_interaction(user_id, message, role)
        result["steps"].append({
            "step": "record_interaction",
            "should_compress": should_compress,
            "round_count": scheduler.get_user_status(user_id)["round_count"]
        })
    else:
        should_compress = True  # 手动触发
        result["steps"].append({
            "step": "manual_trigger",
            "should_compress": True
        })
    
    # Step 2: 执行压缩
    if should_compress:
        compression_result = scheduler.compress_user_profile(user_id)
        result["steps"].append({
            "step": "compress",
            "status": compression_result.get("status"),
            "predictability": compression_result.get("compression_record", {}).get("predictability"),
            "keywords": compression_result.get("compression_record", {}).get("keywords")
        })
        
        # Step 3: 准备模拟验证
        sim_prep = run_simulation_validation(chat_id, user_id, test_questions)
        result["steps"].append({
            "step": "prepare_simulation",
            "test_questions": sim_prep.get("test_questions")
        })
        
        # Step 4: 如果启用自动模拟，输出SubAgent启动信息
        if auto_simulate:
            result["steps"].append({
                "step": "auto_simulate_ready",
                "instruction": "启动SubAgent进行模拟",
                "prompt_preview": sim_prep.get("simulation_prompt", "")[:200] + "..."
            })
            result["next_action"] = "spawn_subagent"
            result["subagent_config"] = {
                "task": f"模拟用户对话 - 基于压缩档案进行3轮问答\n\n{sim_prep.get('simulation_prompt', '')}\n\n测试问题：\n" + "\n".join([f"{i+1}. {q}" for i, q in enumerate(sim_prep.get('test_questions', []))]),
                "mode": "run",
                "timeout": 120
            }
        else:
            result["next_action"] = "manual_validate"
            result["validation_guide"] = {
                "preparation": sim_prep,
                "validation_command": f"python3 scripts/compression_validator.py validate --chat-id {chat_id} --user-id {user_id} --simulation '<模拟对话JSON>'"
            }
    else:
        result["next_action"] = "continue_conversation"
        result["message"] = f"还需 {5 - scheduler.get_user_status(user_id)['round_count']} 轮对话后自动压缩"
    
    return result

def process_simulation_result(chat_id, user_id, simulated_conversation):
    """
    处理SubAgent模拟结果
    
    Args:
        chat_id: 群聊ID
        user_id: 用户ID
        simulated_conversation: SubAgent返回的模拟对话
    
    Returns:
        final_result: 最终处理结果
    """
    validator = CompressionValidator(chat_id, user_id)
    validation = validator.validate_simulation(simulated_conversation)
    
    result = {
        "chat_id": chat_id,
        "user_id": user_id,
        "timestamp": datetime.now().isoformat(),
        "validation": validation,
        "actions": []
    }
    
    # 根据验证结果决定后续动作
    score = validation.get("overall_score", 0)
    
    if score >= 85:
        result["actions"].append({
            "action": "accept_compression",
            "reason": f"压缩效果优秀 (得分: {score})"
        })
        result["status"] = "compression_accepted"
    
    elif score >= 70:
        result["actions"].append({
            "action": "accept_with_notes",
            "reason": f"压缩效果良好 (得分: {score})，但有优化空间",
            "recommendations": validation.get("recommendations", [])
        })
        result["status"] = "compression_accepted_with_notes"
    
    else:
        result["actions"].append({
            "action": "request_recompression",
            "reason": f"压缩效果不佳 (得分: {score})，需要调整",
            "recommendations": validation.get("recommendations", [])
        })
        result["status"] = "recompression_needed"
    
    # 保存验证记录
    save_validation_record(chat_id, user_id, result)
    
    return result

def save_validation_record(chat_id, user_id, result):
    """保存验证记录"""
    record_file = os.path.join(DATA_DIR, f"validation_history_{chat_id}.json")
    
    history = []
    if os.path.exists(record_file):
        with open(record_file, 'r', encoding='utf-8') as f:
            history = json.load(f)
    
    history.append({
        "timestamp": result["timestamp"],
        "user_id": user_id,
        "score": result["validation"].get("overall_score"),
        "status": result["status"]
    })
    
    # 只保留最近20条
    history = history[-20:]
    
    with open(record_file, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

def get_validation_history(chat_id, user_id=None, limit=10):
    """获取验证历史"""
    record_file = os.path.join(DATA_DIR, f"validation_history_{chat_id}.json")
    
    if not os.path.exists(record_file):
        return []
    
    with open(record_file, 'r', encoding='utf-8') as f:
        history = json.load(f)
    
    if user_id:
        history = [h for h in history if h["user_id"] == user_id]
    
    return history[-limit:]

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="压缩-验证完整工作流")
    parser.add_argument("action", choices=[
        "workflow", "validate", "history"
    ])
    parser.add_argument("--chat-id", "-c", required=True)
    parser.add_argument("--user-id", "-u", required=True)
    parser.add_argument("--message", "-m")
    parser.add_argument("--role", "-r", default="user")
    parser.add_argument("--auto-simulate", action="store_true")
    parser.add_argument("--simulation-result", "-s", help="模拟结果JSON")
    
    args = parser.parse_args()
    
    if args.action == "workflow":
        result = run_compression_workflow(
            args.chat_id, args.user_id, 
            args.message, args.role, args.auto_simulate
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "validate":
        if not args.simulation_result:
            print("Error: --simulation-result required", file=sys.stderr)
            sys.exit(1)
        
        simulated = json.loads(args.simulation_result)
        result = process_simulation_result(args.chat_id, args.user_id, simulated)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "history":
        history = get_validation_history(args.chat_id, args.user_id)
        print(json.dumps(history, ensure_ascii=False, indent=2))
