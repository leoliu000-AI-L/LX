#!/usr/bin/env python3
"""
轮询压缩调度器 - 每N轮问答后自动压缩用户语言习惯
"""

import sys
import json
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.communication_entropy import calculate_user_entropy
from scripts.group_entropy_manager import set_user_entropy_profile

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

class CompressionScheduler:
    """压缩调度器 - 管理对话轮次和定期压缩"""
    
    def __init__(self, chat_id, compression_interval=5):
        self.chat_id = chat_id
        self.compression_interval = compression_interval
        self.state_file = os.path.join(DATA_DIR, f"scheduler_{chat_id}.json")
        self.load_state()
    
    def load_state(self):
        """加载调度器状态"""
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r', encoding='utf-8') as f:
                self.state = json.load(f)
        else:
            self.state = {
                "chat_id": self.chat_id,
                "created_at": datetime.now().isoformat(),
                "user_sessions": {},  # user_id -> session data
                "compression_history": []
            }
    
    def save_state(self):
        """保存调度器状态"""
        with open(self.state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)
    
    def record_interaction(self, user_id, message, role="user"):
        """
        记录一次互动
        
        Args:
            user_id: 用户ID
            message: 消息内容
            role: "user" 或 "assistant"
        
        Returns:
            是否需要压缩 (bool)
        """
        if user_id not in self.state["user_sessions"]:
            self.state["user_sessions"][user_id] = {
                "round_count": 0,
                "messages": [],
                "last_compression": None,
                "compression_count": 0
            }
        
        session = self.state["user_sessions"][user_id]
        
        # 记录消息
        session["messages"].append({
            "role": role,
            "content": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # 计算轮次（一轮 = user + assistant）
        if role == "assistant":
            session["round_count"] += 1
        
        # 检查是否达到压缩阈值
        should_compress = session["round_count"] >= self.compression_interval
        
        if should_compress:
            session["round_count"] = 0  # 重置计数
        
        self.save_state()
        return should_compress
    
    def compress_user_profile(self, user_id):
        """
        执行压缩 - 计算用户熵值并生成压缩档案
        
        Returns:
            compression_result: 压缩结果
        """
        session = self.state["user_sessions"].get(user_id)
        if not session or not session["messages"]:
            return {"error": "No messages to compress"}
        
        # 构建消息格式用于熵计算
        messages = []
        for msg in session["messages"]:
            messages.append({
                "sender": user_id if msg["role"] == "user" else "assistant",
                "content": msg["content"],
                "timestamp": msg["timestamp"]
            })
        
        # 计算熵值
        entropy_result = calculate_user_entropy(user_id, messages)
        
        if "error" in entropy_result:
            return entropy_result
        
        # 更新群聊熵档案
        profile = set_user_entropy_profile(self.chat_id, user_id, entropy_result)
        
        # 记录压缩历史
        compression_record = {
            "timestamp": datetime.now().isoformat(),
            "user_id": user_id,
            "round_count": len(session["messages"]) // 2,
            "entropy": entropy_result["entropy_metrics"],
            "predictability": entropy_result["predictability_score"],
            "compression_ratio": entropy_result["compression_ratio"],
            "keywords": entropy_result["compression_profile"]["keywords"]
        }
        
        self.state["compression_history"].append(compression_record)
        session["last_compression"] = datetime.now().isoformat()
        session["compression_count"] += 1
        
        # 清空已压缩的消息（保留最近2轮用于上下文）
        if len(session["messages"]) > 4:
            session["messages"] = session["messages"][-4:]
        
        self.save_state()
        
        return {
            "status": "compressed",
            "user_id": user_id,
            "compression_record": compression_record,
            "profile": profile
        }
    
    def get_user_status(self, user_id):
        """获取用户压缩状态"""
        session = self.state["user_sessions"].get(user_id, {})
        return {
            "user_id": user_id,
            "round_count": session.get("round_count", 0),
            "total_messages": len(session.get("messages", [])),
            "compression_count": session.get("compression_count", 0),
            "last_compression": session.get("last_compression"),
            "next_compression_in": self.compression_interval - session.get("round_count", 0)
        }
    
    def get_compression_history(self, user_id=None, limit=10):
        """获取压缩历史"""
        history = self.state["compression_history"]
        if user_id:
            history = [h for h in history if h["user_id"] == user_id]
        return history[-limit:]

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="轮询压缩调度器")
    parser.add_argument("action", choices=[
        "record", "compress", "status", "history", "init"
    ])
    parser.add_argument("--chat-id", "-c", required=True)
    parser.add_argument("--user-id", "-u")
    parser.add_argument("--message", "-m")
    parser.add_argument("--role", "-r", default="user", choices=["user", "assistant"])
    parser.add_argument("--interval", "-i", type=int, default=5, help="压缩间隔轮次")
    
    args = parser.parse_args()
    
    scheduler = CompressionScheduler(args.chat_id, args.interval)
    
    if args.action == "init":
        print(json.dumps({
            "status": "initialized",
            "chat_id": args.chat_id,
            "compression_interval": args.interval
        }, ensure_ascii=False))
    
    elif args.action == "record":
        if not args.user_id or not args.message:
            print("Error: --user-id and --message required", file=sys.stderr)
            sys.exit(1)
        
        should_compress = scheduler.record_interaction(args.user_id, args.message, args.role)
        status = scheduler.get_user_status(args.user_id)
        
        result = {
            "recorded": True,
            "should_compress": should_compress,
            "status": status
        }
        
        if should_compress:
            # 自动执行压缩
            compression_result = scheduler.compress_user_profile(args.user_id)
            result["compression_result"] = compression_result
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "compress":
        if not args.user_id:
            print("Error: --user-id required", file=sys.stderr)
            sys.exit(1)
        
        result = scheduler.compress_user_profile(args.user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "status":
        if args.user_id:
            status = scheduler.get_user_status(args.user_id)
            print(json.dumps(status, ensure_ascii=False, indent=2))
        else:
            # 显示所有用户状态
            all_status = {
                user_id: scheduler.get_user_status(user_id)
                for user_id in scheduler.state["user_sessions"].keys()
            }
            print(json.dumps(all_status, ensure_ascii=False, indent=2))
    
    elif args.action == "history":
        history = scheduler.get_compression_history(args.user_id)
        print(json.dumps(history, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
