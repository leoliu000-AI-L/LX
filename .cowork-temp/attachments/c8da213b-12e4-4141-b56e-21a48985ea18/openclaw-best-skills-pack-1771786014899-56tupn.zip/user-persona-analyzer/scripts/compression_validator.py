#!/usr/bin/env python3
"""
SubAgent模拟验证器 - 用模拟对话测试压缩效果

流程：
1. 获取用户压缩档案（关键词、熵值、风格指标）
2. 启动SubAgent模拟用户进行3轮对话
3. 对比模拟对话 vs 真实用户风格
4. 输出匹配度和优化建议
"""

import sys
import json
import os
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.group_entropy_manager import get_user_compression_params, load_group_entropy_config

class CompressionValidator:
    """压缩效果验证器"""
    
    def __init__(self, chat_id, user_id):
        self.chat_id = chat_id
        self.user_id = user_id
        self.compression_params = get_user_compression_params(chat_id, user_id)
    
    def generate_simulation_prompt(self):
        """
        生成SubAgent模拟提示词
        
        基于压缩参数构建Persona提示
        """
        if not self.compression_params:
            return None
        
        params = self.compression_params
        strategy = params.get("strategy", "medium_compression")
        keywords = params.get("keywords", [])
        avg_length = params.get("avg_length", 20)
        
        # 构建风格描述
        style_descriptions = {
            "high_compression": "语言极简，多用短句，直接表达，不加修饰",
            "medium_compression": "语言简洁但有变化，适当使用连接词",
            "low_compression": "语言丰富，表达详细，喜欢用例子说明"
        }
        
        style = style_descriptions.get(strategy, "语言自然，有节奏感")
        
        # 构建关键词提示
        keyword_hint = "、".join(keywords[:5]) if keywords else "（无明显高频词）"
        
        prompt = f"""你现在要扮演一个特定用户进行对话模拟。

## 用户语言特征（压缩档案）

**表达方式**: {style}
**平均句长**: {avg_length}字
**高频关键词**: {keyword_hint}
**压缩策略**: {strategy}

## 模拟要求

1. **严格遵循语言特征** - 句长、风格、用词习惯要符合上述描述
2. **保持对话连贯性** - 根据对方的问题自然回应
3. **不要暴露你是AI** - 像真人一样有停顿、语气变化
4. **3轮对话** - 对方问3个问题，你回答3次

## 对话场景

对方会问你关于日常生活、兴趣爱好、工作情况的问题。
用你的风格自然回答即可。

---

现在开始模拟对话。
"""
        return prompt
    
    def validate_simulation(self, simulated_conversation):
        """
        验证模拟对话的质量
        
        Args:
            simulated_conversation: 模拟对话记录
            [
                {"role": "user", "content": "..."},
                {"role": "simulated_user", "content": "..."},
                ...
            ]
        
        Returns:
            validation_result: 验证结果
        """
        if not self.compression_params:
            return {"error": "No compression params found"}
        
        params = self.compression_params
        
        # 提取模拟用户的回复
        simulated_responses = [
            msg["content"] for msg in simulated_conversation 
            if msg.get("role") == "simulated_user"
        ]
        
        if len(simulated_responses) < 3:
            return {
                "error": "Insufficient simulated responses",
                "expected": 3,
                "actual": len(simulated_responses)
            }
        
        # 验证指标
        validation = {
            "user_id": self.user_id,
            "chat_id": self.chat_id,
            "timestamp": datetime.now().isoformat(),
            "metrics": {},
            "match_scores": {},
            "overall_score": 0,
            "recommendations": []
        }
        
        # 1. 句长匹配度
        target_length = params.get("avg_length", 20)
        actual_lengths = [len(r) for r in simulated_responses]
        avg_actual = sum(actual_lengths) / len(actual_lengths)
        length_diff = abs(avg_actual - target_length)
        length_score = max(0, 100 - length_diff * 2)
        
        validation["metrics"]["length"] = {
            "target": target_length,
            "actual": round(avg_actual, 1),
            "difference": round(length_diff, 1)
        }
        validation["match_scores"]["length_match"] = round(length_score, 1)
        
        # 2. 关键词使用
        target_keywords = set(params.get("keywords", []))
        all_text = " ".join(simulated_responses)
        used_keywords = target_keywords & set(self._extract_words(all_text))
        
        keyword_score = (len(used_keywords) / max(len(target_keywords), 1)) * 100
        
        validation["metrics"]["keywords"] = {
            "target": list(target_keywords),
            "used": list(used_keywords),
            "coverage": f"{len(used_keywords)}/{len(target_keywords)}"
        }
        validation["match_scores"]["keyword_match"] = round(keyword_score, 1)
        
        # 3. 风格一致性检查
        style_checks = self._check_style_consistency(simulated_responses, params)
        validation["metrics"]["style"] = style_checks
        validation["match_scores"]["style_match"] = style_checks["score"]
        
        # 4. 整体匹配度
        overall = (length_score + keyword_score + style_checks["score"]) / 3
        validation["overall_score"] = round(overall, 1)
        
        # 5. 生成优化建议
        validation["recommendations"] = self._generate_recommendations(
            validation["metrics"], validation["match_scores"], overall
        )
        
        # 6. 是否需要重新压缩
        validation["needs_recompression"] = overall < 70
        
        return validation
    
    def _extract_words(self, text):
        """简单分词"""
        import re
        # 中文按字，英文按词
        words = re.findall(r'[\u4e00-\u9fff]|[a-zA-Z]+', text)
        return [w.lower() for w in words]
    
    def _check_style_consistency(self, responses, params):
        """检查风格一致性"""
        strategy = params.get("strategy", "medium_compression")
        
        checks = {
            "short_sentence_ratio": 0,
            "punctuation_usage": {},
            "formality_score": 50,
            "score": 0
        }
        
        # 检查短句比例（按标点分割）
        import re
        total_sentences = 0
        short_sentences = 0
        
        for resp in responses:
            sentences = re.split(r'[。！？\n]', resp)
            sentences = [s for s in sentences if s.strip()]
            total_sentences += len(sentences)
            short_sentences += sum(1 for s in sentences if len(s) < 15)
        
        if total_sentences > 0:
            checks["short_sentence_ratio"] = round(short_sentences / total_sentences, 2)
        
        # 根据策略评估
        if strategy == "high_compression":
            # 高压缩期望：短句多、简洁
            if checks["short_sentence_ratio"] > 0.6:
                checks["score"] = 90
            elif checks["short_sentence_ratio"] > 0.4:
                checks["score"] = 70
            else:
                checks["score"] = 50
        elif strategy == "low_compression":
            # 低压缩期望：长短句混合、详细
            if checks["short_sentence_ratio"] < 0.4:
                checks["score"] = 90
            elif checks["short_sentence_ratio"] < 0.6:
                checks["score"] = 70
            else:
                checks["score"] = 50
        else:
            # 中等压缩
            if 0.3 < checks["short_sentence_ratio"] < 0.7:
                checks["score"] = 85
            else:
                checks["score"] = 65
        
        return checks
    
    def _generate_recommendations(self, metrics, scores, overall):
        """生成优化建议"""
        recommendations = []
        
        if scores.get("length_match", 0) < 70:
            target = metrics["length"]["target"]
            actual = metrics["length"]["actual"]
            if actual > target:
                recommendations.append(f"模拟回复过长，建议压缩至约{target}字")
            else:
                recommendations.append(f"模拟回复过短，建议扩展至约{target}字")
        
        if scores.get("keyword_match", 0) < 50:
            recommendations.append("关键词使用不足，建议在回复中多使用目标关键词")
        
        if scores.get("style_match", 0) < 70:
            recommendations.append("风格匹配度较低，建议调整句式结构")
        
        if overall >= 85:
            recommendations.append("压缩效果良好，当前配置可用")
        elif overall >= 70:
            recommendations.append("压缩效果尚可，建议微调参数")
        else:
            recommendations.append("压缩效果不佳，建议重新计算熵值并调整压缩策略")
        
        return recommendations

def run_simulation_validation(chat_id, user_id, test_questions=None):
    """
    运行完整的模拟验证流程
    
    Args:
        chat_id: 群聊ID
        user_id: 用户ID
        test_questions: 测试问题列表（可选，默认3个通用问题）
    
    Returns:
        validation_result: 验证结果
    """
    validator = CompressionValidator(chat_id, user_id)
    
    # 生成模拟提示
    prompt = validator.generate_simulation_prompt()
    if not prompt:
        return {"error": "Failed to generate simulation prompt"}
    
    # 默认测试问题
    if not test_questions:
        test_questions = [
            "你最近有什么新发现或者感兴趣的事吗？",
            "你觉得现在这个功能怎么样？",
            "如果让你改进一个地方，你会改什么？"
        ]
    
    return {
        "status": "ready",
        "chat_id": chat_id,
        "user_id": user_id,
        "simulation_prompt": prompt,
        "test_questions": test_questions,
        "next_step": "使用sessions_spawn启动SubAgent，传入simulation_prompt和test_questions"
    }

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="压缩效果模拟验证")
    parser.add_argument("action", choices=["prepare", "validate"])
    parser.add_argument("--chat-id", "-c", required=True)
    parser.add_argument("--user-id", "-u", required=True)
    parser.add_argument("--simulation", "-s", help="模拟对话JSON（用于validate）")
    
    args = parser.parse_args()
    
    if args.action == "prepare":
        result = run_simulation_validation(args.chat_id, args.user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "validate":
        if not args.simulation:
            print("Error: --simulation required for validate", file=sys.stderr)
            sys.exit(1)
        
        simulated = json.loads(args.simulation)
        validator = CompressionValidator(args.chat_id, args.user_id)
        result = validator.validate_simulation(simulated)
        print(json.dumps(result, ensure_ascii=False, indent=2))
