#!/usr/bin/env python3
"""
分析用户聊天记录，提取语言风格和人格特征
"""

import sys
import json
import re
from collections import Counter

def analyze_chat(messages, user_id=None):
    """
    分析聊天记录
    messages: list of dict with keys: sender, content, timestamp
    user_id: 如果指定，只分析该用户的发言
    """
    
    # 过滤指定用户的消息
    if user_id:
        messages = [m for m in messages if m.get("sender") == user_id]
    
    if not messages:
        return {"error": "No messages to analyze"}
    
    result = {
        "message_count": len(messages),
        "language_style": {},
        "interaction_pattern": {},
        "persona_hints": []
    }
    
    all_text = " ".join([m.get("content", "") for m in messages])
    
    # === 语言风格分析 ===
    
    # 1. 平均句长
    sentences = re.split(r'[。！？\n]', all_text)
    sentences = [s.strip() for s in sentences if s.strip()]
    avg_length = sum(len(s) for s in sentences) / len(sentences) if sentences else 0
    result["language_style"]["avg_sentence_length"] = round(avg_length, 1)
    
    # 2. 语气词统计
    modal_words = re.findall(r'[啊呢吧嘛哦哈呀嘿]', all_text)
    result["language_style"]["modal_words_freq"] = len(modal_words)
    result["language_style"]["modal_words_top"] = Counter(modal_words).most_common(3)
    
    # 3. 表情符号/emoji
    emoji_pattern = r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]'
    emojis = re.findall(emoji_pattern, all_text)
    result["language_style"]["emoji_usage"] = "high" if len(emojis) > len(messages)/2 else "low"
    
    # 4. 问句比例（好奇心指标）
    questions = len(re.findall(r'[？?]', all_text))
    result["language_style"]["question_ratio"] = round(questions / len(messages), 2)
    
    # 5. 感叹号比例（情绪外显度）
    exclamations = len(re.findall(r'[！!]', all_text))
    result["language_style"]["exclamation_ratio"] = round(exclamations / len(messages), 2)
    
    # 6. 括号使用（补充说明习惯）
    brackets = len(re.findall(r'[（(].*?[）)]', all_text))
    result["language_style"]["uses_brackets"] = brackets > len(messages) / 3
    
    # === 互动模式分析 ===
    
    # 发言时机分析（需要完整聊天记录才能判断，这里简化）
    result["interaction_pattern"]["activity_level"] = "high" if len(messages) > 20 else "medium" if len(messages) > 5 else "low"
    
    # === 人格特征推测 ===
    
    hints = []
    
    if result["language_style"]["question_ratio"] > 0.3:
        hints.append("好奇心强，喜欢提问探索")
    
    if result["language_style"]["exclamation_ratio"] > 0.3:
        hints.append("情绪外显，表达直接")
    elif result["language_style"]["exclamation_ratio"] < 0.1:
        hints.append("情绪内敛，表达克制")
    
    if avg_length > 30:
        hints.append("倾向于详细论述")
    elif avg_length < 10:
        hints.append("言简意赅，喜欢短句")
    
    if len(modal_words) > len(messages):
        hints.append("语气柔和，亲和力强")
    
    if result["language_style"]["uses_brackets"]:
        hints.append("习惯补充说明，思维发散")
    
    result["persona_hints"] = hints
    
    return result

if __name__ == "__main__":
    # 从 stdin 读取 JSON 格式的消息列表
    try:
        data = json.load(sys.stdin)
        messages = data.get("messages", [])
        user_id = data.get("user_id")
        
        result = analyze_chat(messages, user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
