#!/usr/bin/env python3
"""
后台压缩执行器 - 异步执行压缩任务并优化Prompt
"""

import sys
import json
import os
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# 优化的压缩Prompt模板
OPTIMIZED_COMPRESSION_PROMPTS = {
    "high_predictability": """基于以下用户对话历史，生成该用户的语言模型指纹：

【用户关键词】：{keywords}
【平均句长】：{avg_length}字
【词汇熵】：{lexical_entropy}
【可预测性】：{predictability}%

请提取：
1. 核心口头禅（3-5个）
2. 句式模板（2-3个）
3. 话题偏好排序
4. 回应风格（直接/委婉/幽默）
5. 触发词（什么关键词会让他回应）

输出为结构化JSON格式。""",

    "medium_predictability": """分析用户沟通模式：

【样本消息】：
{sample_messages}

【关键指标】：
- 词汇熵：{lexical_entropy}
- 问句比例：{question_ratio}
- 平均句长：{avg_length}

请识别：
1. 语言风格（简洁/详细/跳跃）
2. 互动模式（主动/被动/观察）
3. 情绪表达（外显/内敛）
4. 知识领域偏好
5. 不适合模拟的边界情况

输出为压缩档案格式。""",

    "low_predictability": """该用户表达灵活多变，不适合高度压缩。

【对话特征】：
- 词汇熵：{lexical_entropy}（较高）
- 可预测性：{predictability}%（较低）
- 句长方差：{length_variance}

建议策略：
1. 保留最近20条原始消息
2. 提取关键词但不固化模板
3. 动态学习优先于静态规则
4. 模拟时保持灵活性

输出为低压缩策略配置。"""
}

def generate_compression_prompt(user_id, entropy_data, messages):
    """根据用户可预测性生成优化的压缩Prompt"""
    
    predictability = entropy_data.get("predictability_score", 50)
    
    # 选择Prompt模板
    if predictability >= 70:
        template = OPTIMIZED_COMPRESSION_PROMPTS["high_predictability"]
        strategy = "high"
    elif predictability >= 40:
        template = OPTIMIZED_COMPRESSION_PROMPTS["medium_predictability"]
        strategy = "medium"
    else:
        template = OPTIMIZED_COMPRESSION_PROMPTS["low_predictability"]
        strategy = "low"
    
    # 格式化Prompt
    prompt = template.format(
        keywords=", ".join(entropy_data.get("compression_profile", {}).get("keywords", [])[:10]),
        avg_length=entropy_data.get("compression_profile", {}).get("avg_length", 20),
        lexical_entropy=entropy_data.get("entropy_metrics", {}).get("lexical_entropy", 0),
        predictability=predictability,
        sample_messages="\n".join([m.get("content", "") for m in messages[-5:]]),
        question_ratio=entropy_data.get("entropy_metrics", {}).get("question_ratio", 0),
        length_variance=entropy_data.get("compression_profile", {}).get("sentence_length_variance", 0)
    )
    
    return {
        "strategy": strategy,
        "prompt": prompt,
        "user_id": user_id,
        "predictability": predictability
    }

def execute_background_compression(chat_id, user_id, force=False):
    """
    后台执行压缩任务
    
    Args:
        force: 是否强制压缩（忽略轮次限制）
    
    Returns:
        压缩任务状态
    """
    from scripts.compression_scheduler import CompressionScheduler
    from scripts.communication_entropy import calculate_user_entropy
    from scripts.group_entropy_manager import set_user_entropy_profile
    
    scheduler = CompressionScheduler(chat_id)
    session = scheduler.state["user_sessions"].get(user_id)
    
    if not session:
        return {"error": "No session found for user", "user_id": user_id}
    
    # 检查是否需要压缩
    if not force and session.get("round_count", 0) < scheduler.compression_interval:
        return {
            "status": "skipped",
            "reason": "Round count not reached",
            "rounds_remaining": scheduler.compression_interval - session.get("round_count", 0)
        }
    
    # 执行压缩
    result = scheduler.compress_user_profile(user_id)
    
    if "error" in result:
        return result
    
    # 生成优化后的Prompt
    messages = []
    for msg in session.get("messages", []):
        messages.append({
            "sender": user_id if msg["role"] == "user" else "assistant",
            "content": msg["content"],
            "timestamp": msg["timestamp"]
        })
    
    entropy_data = calculate_user_entropy(user_id, messages)
    optimized_prompt = generate_compression_prompt(user_id, entropy_data, messages)
    
    # 保存优化后的Prompt
    prompt_file = os.path.join(
        os.path.dirname(__file__), "..", "data",
        f"{user_id}_compression_prompt.json"
    )
    with open(prompt_file, 'w', encoding='utf-8') as f:
        json.dump(optimized_prompt, f, ensure_ascii=False, indent=2)
    
    return {
        "status": "compressed",
        "user_id": user_id,
        "compression_result": result,
        "optimized_prompt": optimized_prompt,
        "prompt_file": prompt_file,
        "timestamp": datetime.now().isoformat()
    }

def batch_background_compression(chat_id, force=False):
    """批量压缩群聊中所有用户"""
    from scripts.compression_scheduler import CompressionScheduler
    
    scheduler = CompressionScheduler(chat_id)
    results = []
    
    for user_id in scheduler.state["user_sessions"].keys():
        result = execute_background_compression(chat_id, user_id, force)
        results.append(result)
    
    return {
        "chat_id": chat_id,
        "total_users": len(results),
        "compressed": sum(1 for r in results if r.get("status") == "compressed"),
        "skipped": sum(1 for r in results if r.get("status") == "skipped"),
        "results": results
    }

def get_compression_prompt(user_id):
    """获取用户的优化压缩Prompt"""
    prompt_file = os.path.join(
        os.path.dirname(__file__), "..", "data",
        f"{user_id}_compression_prompt.json"
    )
    
    if os.path.exists(prompt_file):
        with open(prompt_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    return {"error": "No compression prompt found"}

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="后台压缩执行器")
    parser.add_argument("action", choices=[
        "compress", "batch", "get-prompt", "generate-only"
    ])
    parser.add_argument("--chat-id", "-c", required=True)
    parser.add_argument("--user-id", "-u")
    parser.add_argument("--force", "-f", action="store_true", help="强制压缩")
    parser.add_argument("--messages", "-m", help="JSON格式的消息列表")
    
    args = parser.parse_args()
    
    if args.action == "compress":
        if not args.user_id:
            print("Error: --user-id required", file=sys.stderr)
            sys.exit(1)
        
        result = execute_background_compression(args.chat_id, args.user_id, args.force)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "batch":
        result = batch_background_compression(args.chat_id, args.force)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "get-prompt":
        if not args.user_id:
            print("Error: --user-id required", file=sys.stderr)
            sys.exit(1)
        
        result = get_compression_prompt(args.user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "generate-only":
        if not args.user_id or not args.messages:
            print("Error: --user-id and --messages required", file=sys.stderr)
            sys.exit(1)
        
        messages = json.loads(args.messages)
        from scripts.communication_entropy import calculate_user_entropy
        entropy_data = calculate_user_entropy(args.user_id, messages)
        
        prompt_data = generate_compression_prompt(args.user_id, entropy_data, messages)
        print(json.dumps(prompt_data, ensure_ascii=False, indent=2))
