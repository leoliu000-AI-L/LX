#!/usr/bin/env python3
"""
对话后处理 - 自动迭代用户画像和沟通禁忌
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(__file__))
from auto_learn import update_profile_from_message, get_user_summary
from user_taboos import load_user_taboos, update_personal_taboos

def process_conversation(user_id, conversation_data):
    """
    处理一次完整对话，自动迭代所有维度
    
    conversation_data: {
        "messages": [
            {"role": "user/assistant", "content": "...", "timestamp": "..."}
        ],
        "metadata": {
            "response_time_ms": 1234,
            "context_length": 10
        }
    }
    """
    results = {
        "user_id": user_id,
        "profile_updated": False,
        "taboos_suggested": [],
        "insights": []
    }
    
    # 1. 提取用户消息进行分析
    user_messages = [m for m in conversation_data.get("messages", []) if m.get("role") == "user"]
    
    for msg in user_messages:
        msg_data = {
            "content": msg.get("content", ""),
            "timestamp": msg.get("timestamp"),
            "is_reply": len(conversation_data.get("messages", [])) > 1,
            "context_length": conversation_data.get("metadata", {}).get("context_length", 0)
        }
        
        # 自动更新用户画像
        update_profile_from_message(user_id, msg_data)
    
    results["profile_updated"] = True
    
    # 2. 分析并建议沟通禁忌更新
    taboos_suggestions = analyze_for_taboos(user_id, user_messages)
    results["taboos_suggested"] = taboos_suggestions
    
    # 3. 生成洞察
    summary = get_user_summary(user_id)
    results["insights"] = generate_insights(summary)
    
    return results

def analyze_for_taboos(user_id, messages):
    """分析消息，建议更新的沟通禁忌"""
    suggestions = []
    
    if not messages:
        return suggestions
    
    all_content = " ".join([m.get("content", "") for m in messages])
    
    # 检测过度使用emoji
    import re
    emoji_count = len(re.findall(r'[\U0001F600-\U0001F64F]', all_content))
    if emoji_count == 0 and len(messages) > 3:
        suggestions.append({
            "type": "preference_detected",
            "taboo": "对方极少使用emoji，建议减少或避免使用emoji",
            "confidence": 0.6
        })
    elif emoji_count > len(messages):
        suggestions.append({
            "type": "preference_detected", 
            "taboo": "对方高频使用emoji，可以适当使用emoji匹配风格",
            "confidence": 0.7
        })
    
    # 检测句长偏好
    avg_len = sum(len(m.get("content", "")) for m in messages) / len(messages)
    if avg_len < 20:
        suggestions.append({
            "type": "style_detected",
            "taboo": "对方偏好极简短句，避免长句和复杂结构",
            "confidence": 0.8
        })
    elif avg_len > 100:
        suggestions.append({
            "type": "style_detected",
            "taboo": "对方习惯详细论述，可以适当展开说明",
            "confidence": 0.7
        })
    
    # 检测标点使用
    exclaim_count = all_content.count('！') + all_content.count('!')
    if exclaim_count == 0 and len(messages) > 5:
        suggestions.append({
            "type": "preference_detected",
            "taboo": "对方从不使用感叹号，保持克制表达",
            "confidence": 0.75
        })
    
    return suggestions

def generate_insights(summary):
    """基于画像生成洞察建议"""
    insights = []
    
    mbti = summary.get("mbti")
    if mbti:
        insights.append(f"当前MBTI推测: {mbti} (置信度: {summary['confidence']})")
    
    sample_count = summary.get("sample_count", 0)
    if sample_count >= 10:
        insights.append(f"已积累{sample_count}条消息样本，画像逐渐稳定")
    
    traits = summary.get("key_traits", [])
    if traits:
        insights.append(f"观察到的特征: {', '.join(traits[:3])}")
    
    return insights

def auto_apply_suggestions(user_id, suggestions, dry_run=True):
    """自动应用建议的沟通禁忌"""
    applied = []
    
    for suggestion in suggestions:
        if suggestion.get("confidence", 0) > 0.7:  # 高置信度才自动应用
            taboo_text = suggestion.get("taboo", "")
            if dry_run:
                applied.append({
                    "taboo": taboo_text,
                    "status": "pending",
                    "action": "建议手动确认"
                })
            else:
                # 实际更新
                update_personal_taboos(user_id, [taboo_text])
                applied.append({
                    "taboo": taboo_text,
                    "status": "applied"
                })
    
    return applied

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="对话后自动处理")
    parser.add_argument("--user-id", "-u", required=True)
    parser.add_argument("--conversation", "-c", help="JSON格式的对话数据")
    parser.add_argument("--apply", action="store_true", help="自动应用建议")
    
    args = parser.parse_args()
    
    if args.conversation:
        conv_data = json.loads(args.conversation)
    else:
        # 从stdin读取
        conv_data = json.load(sys.stdin)
    
    result = process_conversation(args.user_id, conv_data)
    
    if args.apply:
        applied = auto_apply_suggestions(args.user_id, result["taboos_suggested"], dry_run=False)
        result["auto_applied"] = applied
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
