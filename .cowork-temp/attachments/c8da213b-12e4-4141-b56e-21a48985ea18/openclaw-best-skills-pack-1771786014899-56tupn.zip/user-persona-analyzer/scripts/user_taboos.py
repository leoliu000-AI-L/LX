#!/usr/bin/env python3
"""
用户沟通禁忌管理 - 按用户ID存储和检索
"""

import sys
import json
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

def get_user_taboos_path(user_id):
    """获取用户禁忌文件路径"""
    # 清理用户ID中的特殊字符
    safe_id = "".join(c for c in user_id if c.isalnum() or c in "_-").lower()
    return os.path.join(DATA_DIR, f"{safe_id}_taboos.json")

def load_user_taboos(user_id):
    """加载用户的沟通禁忌配置"""
    path = get_user_taboos_path(user_id)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None

def save_user_taboos(user_id, taboos_config):
    """保存用户的沟通禁忌配置"""
    path = get_user_taboos_path(user_id)
    config = {
        "user_id": user_id,
        "updated_at": import_time(),
        **taboos_config
    }
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    return config

def import_time():
    from datetime import datetime
    return datetime.now().isoformat()

def create_default_taboos(user_id, notes=None):
    """创建默认禁忌配置"""
    config = {
        "global_taboos": [
            "去格式化 - 删除首先/其次/最后等结构",
            "减少介词和形容词占比",
            "避免解释性说明（之所以...是因为...）"
        ],
        "personal_taboos": [],
        "preferred_style": {
            "sentence_structure": "短句",
            "punctuation": "空格替代标点",
            "explanation": "禁止",
            "emoji": "根据场景"
        },
        "examples": {
            "avoid": [],
            "preferred": []
        },
        "notes": notes or ""
    }
    return save_user_taboos(user_id, config)

def update_personal_taboos(user_id, new_taboos, notes=None):
    """更新个人禁忌"""
    config = load_user_taboos(user_id)
    if not config:
        config = create_default_taboos(user_id)
    
    if isinstance(new_taboos, list):
        config["personal_taboos"] = list(set(config.get("personal_taboos", []) + new_taboos))
    else:
        config["personal_taboos"].append(new_taboos)
    
    if notes:
        config["notes"] = notes
    
    return save_user_taboos(user_id, config)

def get_merged_taboos(user_id):
    """获取合并后的禁忌列表（全局 + 个人）"""
    config = load_user_taboos(user_id)
    if not config:
        return None
    
    global_taboos = config.get("global_taboos", [])
    personal_taboos = config.get("personal_taboos", [])
    
    return {
        "user_id": user_id,
        "all_taboos": global_taboos + personal_taboos,
        "global": global_taboos,
        "personal": personal_taboos,
        "style": config.get("preferred_style", {})
    }

def add_example(user_id, bad_example, good_example):
    """添加正反例"""
    config = load_user_taboos(user_id)
    if not config:
        config = create_default_taboos(user_id)
    
    config["examples"]["avoid"].append(bad_example)
    config["examples"]["preferred"].append(good_example)
    
    return save_user_taboos(user_id, config)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="用户沟通禁忌管理")
    parser.add_argument("action", choices=["create", "get", "update", "add-example", "list"])
    parser.add_argument("--user-id", "-u", required=True, help="用户ID")
    parser.add_argument("--taboos", "-t", help="个人禁忌（逗号分隔或JSON）")
    parser.add_argument("--notes", "-n", help="备注")
    parser.add_argument("--bad", help="反面示例")
    parser.add_argument("--good", help="正面示例")
    
    args = parser.parse_args()
    
    if args.action == "create":
        result = create_default_taboos(args.user_id, args.notes)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "get":
        result = get_merged_taboos(args.user_id)
        if result:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"error": "User not found"}, ensure_ascii=False))
    
    elif args.action == "update":
        taboos = args.taboos.split(",") if args.taboos else []
        result = update_personal_taboos(args.user_id, taboos, args.notes)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "add-example":
        result = add_example(args.user_id, args.bad, args.good)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "list":
        # 列出所有用户ID
        import glob
        files = glob.glob(os.path.join(DATA_DIR, "*_taboos.json"))
        users = []
        for f in files:
            with open(f, 'r') as file:
                data = json.load(file)
                users.append({
                    "user_id": data.get("user_id"),
                    "updated_at": data.get("updated_at")
                })
        print(json.dumps(users, ensure_ascii=False, indent=2))
