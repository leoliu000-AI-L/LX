#!/usr/bin/env python3
"""
Hook 集成脚本 - 自动记录用户消息并触发压缩

使用场景：集成到 OpenClaw 消息处理流程
"""

import sys
import json
import os

# 添加父目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.compression_scheduler import CompressionScheduler
from scripts.communication_entropy import calculate_user_entropy
from scripts.group_entropy_manager import set_user_entropy_profile

def on_user_message(chat_id, user_id, message_content, metadata=None):
    """
    用户消息 Hook - 每收到一条消息调用
    
    Args:
        chat_id: 群聊ID
        user_id: 用户ID  
        message_content: 消息内容
        metadata: 可选元数据（时间戳、角色等）
    
    Returns:
        dict: 处理结果，包含是否需要压缩
    """
    scheduler = CompressionScheduler(chat_id, compression_interval=5)
    
    # 记录用户消息
    should_compress = scheduler.record_interaction(
        user_id=user_id,
        message=message_content,
        role="user"
    )
    
    result = {
        "chat_id": chat_id,
        "user_id": user_id,
        "recorded": True,
        "should_compress": should_compress,
        "status": scheduler.get_user_status(user_id)
    }
    
    # 如果达到压缩阈值，自动执行压缩
    if should_compress:
        compression_result = scheduler.compress_user_profile(user_id)
        result["compression_result"] = compression_result
        
        # 如果有压缩结果，触发后续处理
        if "compression_record" in compression_result:
            # 这里可以触发 SubAgent 模拟测试
            result["next_action"] = "trigger_simulation"
            result["simulation_config"] = {
                "user_id": user_id,
                "keywords": compression_result["compression_record"]["keywords"],
                "predictability": compression_result["compression_record"]["predictability"]
            }
    
    return result

def on_assistant_reply(chat_id, user_id, reply_content):
    """
    助手回复 Hook - 每次回复后调用
    
    用于记录完整对话轮次
    """
    scheduler = CompressionScheduler(chat_id, compression_interval=5)
    
    # 记录助手回复（更新轮次计数）
    should_compress = scheduler.record_interaction(
        user_id=user_id,
        message=reply_content,
        role="assistant"
    )
    
    return {
        "chat_id": chat_id,
        "user_id": user_id,
        "round_recorded": True,
        "should_compress": should_compress
    }

def get_user_context(chat_id, user_id, context_type="full"):
    """
    获取用户上下文
    
    Args:
        context_type: "full" | "compressed" | "recent"
    """
    scheduler = CompressionScheduler(chat_id)
    session = scheduler.state["user_sessions"].get(user_id, {})
    
    if context_type == "recent":
        # 返回最近 2 轮对话
        return {
            "user_id": user_id,
            "recent_messages": session.get("messages", [])[-4:],
            "round_count": session.get("round_count", 0)
        }
    
    elif context_type == "compressed":
        # 返回压缩档案
        import glob
        data_dir = os.path.join(os.path.dirname(__file__), "..", "data")
        profile_files = glob.glob(os.path.join(data_dir, f"group_{chat_id}_entropy.json"))
        
        if profile_files:
            with open(profile_files[0], 'r') as f:
                group_data = json.load(f)
                profile = group_data.get("user_entropy_profiles", {}).get(user_id)
                if profile:
                    return {
                        "user_id": user_id,
                        "compression_profile": profile.get("compression_profile"),
                        "predictability": profile.get("predictability_score"),
                        "strategy": profile.get("communication_strategy")
                    }
        return {"error": "No compressed profile found"}
    
    else:  # full
        # 返回完整信息
        return {
            "user_id": user_id,
            "session": session,
            "status": scheduler.get_user_status(user_id)
        }

def check_compression_ready(chat_id, user_id):
    """检查用户是否达到压缩条件"""
    scheduler = CompressionScheduler(chat_id)
    status = scheduler.get_user_status(user_id)
    
    return {
        "user_id": user_id,
        "ready": status["next_compression_in"] <= 0,
        "rounds_remaining": status["next_compression_in"],
        "total_messages": status["total_messages"]
    }

# Hook 处理器注册表
HOOK_REGISTRY = {
    "on_user_message": on_user_message,
    "on_assistant_reply": on_assistant_reply,
    "get_user_context": get_user_context,
    "check_compression_ready": check_compression_ready
}

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Hook 集成工具")
    parser.add_argument("action", choices=[
        "user-message", "assistant-reply", "get-context", "check-ready"
    ])
    parser.add_argument("--chat-id", "-c", required=True)
    parser.add_argument("--user-id", "-u", required=True)
    parser.add_argument("--message", "-m", help="消息内容")
    parser.add_argument("--context-type", "-t", default="recent", 
                       choices=["full", "compressed", "recent"])
    
    args = parser.parse_args()
    
    if args.action == "user-message":
        if not args.message:
            print("Error: --message required", file=sys.stderr)
            sys.exit(1)
        
        result = on_user_message(args.chat_id, args.user_id, args.message)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "assistant-reply":
        if not args.message:
            print("Error: --message required", file=sys.stderr)
            sys.exit(1)
        
        result = on_assistant_reply(args.chat_id, args.user_id, args.message)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "get-context":
        result = get_user_context(args.chat_id, args.user_id, args.context_type)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "check-ready":
        result = check_compression_ready(args.chat_id, args.user_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
