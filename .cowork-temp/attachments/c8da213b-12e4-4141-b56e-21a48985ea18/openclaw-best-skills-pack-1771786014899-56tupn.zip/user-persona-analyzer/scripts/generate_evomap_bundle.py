#!/usr/bin/env python3
"""
EvoMap Bundle Generator - 为 user-persona-analyzer 生成 Gene + Capsule + EvolutionEvent
"""

import json
import hashlib
import os
from datetime import datetime

def canonical_json(obj):
    """生成规范的JSON（排序键）"""
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

def compute_asset_id(asset):
    """计算 asset_id (SHA256 of canonical JSON without asset_id)"""
    # 复制asset，移除asset_id字段
    asset_copy = {k: v for k, v in asset.items() if k != 'asset_id'}
    canonical = canonical_json(asset_copy)
    return f"sha256:{hashlib.sha256(canonical.encode('utf-8')).hexdigest()}"

def generate_gene():
    """生成 Gene - 策略模板"""
    gene = {
        "type": "Gene",
        "schema_version": "1.5.0",
        "category": "innovate",
        "signals_match": [
            "user_persona_analysis",
            "communication_style_detection",
            "auto_learn_user_preferences"
        ],
        "summary": "通过多维度分析（名字、聊天记录、语言风格）自动构建用户人格画像，并持续迭代沟通策略",
        "validation": [
            "python3 scripts/analyze_name.py '测试'",
            "python3 scripts/auto_learn.py summary --user-id 'test_user'"
        ]
    }
    gene["asset_id"] = compute_asset_id(gene)
    return gene

def generate_capsule(gene_id):
    """生成 Capsule - 具体实现"""
    capsule = {
        "type": "Capsule",
        "schema_version": "1.5.0",
        "trigger": [
            "user_onboarding",
            "persona_clone_request",
            "communication_optimization"
        ],
        "gene": gene_id,
        "summary": "User Persona Analyzer v1.0 - 自动分析用户名字含义、聊天记录语言风格、MBTI推测，并持续迭代沟通禁忌和语言习惯。支持主动发起非问题型沟通（打招呼、分享洞察）。",
        "confidence": 0.85,
        "blast_radius": {
            "files": 8,
            "lines": 1200
        },
        "outcome": {
            "status": "success",
            "score": 0.85
        },
        "success_streak": 1,
        "env_fingerprint": {
            "platform": "linux",
            "arch": "arm64",
            "python_version": "3.13"
        }
    }
    capsule["asset_id"] = compute_asset_id(capsule)
    return capsule

def generate_evolution_event(capsule_id, gene_id):
    """生成 EvolutionEvent - 进化过程记录"""
    event = {
        "type": "EvolutionEvent",
        "intent": "innovate",
        "capsule_id": capsule_id,
        "genes_used": [gene_id],
        "outcome": {
            "status": "success",
            "score": 0.85
        },
        "mutations_tried": 5,
        "total_cycles": 8,
        "notes": "从基础用户分析扩展到自动迭代学习，增加MBTI推测、沟通禁忌管理、主动沟通触发机制"
    }
    event["asset_id"] = compute_asset_id(event)
    return event

def generate_bundle():
    """生成完整的 Gene + Capsule + EvolutionEvent bundle"""
    gene = generate_gene()
    capsule = generate_capsule(gene["asset_id"])
    event = generate_evolution_event(capsule["asset_id"], gene["asset_id"])
    
    bundle = {
        "gene": gene,
        "capsule": capsule,
        "evolution_event": event,
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "skill_name": "user-persona-analyzer",
            "version": "1.0.0"
        }
    }
    
    return bundle

if __name__ == "__main__":
    bundle = generate_bundle()
    print(json.dumps(bundle, ensure_ascii=False, indent=2))
    
    # 保存到文件
    output_dir = os.path.join(os.path.dirname(__file__), "..", "evomap_bundle")
    os.makedirs(output_dir, exist_ok=True)
    
    with open(os.path.join(output_dir, "bundle.json"), 'w', encoding='utf-8') as f:
        json.dump(bundle, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Bundle saved to: {output_dir}/bundle.json")
    print(f"   Gene ID: {bundle['gene']['asset_id'][:20]}...")
    print(f"   Capsule ID: {bundle['capsule']['asset_id'][:20]}...")
    print(f"   Event ID: {bundle['evolution_event']['asset_id'][:20]}...")
