---
name: user-persona-analyzer
description: 用户人格分析与分身构建。通过名字分析家庭期望生成破冰问题，通过聊天记录分析语言风格和人格特征，构建用户AI分身。使用场景：(1) 新用户破冰，(2) 深度用户画像，(3) 人格模拟与风格迁移。
---

# 用户人格分析器

## 功能概述

本技能提供三个核心能力：
1. **名字分析** → 推测家庭期望 → 生成破冰问题
2. **聊天记录分析** → 提取语言风格 → 构建人格画像
3. **用户分身** → 生成可复用的AI人格档案

## 核心工作流

### 1. 名字分析（破冰启动）

**使用场景**：认识新用户，需要引起兴趣

```bash
python3 scripts/analyze_name.py "用户名"
```

**输出**：
- 单字含义解析
- 家庭期望推测（品德/才华/成就/性格/平安）
- 代际特征提示
- 3个破冰问题

**应用策略**：
- 首选"验证型"问题验证推测
- 次选"好奇型"问题拉近距离
- 避免直接问"名字什么意思"这种无聊问题

### 2. 聊天记录分析（深度画像）

**使用场景**：已有互动记录，想深度理解用户

**数据格式**：
```json
{
  "messages": [
    {"sender": "user_id", "content": "消息内容", "timestamp": "..."},
    ...
  ],
  "user_id": "目标用户ID（可选）"
}
```

**运行**：
```bash
cat chat_data.json | python3 scripts/analyze_chat.py
```

**分析维度**：
- 平均句长（详细vs简洁）
- 问句比例（好奇心/主导性）
- 感叹号比例（情绪外显度）
- 括号使用（补充说明习惯）
- 语气词频率（亲和力）
- 活跃度分级

**参考文档**：[persona-dimensions.md](references/persona-dimensions.md)

### 3. 分身构建

**使用场景**：需要模拟用户风格或长期跟踪

```bash
echo '{"name": "...", "name_analysis": {...}, "chat_analysis": {...}}' | python3 scripts/generate_clone.py
```

**输出**：完整的分身档案，包含说话风格、典型反应、知识领域、互动偏好

**参考文档**：[persona-clone-guide.md](references/persona-clone-guide.md)

### 4. 书面沟通禁忌管理（按用户ID）

**使用场景**：为特定用户定制沟通风格，并按用户ID持久化存储

**管理脚本**：`scripts/user_taboos.py`

#### 创建用户禁忌配置
```bash
python3 scripts/user_taboos.py create --user-id "ou_xxx" --notes "该用户偏好极简风格"
```

#### 查询用户禁忌（合并全局+个人）
```bash
python3 scripts/user_taboos.py get --user-id "ou_xxx"
```

**输出示例**：
```json
{
  "user_id": "ou_xxx",
  "all_taboos": [
    "去格式化 - 删除首先/其次/最后等结构",
    "减少介词和形容词占比",
    "避免解释性说明",
    "禁止emoji"
  ],
  "global": [...],
  "personal": ["禁止emoji"],
  "style": {
    "sentence_structure": "短句",
    "punctuation": "空格替代标点"
  }
}
```

#### 更新个人禁忌
```bash
python3 scripts/user_taboos.py update --user-id "ou_xxx" --taboos "禁止emoji,禁用感叹号"
```

#### 添加正反例
```bash
python3 scripts/user_taboos.py add-example --user-id "ou_xxx" \
  --bad "我觉得这个非常好" \
  --good "这个好"
```

#### 列出所有用户
```bash
python3 scripts/user_taboos.py list
```

#### 数据存储
- 位置：`data/{user_id}_taboos.json`
- 按用户ID隔离，安全存储
- 支持全局模板 + 个人覆盖

### 5. 自动迭代学习（核心功能）

**使用场景**：在沟通过程中持续学习用户特征，自动迭代画像和沟通禁忌

**核心脚本**：
- `auto_learn.py` - 单条消息学习和画像更新
- `post_chat_process.py` - 对话后批量处理和洞察生成

#### 快速开始：对话后自动处理

```bash
echo '{
  "messages": [
    {"role": "user", "content": "这个功能怎么用？", "timestamp": "2026-02-22T14:00:00"},
    {"role": "assistant", "content": "你可以这样...", "timestamp": "2026-02-22T14:00:05"},
    {"role": "user", "content": "明白了，谢谢", "timestamp": "2026-02-22T14:00:10"}
  ],
  "metadata": {"response_time_ms": 5000}
}' | python3 scripts/post_chat_process.py --user-id "ou_xxx"
```

**输出**：
```json
{
  "user_id": "ou_xxx",
  "profile_updated": true,
  "taboos_suggested": [
    {"type": "style_detected", "taboo": "对方偏好极简短句", "confidence": 0.8}
  ],
  "insights": [
    "当前MBTI推测: INTP (置信度: 0.65)",
    "已积累12条消息样本，画像逐渐稳定"
  ]
}
```

#### 单条消息实时学习

```bash
python3 scripts/auto_learn.py update --user-id "ou_xxx" \
  --message '{"content": "这个想法不错", "timestamp": "...", "is_reply": true}'
```

#### 查看用户画像摘要

```bash
python3 scripts/auto_learn.py summary --user-id "ou_xxx"
```

**输出**：
```json
{
  "user_id": "ou_xxx",
  "mbti": "INTP",
  "confidence": 0.72,
  "sample_count": 25,
  "key_traits": ["言简意赅(I倾向)", "好奇心强", "情绪内敛"],
  "language_style": {
    "avg_length": 18.5,
    "question_ratio": 0.35,
    "emoji_usage": "low"
  }
}
```

#### 自动学习机制

**学习维度**：
1. **MBTI推测** - 基于语言特征推断性格类型
2. **语言习惯** - 句长、问句比例、emoji使用（滑动平均更新）
3. **沟通禁忌** - 自动检测并建议（emoji偏好、句长偏好、标点习惯）
4. **性格特征** - 好奇心、情绪外显度、思维发散度

**迭代逻辑**：
- 每条消息实时更新画像
- 使用滑动平均平滑特征变化
- 置信度随样本量增加
- 高置信度禁忌建议可自动应用

#### 在OpenClaw中集成

**建议方案** - 在每次回复后自动触发：

```python
# 伪代码示例
async def on_message(user_id, message):
    # 正常回复...
    response = await generate_response(message)
    
    # 对话后自动学习
    conversation = {
        "messages": [{"role": "user", "content": message},
                     {"role": "assistant", "content": response}],
        "metadata": {"response_time_ms": response_time}
    }
    
    # 异步触发学习（不阻塞回复）
    asyncio.create_task(
        post_chat_process(user_id, conversation)
    )
    
    return response
```

#### 数据文件

- **画像数据**：`data/{user_id}_profile.json`
- **禁忌配置**：`data/{user_id}_taboos.json`

### 6. EvoMap 集成（协同进化）

**使用场景**：将 skill 发布到 EvoMap 市场，与其他 AI 协同进化

#### 生成 EvoMap Bundle

```bash
python3 scripts/generate_evomap_bundle.py
```

生成 Gene + Capsule + EvolutionEvent 完整 bundle：
- **Gene**: 策略模板（用户多维度分析与自动迭代）
- **Capsule**: 具体实现（User Persona Analyzer v1.0）
- **EvolutionEvent**: 进化记录（从基础分析到自动学习）

#### 发布到 EvoMap

```bash
# 1. 注册节点
python3 scripts/evomap_cli.py hello

# 2. 发布 Bundle
python3 scripts/evomap_cli.py publish --bundle evomap_bundle/bundle.json

# 3. 获取节点状态
python3 scripts/evomap_cli.py status
```

**发布后**：
- Bundle 进入 `candidate` 状态等待验证
- 验证通过后变为 `promoted`，可供其他 agent 使用
- 用户可通过 claim_url 绑定节点获取收益

#### EvoMap 收益机制

- 其他 agent 使用你的 Capsule 解决问题时，你获得 credits
- 高质量贡献提升 reputation（0-100），解锁更高收益倍率
- 可认领 bounty 任务获取额外收益

---

## 进阶：主动沟通触发机制

### 核心理念
主动沟通**不一定是问题**，可以是：
- 打招呼/问候
- 分享洞察/发现
- 提供帮助
- 简单的情绪共鸣

### 触发策略

#### 触发时机
```python
# 新用户加入
if new_user_joined:
    persona = analyze_from_first_message(user_id, message)
    send_greeting(user_id, persona)  # 基于画像的个性化问候

# 长时间未互动后的重逢
if days_since_last_chat > 7:
    summary = get_user_summary(user_id)
    send("好久不见，上次聊到你正在..." + summary["key_traits"][0])

# 检测到情绪信号
if detect_emotion(message) in ["frustrated", "excited"]:
    respond_with_empathy(user_id, emotion)

# 画像完成度达到阈值
if profile["sample_count"] == 10:
    share_insight(user_id, "我发现你是那种...的人")
```

#### 非问题型沟通示例

| 场景 | 传统方式 ❌ | 主动方式 ✅ |
|------|------------|------------|
| 新用户 | "你好，有什么可以帮你的？" | "看你头像是猫，你家主子是什么品种？" |
| 久未联系 | （沉默） | "好久没聊，上次你说的那件事怎么样了？" |
| 深夜在线 | （无反应） | "这么晚还在，是在赶项目吗？" |
| 发现共同点 | （不说） | "原来你也看《XXX》，最新一集看了吗？" |
| 用户取得成就 | （等对方说） | "恭喜！看到你发的XXX了，厉害啊" |

### 与 EvoMap 结合

发布到 EvoMap 后，其他 agent 可以：
1. **获取你的 Capsule** - 复用用户分析能力
2. **贡献改进** - 提交更好的沟通策略
3. **认领 bounty** - 解决特定的用户分析需求

你的 skill 因此持续进化，而无需手动更新。

---

## 进阶：沟通熵计算（信息论量化）

### 核心概念

**沟通熵** = 香农熵（Shannon Entropy）应用于用户语言分析：
- **熵值高** = 信息不确定性大 = 沟通风格多变 = **难以预测**
- **熵值低** = 沟通有规律 = 习惯明显 = **容易模拟**

**压缩思维**：模拟用户发言 = 压缩/解压缩过程
- **关键词 + 指标** = 压缩表示（低熵用户可高度压缩）
- **完整语料** = 原始数据（高熵用户需保留更多）

### 脚本：`communication_entropy.py`

#### 计算单个用户熵值

```bash
cat messages.json | python3 scripts/communication_entropy.py user --user-id "ou_xxx"
```

**输出**：
```json
{
  "user_id": "ou_xxx",
  "entropy_metrics": {
    "lexical_entropy": 4.52,      // 词汇熵（用词多样性）
    "structural_entropy": 2.1,    // 结构熵（句式多样性）
    "temporal_entropy": 3.2,      // 时间熵（活跃时段分布）
    "conditional_entropy": 0.35   // 条件熵（上下文可预测性）
  },
  "predictability_score": 65,      // 可预测性分数 (0-100)
  "compression_ratio": 0.25,       // 压缩率
  "compression_profile": {
    "keywords": ["好", "可以", "试试"],
    "avg_length": 15,
    "active_hours": [14, 15, 21]
  },
  "summary": "词汇使用适中，有一定规律性；句式长度稳定；整体可预测性中等"
}
```

#### 计算群聊全局熵值

```bash
cat chat_messages.json | python3 scripts/communication_entropy.py group --chat-id "oc_xxx"
```

**输出**：
```json
{
  "group": {
    "chat_id": "oc_xxx",
    "user_count": 5,
    "group_entropy": {
      "average_lexical_entropy": 5.2,
      "entropy_variance": 1.8,
      "average_predictability": 58
    },
    "group_type": "分层群聊 - 存在明显不同的表达群体",
    "compression_strategy": [
      "高可预测用户(2人): 可用关键词+指标精准模拟",
      "低可预测用户(1人): 需保留更多原始语料",
      "群聊高频词: ['好', '可以', '没问题']"
    ]
  },
  "users": [...]
}
}
```

#### 用户间对比

```bash
cat messages.json | python3 scripts/communication_entropy.py compare
```

### 群聊熵值管理：`group_entropy_manager.py`

#### 初始化群聊配置

```bash
python3 scripts/group_entropy_manager.py init --chat-id "oc_xxx"
```

#### 设置用户熵档案

```bash
python3 scripts/group_entropy_manager.py set-user \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --entropy-data '{"lexical_entropy": 3.5, "predictability_score": 75, ...}'
```

#### 获取用户压缩参数

```bash
python3 scripts/group_entropy_manager.py get-compression-params \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx"
```

**输出**（高可预测用户）：
```json
{
  "strategy": "high_compression",
  "compression_ratio": 0.1,
  "keywords": ["好", "可以", "试试"],
  "avg_length": 15,
  "template_based": true
}
```

**压缩策略对照表**：

| 可预测性 | 压缩策略 | 压缩率 | 实现方式 |
|---------|---------|--------|---------|
| 高(>70) | high_compression | 0.1 | 关键词+模板生成 |
| 中(40-70) | medium_compression | 0.3 | 关键词+部分语料 |
| 低(<40) | low_compression | 0.7 | 完整语料+动态学习 |

#### 查看群聊报告

```bash
python3 scripts/group_entropy_manager.py get-report --chat-id "oc_xxx"
```

### 熵值解读指南

| 词汇熵 | 含义 | 模拟难度 |
|-------|------|---------|
| 0-3 | 用词高度重复，口头禅明显 | 极易模拟 |
| 3-5 | 词汇使用适中，有一定规律 | 中等难度 |
| 5-8 | 词汇丰富，风格多变 | 较难模拟 |
| >8 | 词汇高度多样，难以捉摸 | 极难模拟 |

| 可预测性分数 | 沟通策略 |
|-------------|---------|
| >70 | 使用模板化回复，关键词驱动 |
| 40-70 | 混合策略，保留灵活性 |
| <40 | 保留完整语料，持续学习 |

### 与自动学习的结合

```python
# 工作流程示例
async def on_conversation_end(chat_id, user_id, messages):
    # 1. 计算沟通熵
    entropy = calculate_user_entropy(user_id, messages)
    
    # 2. 更新群聊熵档案
    set_user_entropy_profile(chat_id, user_id, entropy)
    
    # 3. 获取压缩参数用于后续模拟
    compression_params = get_user_compression_params(chat_id, user_id)
    
    # 4. 根据熵值调整主动沟通策略
    if entropy["predictability_score"] > 70:
        # 高可预测用户 - 可以大胆使用模板
        enable_template_responses(user_id)
    else:
        # 低可预测用户 - 保留更多变化
        enable_dynamic_responses(user_id)
```

### 数据文件

- **用户熵档案**：`data/group_{chat_id}_entropy.json`
- **包含**：全局阈值、用户档案、压缩策略、群聊统计

---

## 进阶：定期压缩与模拟验证

### 核心理念

**压缩-验证循环**：
1. 每 **N 轮对话** 后自动压缩用户语言习惯
2. 使用 **SubAgent 模拟** 3轮对话验证压缩效果
3. 根据验证结果决定：**接受 / 调整 / 重新压缩**

### 脚本：`compression_scheduler.py`（定期压缩）

#### 初始化调度器

```bash
python3 scripts/compression_scheduler.py init --chat-id "oc_xxx" --interval 5
```

#### 记录互动（自动触发压缩）

```bash
# 用户消息
python3 scripts/compression_scheduler.py record \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --message "用户说的话" \
  --role user

# AI回复
python3 scripts/compression_scheduler.py record \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --message "AI的回复" \
  --role assistant
```

**输出**（第5轮自动压缩）：
```json
{
  "recorded": true,
  "should_compress": true,
  "compression_result": {
    "status": "compressed",
    "compression_record": {
      "round_count": 5,
      "predictability": 76,
      "compression_ratio": 0.3,
      "keywords": ["好", "可以", "试试"]
    }
  }
}
```

#### 查看压缩状态

```bash
python3 scripts/compression_scheduler.py status --chat-id "oc_xxx" --user-id "ou_xxx"
```

### 脚本：`compression_validator.py`（模拟验证）

#### 准备模拟

```bash
python3 scripts/compression_validator.py prepare --chat-id "oc_xxx" --user-id "ou_xxx"
```

**输出**：
```json
{
  "status": "ready",
  "simulation_prompt": "你现在要扮演一个特定用户...",
  "test_questions": [
    "你最近有什么新发现？",
    "你觉得这个功能怎么样？",
    "如果改进一个地方，你会改什么？"
  ]
}
```

#### 使用 SubAgent 进行模拟

```bash
# 使用 OpenClaw sessions_spawn 启动 SubAgent
openclaw sessions_spawn \
  --task "基于以下提示模拟用户进行3轮对话：\n\n<simulation_prompt>" \
  --mode run \
  --timeout 120
```

#### 验证模拟结果

```bash
python3 scripts/compression_validator.py validate \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --simulation '<模拟对话JSON>'
```

**输出**：
```json
{
  "overall_score": 78.5,
  "match_scores": {
    "length_match": 85,
    "keyword_match": 60,
    "style_match": 90
  },
  "recommendations": [
    "关键词使用不足，建议增加目标关键词",
    "压缩效果良好，当前配置可用"
  ],
  "needs_recompression": false
}
```

### 完整工作流：`compression_workflow.py`

#### 自动运行完整流程

```bash
python3 scripts/compression_workflow.py workflow \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --message "用户消息" \
  --auto-simulate
```

**输出**（达到压缩阈值时）：
```json
{
  "steps": [
    {"step": "record_interaction", "should_compress": true},
    {"step": "compress", "predictability": 76},
    {"step": "prepare_simulation", "test_questions": [...]},
    {"step": "auto_simulate_ready"}
  ],
  "next_action": "spawn_subagent",
  "subagent_config": {
    "task": "模拟用户对话...",
    "mode": "run",
    "timeout": 120
  }
}
```

#### 处理模拟结果

```bash
python3 scripts/compression_workflow.py validate \
  --chat-id "oc_xxx" \
  --user-id "ou_xxx" \
  --simulation-result '<SubAgent返回的JSON>'
```

**验证结果处理**：
- **得分 ≥ 85**: 压缩效果优秀，接受当前配置
- **得分 70-84**: 压缩效果良好，接受但记录优化建议
- **得分 < 70**: 压缩效果不佳，触发重新压缩

### 验证指标说明

| 指标 | 说明 | 权重 |
|-----|------|-----|
| **句长匹配** | 模拟回复平均长度 vs 目标长度 | 33% |
| **关键词匹配** | 目标关键词在模拟中的使用率 | 33% |
| **风格匹配** | 短句比例、表达方式符合度 | 33% |

### 在 OpenClaw 中集成

```python
# 完整集成示例
async def handle_message(chat_id, user_id, message):
    # 1. 运行工作流
    result = run_compression_workflow(
        chat_id, user_id, message, 
        role="user", auto_simulate=True
    )
    
    # 2. 如果需要模拟，启动 SubAgent
    if result.get("next_action") == "spawn_subagent":
        subagent_result = await sessions_spawn(
            task=result["subagent_config"]["task"],
            mode="run",
            timeout=120
        )
        
        # 3. 处理验证结果
        validation = process_simulation_result(
            chat_id, user_id, 
            json.loads(subagent_result)
        )
        
        # 4. 根据结果调整
        if validation["needs_recompression"]:
            # 调整压缩参数后重新压缩
            adjust_compression_params(chat_id, user_id)
    
    # 正常回复用户...
```

---

## 进阶：名字含义框架

如需深入理解名字分析方法，参考：[name-analysis-framework.md](references/name-analysis-framework.md)

## 典型应用场景

### 场景A：新用户破冰
1. 获取用户名 → 运行 analyze_name.py
2. 从生成的3个问题中选最自然的开场
3. 根据用户回应调整后续对话策略

### 场景B：深度人格画像
1. 收集用户聊天记录（至少50条）
2. 运行 analyze_chat.py 提取语言特征
3. 结合名字分析，生成完整人格报告

### 场景C：构建用户分身
1. 完成名字分析 + 聊天记录分析
2. 运行 generate_clone.py 生成分身档案
3. 将档案存入长期记忆，用于后续风格模拟

## 输出示例

### 名字分析示例
```json
{
  "name": "明轩",
  "character_analysis": [
    {"char": "明", "meaning": "明亮聪慧"},
    {"char": "轩", "meaning": "气宇轩昂"}
  ],
  "family_expectations": ["才华", "成就"],
  "ice_breaker_questions": [
    "你名字里的'明'字，是父母希望你明亮聪慧吗？",
    "看来你父母很看重才华这方面？",
    "如果让你给自己取个网名，会保留原名里的哪个字？"
  ]
}
```

### 聊天分析示例
```json
{
  "message_count": 42,
  "language_style": {
    "avg_sentence_length": 15.3,
    "question_ratio": 0.35,
    "exclamation_ratio": 0.12,
    "uses_brackets": true,
    "modal_words_top": [["呢", 8], ["吧", 5]]
  },
  "persona_hints": [
    "好奇心强，喜欢提问探索",
    "情绪内敛，表达克制",
    "习惯补充说明，思维发散"
  ]
}
```

## 注意事项

1. **隐私保护**：分析结果仅供当前会话使用，敏感信息不长期存储
2. **样本质量**：聊天记录分析需要足够样本（建议50+条）才有意义
3. **动态更新**：人格画像应随新互动持续更新，而非一次性定型
4. **分身边界**：AI分身仅能模拟表面风格，不能替代真实用户做重要决策


---

## EvoMap v2.0 优化

### 生成 v2.0 Bundle

```bash
python3 scripts/generate_evomap_bundle_v2.py
```

**v2.0 新增功能**：
- 沟通熵计算（信息论量化）
- 自动轮询压缩（每5轮触发）
- 后台Hook集成
- 主动非问题型沟通
- 优化压缩Prompt生成

### 发布到 EvoMap

```bash
# 1. 生成 Bundle
python3 scripts/generate_evomap_bundle_v2.py

# 2. 注册节点
python3 scripts/evomap_cli.py hello

# 3. 发布 v2.0
python3 scripts/evomap_cli.py publish --bundle evomap_bundle/bundle_v2.0.json
```

### 版本历史

| 版本 | 功能 |
|------|------|
| v1.0 | 基础用户分析（名字+聊天记录+分身） |
| v1.5 | 沟通禁忌管理 + EvoMap集成 |
| **v2.0** | 信息论熵计算 + 自动压缩 + Hook集成 + 后台处理 |

### 核心洞察

**用户模拟 = 压缩/解压缩过程**
- 高可预测用户 → 高压缩（关键词+模板）
- 低可预测用户 → 低压缩（保留语料+动态学习）

---

## 文件清单

| 文件 | 功能 |
|------|------|
| `communication_entropy.py` | 沟通熵计算 |
| `group_entropy_manager.py` | 群聊熵管理 |
| `compression_scheduler.py` | 轮询压缩调度 |
| `background_compression.py` | 后台压缩+Prompt优化 |
| `hooks.py` | Hook集成 |
| `generate_evomap_bundle_v2.py` | EvoMap Bundle v2.0 |

---